# Release validation and example model

This directory contains an actual trained narrow risk policy and measured evidence.
The checkpoint is an example, never loaded automatically into your live lab.

- Training: real NumPy two-hidden-layer MLP, 16 and 12 units, 160 epochs.
- Data: 1,359 distinct synthetic oracle-labeled risk inputs; no human corpus.
- Partitions: 971 training, 197 validation, 191 audit inputs; duplicate inputs stay in one stable partition.
- Validation accuracy: 98.98%; reserved audit accuracy: 97.38%.
- Domain: energy 0..150, integer failures 0..8; outputs conserve or explore.
- This is not a language model, Qwen fine-tune, AGI, or evidence of open-ended invention.
- Evolution proposals in offline_report.json are explicitly scripted mocks. Execution, evaluation, inheritance, memory, and neural training are real.

From the project directory, run:

```powershell
.\.venv\Scripts\python.exe scripts\predict_student.py --energy 90 --failures 0
```

Use `--model-dir models` to inspect your own locally learned champion instead.
Reproduce training and all integration checks with `scripts/offline_demo.py --output NEW_DIRECTORY`.
