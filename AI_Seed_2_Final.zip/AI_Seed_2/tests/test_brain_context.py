"""Deterministic protocol, transport, context and scoped inspection checks."""
import copy
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from seed_core.brain import OllamaClient, SYSTEM, parse_action
from seed_core.context_builder import build_messages, estimate_tokens
from seed_core.project_index import ProjectIndex


class ProtocolTests(unittest.TestCase):
    def parse(self, action, **kwargs):
        return parse_action(json.dumps(action), **kwargs)

    def test_missing_task_inferred_only_from_exact_registered_function(self):
        result = self.parse({'action': 'mutate', 'function': 'def clamp_value(x, low, high):\n return max(min(x, high), low)'})
        self.assertEqual(result['task'], 'clamp_value')
        self.assertTrue(result['_normalizations'])
        with self.assertRaisesRegex(ValueError, 'requires task'):
            self.parse({'action': 'mutate', 'function': 'def clamp(x, low, high):\n return x'})
        with self.assertRaisesRegex(ValueError, 'match task'):
            self.parse({'action': 'mutate', 'task': 'parity_label', 'function': 'def clamp_value(x, low, high):\n return x'})

    def test_helper_is_explicit_and_calls_existing_functions_not_rejected(self):
        result = self.parse({'action': 'mutate', 'task': 'helper', 'function': 'def bigger(x):\n return old_helper(x) + 1'})
        self.assertEqual(result['task'], 'helper')

    def test_inspect_paths_recovered_only_when_unambiguous(self):
        allowed = ['seed_core/tasks.py', 'README.md']
        result = self.parse({'action': 'inspect', 'hypothesis': 'Need seed_core/tasks.py to find contract'}, allowed_paths=allowed)
        self.assertEqual(result['paths'], ['seed_core/tasks.py'])
        with self.assertRaisesRegex(ValueError, 'requires paths'):
            self.parse({'action': 'inspect'}, allowed_paths=allowed)
        with self.assertRaisesRegex(ValueError, 'requires paths'):
            self.parse({'action': 'inspect', 'learning': 'Read README.md and seed_core/tasks.py'}, allowed_paths=allowed)
        with self.assertRaisesRegex(ValueError, 'not in project_files'):
            self.parse({'action': 'inspect', 'paths': ['private.json']}, allowed_paths=allowed)
        for bad in ('/etc/passwd', '../README.md', 'C:\\Users\\secret.txt', '.env'):
            with self.subTest(path=bad), self.assertRaises(ValueError):
                self.parse({'action': 'inspect', 'paths': [bad]}, allowed_paths=allowed)
        self.assertEqual(self.parse({'action': 'inspect', 'paths': 'seed_core\\tasks.py'}, allowed_paths=allowed)['paths'], ['seed_core/tasks.py'])

    def test_protocol_limits_and_nonfinite_values(self):
        for raw in ('[]', '{"action":[]}', '{"action":"reflect"}', '{"action":"inspect","paths":true}',
                    '{"action":"reflect","learning":"a","learning":"b"}',
                    '{"action":"model_experiment","params":{"learning_rate":NaN}}'):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                parse_action(raw)
        with self.assertRaisesRegex(ValueError, '32000'):
            parse_action(' ' * 32001)
        with self.assertRaisesRegex(ValueError, 'exactly one'):
            parse_action('{"action":"reflect","learning":"x"}{"action":"reflect","learning":"y"}')
        self.assertEqual(parse_action('preamble {"action":"reflect","learning":"ok"} trailing')['learning'], 'ok')

    def test_model_parameters_match_training_bounds(self):
        good = self.parse({'action': 'model_experiment', 'params': {}})
        self.assertEqual(good['params']['epochs'], 90)
        for key, value in [('hidden1', True), ('hidden2', 65), ('epochs', 161), ('learning_rate', .2), ('unknown', 1)]:
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.parse({'action': 'model_experiment', 'params': {key: value}})


class TransportTests(unittest.TestCase):
    def test_json_mode_no_thinking_and_usage(self):
        captured = {}
        def respond(request, timeout):
            captured.update(json.loads(request.data))
            return io.BytesIO(json.dumps({'message': {'content': '{"action":"reflect","learning":"ok"}'},
                                         'prompt_eval_count': 100, 'eval_count': 15}).encode())
        with patch('urllib.request.urlopen', side_effect=respond):
            raw, usage = OllamaClient().generate([{'role': 'user', 'content': 'hi'}])
        self.assertEqual(usage, 115)
        self.assertEqual(json.loads(raw)['action'], 'reflect')
        self.assertEqual(captured['format'], 'json')
        self.assertFalse(captured['think'])
        self.assertFalse(captured['stream'])

    def test_large_and_malformed_response_rejected(self):
        for body in (b'x' * 1100, b'[]', b'{"message":{}}', b'{"error":"model missing"}',
                     b'{"message":{"content":"ok"},"eval_count":-1}'):
            with self.subTest(body=body[:40]), patch('urllib.request.urlopen', return_value=io.BytesIO(body)):
                with self.assertRaises(ConnectionError):
                    OllamaClient(max_response_bytes=1024).generate([])

    def test_missing_usage_falls_back_to_conservative_charge(self):
        messages = [{'role': 'user', 'content': 'hello'}]
        body = b'{"message":{"content":"hello response"}}'
        with patch('urllib.request.urlopen', return_value=io.BytesIO(body)):
            raw, usage = OllamaClient().generate(messages)
        self.assertGreaterEqual(usage, estimate_tokens(messages) + len(raw.encode('utf8')))


class ContextTests(unittest.TestCase):
    def observation(self):
        return {
            'identity': {'organism': 1, 'generation': 3, 'energy': 67.0},
            'focus_task': 'clamp_value',
            'task_catalog': [{'name': 'clamp_value', 'args': ['x', 'low', 'high'], 'description': 'Clamp x to inclusive low..high.'},
                             {'name': 'unrelated', 'args': ['x'], 'description': 'Not selected'}],
            'task_scores': {'clamp_value': 0, 'parity_label': 1},
            'organism_source': 'def parity_label(x):\n return "even"\n',
            'project_files': [{'path': 'seed_core/tasks.py', 'sha': '123'}, {'path': 'README.md', 'sha': '321'}],
            'memory': {'last_proposals': [{'task': 'clamp_value', 'reason': 'previous function returned wrong value', 'accepted': 0}],
                       'known_rejections': [{'task': 'clamp_value', 'reason': 'missing clamp upper bound', 'fingerprint': 'abc'}]},
            'requested_file_contents': {'seed_core/tasks.py': 'TASKS = {"clamp_value": "task contract"}'},
        }

    def test_budget_preserves_focus_feedback_and_inspected_source(self):
        original = self.observation()
        obs = copy.deepcopy(original)
        obs['project_files'] += [{'path': f'irrelevant/file_{i}.py'} for i in range(300)]
        obs['requested_file_contents']['seed_core/tasks.py'] += ' unrelated ' * 5000
        obs['memory']['last_proposals'] *= 100
        messages = build_messages(obs)
        self.assertLessEqual(estimate_tokens(messages) + 750 + 64, 4096)
        selected = json.loads(messages[1]['content'])
        self.assertEqual(selected['focus_task'], 'clamp_value')
        self.assertEqual(selected['task_catalog'][0]['name'], 'clamp_value')
        self.assertEqual(len(selected['task_catalog']), 1)
        self.assertTrue(selected['memory']['last_proposals'])
        self.assertIn('seed_core/tasks.py', selected['requested_file_contents'])
        self.assertIn('previous function returned wrong value', messages[1]['content'])
        self.assertTrue(selected['context_budget']['excerpts'])
        self.assertEqual(obs['requested_file_contents']['seed_core/tasks.py'], original['requested_file_contents']['seed_core/tasks.py'] + ' unrelated ' * 5000)
        self.assertEqual(build_messages(obs), messages)

    def test_relevant_function_and_helper_are_selected(self):
        obs = self.observation()
        obs.pop('requested_file_contents')
        obs['organism_source'] = 'def helper(x):\n return abs(x)\ndef clamp_value(x, low, high):\n return helper(x)\ndef unrelated(a):\n return a\n'
        messages = build_messages(obs, num_ctx=8192)
        source = json.loads(messages[1]['content'])['organism_source']
        self.assertIn('def clamp_value', source)
        self.assertIn('def helper', source)
        self.assertNotIn('def unrelated', source)
        self.assertLessEqual(estimate_tokens(messages) + 750 + 64, 8192)

    def test_existing_helper_is_visible_when_focus_function_is_missing(self):
        obs = self.observation()
        obs['organism_source'] = 'def risk_gate(energy, failures):\n return "conserve"\ndef positive(x):\n return max(x, 0)\n'
        messages = build_messages(obs, num_ctx=8192)
        selected = json.loads(messages[1]['content'])
        self.assertIn('def positive', selected['organism_source'])
        self.assertIn('positive(x)', selected['available_functions'])

    def test_unicode_and_impossible_budget(self):
        obs = self.observation()
        obs['requested_file_contents']['seed_core/tasks.py'] = '漢字🙂' * 5000
        messages = build_messages(obs)
        self.assertLessEqual(estimate_tokens(messages) + 750 + 64, 4096)
        with self.assertRaises(ValueError):
            build_messages(obs, num_ctx=1024, num_predict=750)

    def test_chat_keeps_the_exact_question(self):
        obs = self.observation()
        obs['user_question'] = 'Why was clamp_value rejected after my previous run?'
        messages = build_messages(obs, system=SYSTEM + '\nAnswer user_question.')
        selected = json.loads(messages[1]['content'])
        self.assertEqual(selected['user_question'], obs['user_question'])
        self.assertLessEqual(estimate_tokens(messages) + 750 + 64, 4096)

    def test_repair_preserves_exact_error_and_original_response(self):
        original = '{"action":"inspect","hypothesis":"Read task evaluator"}'
        error = 'inspect requires paths: ["seed_core/tasks.py"] (1..3 permitted files)'
        obs = {'protocol_error': error, 'original_response': original,
               'instruction': 'Correct this exact schema error; do not invent tests.',
               'focus_task': 'clamp_value', 'task_catalog': self.observation()['task_catalog']}
        messages = build_messages(obs)
        selected = json.loads(messages[1]['content'])
        self.assertEqual(selected['protocol_error'], error)
        self.assertEqual(selected['original_response'], original)
        self.assertEqual(selected['instruction'], obs['instruction'])
        self.assertLessEqual(estimate_tokens(messages) + 750 + 64, 4096)

    def test_plan_and_relevant_old_failure_outrank_unrelated_recent_record(self):
        obs = self.observation()
        obs['plan'] = {'focus_task': 'clamp_value', 'strategy': 'correct_failure',
                       'instruction': 'Correct the upper-bound error with different code.', 'cooldown_multiplier': 1}
        obs['focus_instruction'] = obs['plan']['instruction']
        obs['memory']['last_proposals'] = [{'task': 'parity_label', 'reason': 'unrelated recent failure', 'accepted': 0}]
        obs['student'] = {'trained': True, 'stored_samples': 320, 'validation_samples': 80, 'accuracy': .9}
        messages = build_messages(obs)
        selected = json.loads(messages[1]['content'])
        self.assertEqual(selected['plan']['strategy'], 'correct_failure')
        self.assertIn('Correct the upper-bound error', selected['focus_instruction'])
        self.assertEqual(selected['memory']['known_rejections'][0]['reason'], 'missing clamp upper bound')
        if 'student' in selected:
            self.assertEqual(selected['student']['stored_samples'], 320)


class ProjectInspectionTests(unittest.TestCase):
    def test_secrets_symlinks_and_search(self):
        with tempfile.TemporaryDirectory() as directory, tempfile.TemporaryDirectory() as external:
            root = Path(directory)
            (root / 'seed_core').mkdir()
            (root / 'seed_core' / 'tasks.py').write_text('def clamp_value(x):\n return x\n')
            (root / 'requirements.txt').write_text('numpy>=1.24\n# a comment\n')
            (root / 'data').mkdir()
            (root / 'data' / 'config.json').write_text('private data')
            (root / 'credentials').mkdir()
            (root / 'credentials' / 'settings.json').write_text('private credentials')
            (root / '.env').write_text('private environment')
            outside = Path(external) / 'outside.py'
            outside.write_text('private external file')
            try:
                (root / 'escape.py').symlink_to(outside)
                (root / 'inside.py').symlink_to(root / 'seed_core' / 'tasks.py')
                (root / 'alias').symlink_to(root / 'seed_core', target_is_directory=True)
            except OSError:
                pass
            index = ProjectIndex(root)
            paths = [item['path'] for item in index.manifest()]
            self.assertEqual(paths, ['requirements.txt', 'seed_core/tasks.py'])
            for path in ('escape.py', 'inside.py', 'alias/tasks.py', '../outside.py', 'data/config.json', 'credentials/settings.json', '.env'):
                with self.subTest(path=path), self.assertRaises(ValueError):
                    index.read(path)
            self.assertEqual(index.search('clamp_value')[0]['path'], 'seed_core/tasks.py')
            self.assertEqual(index.dependencies(), ['numpy>=1.24'])
            action = parse_action('{"action":"inspect","path":"seed_core/tasks.py"}', allowed_paths=index)
            self.assertEqual(action['paths'], ['seed_core/tasks.py'])


if __name__ == '__main__':
    unittest.main()
