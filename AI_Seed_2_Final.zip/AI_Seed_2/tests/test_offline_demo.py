"""Full deterministic feedback-loop demo with actual neural learning."""
import tempfile
import unittest
from pathlib import Path

from scripts.offline_demo import run_demo


class OfflineDemoTests(unittest.TestCase):
    def test_offline_evolution_training_and_restart(self):
        with tempfile.TemporaryDirectory() as parent:
            output = Path(parent) / 'demo'
            report = run_demo(output)
            self.assertEqual(report['status'], 'passed')
            self.assertEqual(report['accepted_mutations'], 4)
            self.assertEqual(report['rejected_mutations'], 3)
            self.assertGreaterEqual(report['student_champion']['accuracy'], .90)
            self.assertFalse(report['weaker_candidate']['promoted'])
            self.assertGreater(report['student_independent_trials'], 0)
            self.assertTrue((output / 'report.json').is_file())
            self.assertTrue((output / 'data' / 'seed2.db').is_file())
            self.assertTrue((output / 'models' / 'student_policy.npz').is_file())
            # A rerun must not overwrite the report, database or checkpoints.
            original_report = (output / 'report.json').read_bytes()
            with self.assertRaisesRegex(ValueError, 'existing data'):
                run_demo(output)
            self.assertEqual((output / 'report.json').read_bytes(), original_report)


if __name__ == '__main__':
    unittest.main()
