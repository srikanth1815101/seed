"""Deterministic tests of learning, split integrity, rollback and checkpoint trust."""
import io
import json
import random
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

import numpy as np

from seed_core.db import Store
from seed_core.student import NeuralStudent, _input_key, _partition


class StudentTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.store = Store(self.root / 'data' / 'db.sqlite')
        rng = random.Random(88)
        with self.store.connect() as conn:
            for _ in range(400):
                e, f = rng.randint(0, 145), rng.randint(0, 8)
                conn.execute('INSERT INTO student_examples(energy,failures,label) VALUES(?,?,?)',
                             (e, f, int(e >= 25 and f < 3)))
        self.student = NeuralStudent(self.root / 'models', self.store)

    def train(self, **kwargs):
        return self.student.train_candidate(hidden1=12, hidden2=10, epochs=110, **kwargs)

    def test_real_training_and_exact_checkpoint_reload(self):
        result = self.train()
        self.assertTrue(result['trained'])
        self.assertTrue(result['promoted'])
        self.assertGreater(result['accuracy'], .85)
        self.assertGreater(result['audit_accuracy'], .8)
        self.assertGreater(result['train_accuracy'], .8)
        self.assertEqual(result['unique_samples'], result['training_samples'] + result['validation_samples'] + result['audit_samples'])
        self.assertTrue((self.root / result['artifact']).is_file())
        model_record = self.store.one('SELECT * FROM models')
        self.assertEqual(model_record['artifact'], result['artifact'])
        # The NPZ is authoritative; a missing/stale sidecar cannot change weights or metadata.
        self.student.meta_path.write_text('{bad json', encoding='utf8')
        reloaded = NeuralStudent(self.root / 'models', self.store)
        self.assertEqual(reloaded.predict(90, 0), self.student.predict(90, 0))
        self.assertEqual(reloaded.predict(90, 0)['prediction'], 'explore')
        self.assertEqual(reloaded.predict(10, 5)['prediction'], 'conserve')
        self.assertEqual(reloaded.stats()['candidate_id'], result['candidate_id'])
        for before, after in zip(self.student.weights, reloaded.weights):
            np.testing.assert_array_equal(before, after)

    def test_duplicates_never_cross_or_move_between_splits(self):
        before, _, _ = self.student._dataset()
        key_sets = {name: set(values[2]) for name, values in before.items()}
        self.assertFalse(key_sets['train'] & key_sets['validation'])
        self.assertFalse(key_sets['train'] & key_sets['audit'])
        self.assertFalse(key_sets['validation'] & key_sets['audit'])
        with self.store.connect() as conn:
            for _ in range(200):
                conn.execute('INSERT INTO student_examples(energy,failures,label) VALUES(?,?,?)', (90, 0, 1))
            conn.execute('INSERT INTO student_examples(energy,failures,label) VALUES(?,?,?)', (149, 7, 0))
        after, _, _ = self.student._dataset()
        for name, values in after.items():
            self.assertTrue(all(_partition(key) == name for key in values[2]))
            self.assertTrue(key_sets[name] <= set(values[2]))
        duplicate = _input_key(90, 0)
        self.assertEqual(sum(values[2].count(duplicate) for values in after.values()), 1)

    def test_candidate_compared_with_champion_on_same_validation_inputs(self):
        self.train()
        saved = self.student.checkpoint.read_bytes()
        candidate_id = self.student.meta['candidate_id']
        # A stale historical accuracy of zero must not permit a tied/worse candidate.
        self.student.meta['accuracy'] = 0.0
        result = self.train()
        self.assertFalse(result['promoted'])
        self.assertGreater(result['previous_accuracy'], .85)
        self.assertEqual(self.student.checkpoint.read_bytes(), saved)
        self.assertEqual(self.student.meta['candidate_id'], candidate_id)
        worse = self.student.train_candidate(hidden1=4, hidden2=4, epochs=10, learning_rate=.001)
        self.assertFalse(worse['promoted'])
        self.assertLess(worse['accuracy'], worse['previous_accuracy'])
        self.assertEqual(self.student.checkpoint.read_bytes(), saved)
        records = self.store.rows('SELECT promoted FROM models ORDER BY id')
        self.assertEqual([row['promoted'] for row in records], [1, 0, 0])

    def test_reserved_audit_does_not_control_weights_or_promotion(self):
        first = self.train(persist=False)
        with self.store.connect() as conn:
            rows = conn.execute('SELECT id,energy,failures,label FROM student_examples').fetchall()
            for row in rows:
                if _partition(_input_key(row['energy'], row['failures'])) == 'audit':
                    conn.execute('UPDATE student_examples SET label=? WHERE id=?', (1 - row['label'], row['id']))
        second = self.train(persist=False)
        self.assertEqual(first['accuracy'], second['accuracy'])
        self.assertEqual(first['train_accuracy'], second['train_accuracy'])
        self.assertEqual(first['would_promote'], second['would_promote'])
        self.assertAlmostEqual(first['audit_accuracy'] + second['audit_accuracy'], 1.0, places=3)
        self.assertIsNone(self.student.weights)
        self.assertFalse(self.student.checkpoint.exists())
        self.assertFalse(self.store.rows('SELECT * FROM models'))

    def test_strict_parameters_and_input_domain(self):
        for kwargs in [{'hidden1': '12'}, {'hidden1': True}, {'hidden2': 12.5}, {'epochs': 2000},
                       {'learning_rate': float('nan')}, {'learning_rate': float('inf')},
                       {'learning_rate': '0.03'}, {'persist': 1}]:
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                self.student.train_candidate(**kwargs)
        self.train()
        for args in [(float('nan'), 0), (90, 1.2), (90, True), (151, 0), (-1, 0)]:
            with self.subTest(args=args):
                self.assertFalse(self.student.predict(*args)['ready'])

    def test_failed_persistence_preserves_champion(self):
        self.train()
        saved = self.student.checkpoint.read_bytes()
        metadata = self.student.meta.copy()
        weights = [array.copy() for array in self.student.weights]
        # Force a new first-champion attempt and fail before checkpoint installation.
        self.student.weights = None
        with patch.object(self.student, '_save_checkpoint', side_effect=OSError('disk full')):
            with self.assertRaisesRegex(OSError, 'disk full'):
                self.train()
        self.assertEqual(self.student.checkpoint.read_bytes(), saved)
        self.student.weights = weights
        self.assertEqual(self.student.meta, metadata)
        self.assertEqual(NeuralStudent(self.root / 'models', self.store).predict(90, 0), self.student.predict(90, 0))

    def test_database_failure_rolls_back_checkpoint_replacement(self):
        self.train()
        saved, meta = self.student.checkpoint.read_bytes(), self.student.meta_path.read_bytes()
        weights = self.student.weights
        self.student.weights = None
        with patch.object(self.store, 'execute', side_effect=RuntimeError('database failure')):
            with self.assertRaisesRegex(RuntimeError, 'database failure'):
                self.train()
        self.assertEqual(self.student.checkpoint.read_bytes(), saved)
        self.assertEqual(self.student.meta_path.read_bytes(), meta)
        self.student.weights = weights

    def test_current_validation_metric_tracks_new_evidence_and_survives_reload(self):
        self.store.execute('DELETE FROM student_examples WHERE id>?', (160,))
        initial = self.train()
        self.assertEqual(initial['accuracy'], 1.0)
        groups, _, _ = self.student._dataset()
        known = set(groups['validation'][2])
        new_examples = []
        for energy in range(151):
            for failures in range(9):
                key = _input_key(energy, failures)
                if _partition(key) != 'validation' or key in known:
                    continue
                expected = 'explore' if energy >= 25 and failures < 3 else 'conserve'
                if self.student.predict(energy, failures)['prediction'] != expected:
                    new_examples.append((energy, failures, int(expected == 'explore')))
        self.assertTrue(new_examples)
        with self.store.connect() as conn:
            conn.executemany('INSERT INTO student_examples(energy,failures,label) VALUES(?,?,?)', new_examples)
        candidate = self.student.train_candidate(hidden1=4, hidden2=4, epochs=10, learning_rate=.001)
        self.assertFalse(candidate['promoted'])
        self.assertLess(candidate['previous_accuracy'], .90)
        self.assertEqual(self.student.stats()['accuracy'], 1.0)  # Historical artifact score remains accurate.
        self.assertAlmostEqual(self.student.stats()['current_validation_accuracy'], candidate['previous_accuracy'], places=4)
        self.assertLess(self.student.predict(90, 0)['current_validation_accuracy'], .90)
        reloaded = NeuralStudent(self.root / 'models', self.store)
        self.assertEqual(reloaded.stats()['current_validation_accuracy'], self.student.stats()['current_validation_accuracy'])
        self.assertEqual(reloaded.stats()['accuracy'], 1.0)

    def test_oversized_prior_artifacts_are_not_read_into_memory_on_replacement(self):
        checkpoint = self.student.checkpoint
        sidecar = self.student.meta_path
        checkpoint.write_bytes(b'x' * 2_000_001)
        sidecar.write_bytes(b'x' * 100_001)
        self.student = NeuralStudent(self.root / 'models', self.store)
        self.assertFalse(self.student.stats()['trained'])
        original_read = Path.read_bytes

        def bounded_read(path):
            if path == checkpoint or path == sidecar:
                self.fail('Rollback must not read prior artifacts into memory')
            return original_read(path)

        # Also exercise the bounded-copy fallback used where hard links are unavailable.
        with patch.object(Path, 'read_bytes', bounded_read), patch('seed_core.student.os.link', side_effect=OSError('unsupported')):
            result = self.train()
        self.assertTrue(result['promoted'])
        self.assertTrue(NeuralStudent(self.root / 'models', self.store).stats()['trained'])
        self.assertFalse(list((self.root / 'models').glob('.rollback-*')))

    def test_failed_rollback_retains_recovery_files(self):
        self.train()
        saved_checkpoint = self.student.checkpoint.read_bytes()
        saved_meta = self.student.meta_path.read_bytes()
        self.student.weights = None
        original_replace = __import__('os').replace

        def fail_only_rollback(source, target):
            if Path(source).name.startswith('.rollback-'):
                raise OSError('filesystem rejected recovery replacement')
            return original_replace(source, target)

        with patch.object(self.store, 'execute', side_effect=RuntimeError('database failure')):
            with patch('seed_core.student.os.replace', side_effect=fail_only_rollback):
                with self.assertRaisesRegex(OSError, 'rollback was incomplete'):
                    self.train()
        recovery = [path.read_bytes() for path in (self.root / 'models').glob('.rollback-*')]
        self.assertIn(saved_checkpoint, recovery)
        self.assertIn(saved_meta, recovery)

    def test_malformed_checkpoint_never_claims_ready(self):
        self.train()
        with self.student.checkpoint.open('wb') as handle:
            np.savez_compressed(handle, w1=np.zeros((5, 400)), w2=np.zeros((400, 4)), w3=np.zeros((4, 2)),
                                b1=np.zeros(400), b2=np.zeros(4), b3=np.zeros(2))
        reloaded = NeuralStudent(self.root / 'models', self.store)
        self.assertFalse(reloaded.stats()['trained'])
        self.assertFalse(reloaded.predict(90, 0)['ready'])
        self.assertIn('checkpoint_error', reloaded.stats())

    def test_forged_array_header_is_rejected_before_allocation(self):
        self.train()
        with zipfile.ZipFile(self.student.checkpoint, 'r') as archive:
            contents = {name: archive.read(name) for name in archive.namelist()}
        malicious = io.BytesIO()
        np.lib.format.write_array_header_1_0(malicious,
                                            {'descr': '<f8', 'fortran_order': False, 'shape': (10 ** 12,)})
        contents['w1.npy'] = malicious.getvalue()
        with zipfile.ZipFile(self.student.checkpoint, 'w') as archive:
            for name, content in contents.items():
                archive.writestr(name, content)
        reloaded = NeuralStudent(self.root / 'models', self.store)
        self.assertFalse(reloaded.stats()['trained'])
        self.assertIn('shape/size', reloaded.stats()['checkpoint_error'])

    def test_duplicate_conflicting_labels_are_rejected(self):
        with self.store.connect() as conn:
            conn.execute('INSERT INTO student_examples(energy,failures,label) VALUES(?,?,?)', (90, 0, 1))
            conn.execute('INSERT INTO student_examples(energy,failures,label) VALUES(?,?,?)', (90, 0, 0))
        with self.assertRaisesRegex(ValueError, 'Conflicting labels'):
            self.train()

    def test_insufficient_unique_observations_do_not_train(self):
        self.store.execute('DELETE FROM student_examples')
        with self.store.connect() as conn:
            for _ in range(300):
                conn.execute('INSERT INTO student_examples(energy,failures,label) VALUES(?,?,?)', (90, 0, 1))
        result = self.train()
        self.assertFalse(result['trained'])
        self.assertEqual(result['unique_samples'], 1)
        self.assertFalse(self.student.checkpoint.exists())


if __name__ == '__main__':
    unittest.main()
