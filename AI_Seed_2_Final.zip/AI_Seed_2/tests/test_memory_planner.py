"""Persistence migrations, relevant historical retrieval, deterministic planning."""
import sqlite3
import tempfile
import unittest
from pathlib import Path

from seed_core.db import SCHEMA, PROPOSAL_COLUMNS, Store
from seed_core.memory import Memory
from seed_core.planner import Planner


class PersistenceTests(unittest.TestCase):
    def test_transaction_rolls_back_outcome_source_and_energy_together(self):
        with tempfile.TemporaryDirectory() as directory:
            store = Store(Path(directory) / 'seed.db')
            store.execute('INSERT INTO organisms(id,generation,alive,energy) VALUES(1,1,1,85)')
            proposal = store.execute("INSERT INTO proposals(organism,action,outcome) VALUES(1,'mutate','pending')")
            store.execute("INSERT INTO organism_code VALUES(1,'previous source','previous fingerprint','before')")
            with self.assertRaisesRegex(RuntimeError, 'simulated interruption'):
                with store.transaction() as transaction:
                    store.execute('UPDATE organisms SET energy=88 WHERE id=1')
                    with store.connect() as shared:
                        self.assertIs(transaction, shared)
                        shared.execute("UPDATE proposals SET outcome='accepted',accepted=1 WHERE id=?", (proposal,))
                    with store.transaction() as nested:
                        self.assertIs(transaction, nested)
                        store.execute("UPDATE organism_code SET source='new source',fingerprint='new' WHERE organism=1")
                        store.execute("INSERT INTO code_revisions(organism,source) VALUES(1,'new source')")
                    self.assertEqual(store.one('SELECT energy FROM organisms WHERE id=1')['energy'], 88)
                    raise RuntimeError('simulated interruption')
            self.assertEqual(store.one('SELECT energy FROM organisms WHERE id=1')['energy'], 85)
            self.assertEqual(store.one('SELECT outcome FROM proposals WHERE id=?', (proposal,))['outcome'], 'pending')
            self.assertEqual(store.one('SELECT source FROM organism_code WHERE organism=1')['source'], 'previous source')
            self.assertEqual(store.one('SELECT COUNT(*) n FROM code_revisions')['n'], 0)
            self.assertEqual(store.one('SELECT COUNT(*) n FROM proposals')['n'], 1)
            # The connection is released after failure; the next transaction is usable.
            with store.transaction():
                store.execute('UPDATE organisms SET energy=86 WHERE id=1')
            self.assertEqual(store.one('SELECT energy FROM organisms WHERE id=1')['energy'], 86)

    def test_caught_inner_sql_failure_cannot_commit_partial_transaction(self):
        with tempfile.TemporaryDirectory() as directory:
            store = Store(Path(directory) / 'seed.db')
            store.execute("INSERT INTO settings VALUES('durable','before')")
            with self.assertRaisesRegex(RuntimeError, 'inner database failure'):
                with store.transaction():
                    store.execute("UPDATE settings SET value='partial' WHERE key='durable'")
                    try:
                        store.execute('INSERT INTO nonexistent_table VALUES(1)')
                    except sqlite3.OperationalError:
                        pass
            self.assertEqual(store.one("SELECT value FROM settings WHERE key='durable'")['value'], 'before')

    def test_other_thread_does_not_observe_or_commit_uncommitted_changes(self):
        import threading
        with tempfile.TemporaryDirectory() as directory:
            store = Store(Path(directory) / 'seed.db')
            store.execute("INSERT INTO settings VALUES('state','before')")
            result = []
            with store.transaction():
                store.execute("UPDATE settings SET value='during' WHERE key='state'")
                thread = threading.Thread(target=lambda: result.append(
                    store.one("SELECT value FROM settings WHERE key='state'")['value']))
                thread.start()
                thread.join(2)
                self.assertFalse(thread.is_alive())
                self.assertEqual(result, ['before'])
            self.assertEqual(store.one("SELECT value FROM settings WHERE key='state'")['value'], 'during')

    def test_legacy_history_migrates_without_replacing_rows(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'legacy.db'
            with sqlite3.connect(path) as conn:
                conn.executescript(SCHEMA)
                conn.execute('ALTER TABLE proposals ADD COLUMN user_annotation TEXT')
                conn.execute("INSERT INTO organisms(id,parent,generation,alive,energy) VALUES(4,NULL,1,1,75)")
                conn.execute("INSERT INTO settings VALUES('user_setting','preserved')")
                reason = ('already attempted this exact function for this task: ' * 3) + 'unknown function: min'
                conn.execute('INSERT INTO proposals(id,organism,action,task,reason,accepted,user_annotation) '
                             'VALUES(12,4,\'mutate\',\'clamp_value\',?,0,\'keep this\')', (reason,))
            store = Store(path)
            migrated = store.one('SELECT * FROM proposals WHERE id=12')
            self.assertEqual(migrated['reason'], reason)
            self.assertEqual(migrated['canonical_reason'], 'unknown function: min')
            self.assertEqual(migrated['user_annotation'], 'keep this')
            self.assertEqual(store.one('SELECT energy FROM organisms WHERE id=4')['energy'], 75)
            self.assertEqual(store.one("SELECT value FROM settings WHERE key='user_setting'")['value'], 'preserved')
            self.assertTrue(set(PROPOSAL_COLUMNS).issubset(migrated))
            Store(path)
            self.assertEqual(store.one('SELECT COUNT(*) n FROM proposals')['n'], 1)
            with store.connect() as conn:
                self.assertEqual(conn.execute('PRAGMA user_version').fetchone()[0], 2)
                self.assertEqual(conn.execute('PRAGMA integrity_check').fetchone()[0], 'ok')

    def test_future_schema_is_not_downgraded(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'future.db'
            with sqlite3.connect(path) as conn:
                conn.execute('PRAGMA user_version=50')
                conn.execute('CREATE TABLE user_data(value TEXT)')
                conn.execute("INSERT INTO user_data VALUES('safe')")
            with self.assertRaisesRegex(ValueError, 'newer'):
                Store(path)
            with sqlite3.connect(path) as conn:
                self.assertEqual(conn.execute('PRAGMA user_version').fetchone()[0], 50)
                self.assertEqual(conn.execute('SELECT value FROM user_data').fetchone()[0], 'safe')
                self.assertIsNone(conn.execute("SELECT name FROM sqlite_master WHERE name='proposals'").fetchone())


class MemoryPlannerTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.directory.name) / 'seed.db')
        self.store.execute('INSERT INTO organisms(id,parent,generation,alive) VALUES(1,NULL,1,0)')
        self.store.execute('INSERT INTO organisms(id,parent,generation,alive) VALUES(2,1,2,1)')
        self.organism = self.store.one('SELECT * FROM organisms WHERE id=2')

    def tearDown(self):
        self.directory.cleanup()

    def proposal(self, *, oid=2, task='clamp_value', fingerprint='abc', accepted=0,
                 action='mutate', reason='unknown function: open', outcome='rejected'):
        return self.store.execute(
            'INSERT INTO proposals(organism,action,task,function_name,fingerprint,reason,'
            'canonical_reason,accepted,outcome,cost,reward,holdout_before,holdout_after) '
            'VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
            (oid, action, task, task, fingerprint, reason, reason, accepted, outcome,
             1.5, 4.5 if accepted else 0, 0, 1 if accepted else 0))

    def test_relevant_older_rejection_and_ancestor_success_survive_noise(self):
        first = self.proposal(oid=1)
        self.proposal(oid=1, task='parity_label', fingerprint='parity', accepted=1, outcome='accepted', reason='')
        for i in range(150):
            self.proposal(task='budget_left', fingerprint=f'noise{i}')
        memory = Memory(self.store).recall(self.organism, focus_task='clamp_value', limit=5)
        self.assertEqual(memory['known_rejections'][0]['id'], first)
        self.assertEqual(memory['known_rejections'][0]['reason'], 'unknown function: open')
        self.assertEqual(memory['verified_successes'][0]['task'], 'parity_label')
        self.assertEqual(memory['evolutionary_memory']['ancestors'][0]['id'], 1)
        self.assertEqual(len(memory['last_proposals']), 5)
        self.assertEqual(memory['summary']['attempts'], 150)
        self.assertEqual(memory['summary']['net_energy'], -225)

    def test_rejection_fingerprint_is_deduplicated_and_original_reason_kept(self):
        first = self.proposal()
        for _ in range(8):
            self.proposal(reason='DUPLICATE_PROPOSAL: duplicate wrapper')
        recall = Memory(self.store).recall(self.organism, 'clamp_value')
        self.assertEqual(len(recall['known_rejections']), 1)
        self.assertEqual(recall['known_rejections'][0]['id'], first)
        self.assertEqual(recall['known_rejections'][0]['reason'], 'unknown function: open')

    def test_ancestor_cycles_are_bounded(self):
        self.store.execute('UPDATE organisms SET parent=2 WHERE id=1')
        recall = Memory(self.store).recall(self.organism)
        self.assertEqual([row['id'] for row in recall['evolutionary_memory']['ancestors']], [1])

    def test_two_rejections_switch_objective_and_back_off(self):
        self.proposal()
        self.proposal()
        scores = {'clamp_value': 0, 'parity_label': 0, 'risk_gate': 1}
        planner = Planner(self.store)
        plan = planner.plan(self.organism, scores)
        self.assertEqual(plan['focus_task'], 'parity_label')
        self.assertEqual(plan['strategy'], 'switch_task')
        self.assertEqual(plan['cooldown_multiplier'], 4)
        self.assertEqual(plan, planner.plan(self.organism, scores))

    def test_single_failure_reports_exact_constraint(self):
        self.proposal(reason='unsupported syntax: Attribute')
        plan = Planner(self.store).plan(self.organism, {'clamp_value': 0})
        self.assertEqual(plan['strategy'], 'correct_failure')
        self.assertIn('unsupported syntax: Attribute', plan['instruction'])

    def test_inspection_reflection_stall_changes_strategy(self):
        self.proposal(action='inspect', task='', fingerprint=None)
        self.proposal(action='reflect', task='', fingerprint=None)
        plan = Planner(self.store).plan(self.organism, {'clamp_value': 0, 'parity_label': 0})
        self.assertEqual(plan['strategy'], 'switch_task')
        self.assertEqual(plan['focus_task'], 'parity_label')

    def test_saved_reflection_preference_is_validated(self):
        self.store.execute('INSERT INTO settings(key,value) VALUES(?,?)', ('planner_next_task_2', '"parity_label"'))
        plan = Planner(self.store).plan(self.organism, {'clamp_value': 0, 'parity_label': .5})
        self.assertEqual(plan['focus_task'], 'parity_label')
        solved = Planner(self.store).plan(self.organism, {'clamp_value': 1, 'parity_label': 1})
        self.assertEqual(solved['focus_task'], 'model_experiment')


if __name__ == '__main__':
    unittest.main()
