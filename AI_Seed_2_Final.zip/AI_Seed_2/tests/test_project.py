"""Offline integration checks: no running Ollama or HTTP service required."""
import json
import tempfile
import unittest
from pathlib import Path

from seed_core.brain import parse_action
from seed_core.engine import Engine
from seed_core.project_index import ProjectIndex
from seed_core.safe_runtime import Runtime, CapabilityError, merge_one
from seed_core.tasks import evaluate
from seed_core.student import NeuralStudent
from seed_core.db import Store
import random


class FakeBrain:
    def __init__(self, responses):
        self.responses = iter(responses)
        self.messages = []

    def generate(self, messages):
        self.messages.append(messages)
        answer = next(self.responses)
        return answer if isinstance(answer, str) else json.dumps(answer), 85


class ProjectTests(unittest.TestCase):
    def make_engine(self, brain):
        tmp = tempfile.TemporaryDirectory()
        root = Path(tmp.name)
        original = Path(__file__).resolve().parents[1]
        (root / 'config.json').write_bytes((original / 'config.json').read_bytes())
        (root / 'seed_core').mkdir()
        (root / 'seed_core' / 'tasks.py').write_text('# safe to inspect')
        (root / 'data').mkdir()
        (root / 'data' / 'private.db').write_text('SECRET!')
        engine = Engine(root, brain=brain, start_worker=False)
        engine.cfg['brain_every_cycles'] = 1
        engine.cfg['max_ram_percent'] = 101
        engine.cfg['max_cpu_percent'] = 101
        return tmp, engine

    def test_restricted_runtime(self):
        source = 'def triple(x):\n    return x * 3\n'
        self.assertEqual(Runtime(source).call('triple', 7), 21)
        merged, name, op = merge_one(source, 'def calc(x):\n    return triple(x) + 2\n')
        self.assertEqual((name, op), ('calc', 'added'))
        self.assertEqual(Runtime(merged).call('calc', 6), 20)
        with self.assertRaises(CapabilityError):
            Runtime('import os\ndef x():\n    return os.getcwd()')
        with self.assertRaises(CapabilityError):
            Runtime('def x():\n    return open("secret")').call('x')
        with self.assertRaises(CapabilityError):
            merge_one(source, source)

    def test_sample_task(self):
        src = 'def parity_label(x):\n    return "even" if x % 2 == 0 else "odd"\n'
        self.assertEqual(evaluate(src, 'parity_label')['score'], 1.0)
        self.assertEqual(evaluate('', 'parity_label')['score'], 0)

    def test_memory_and_mutation_and_persistence(self):
        fake = FakeBrain([
            {'action': 'inspect', 'paths': ['seed_core/tasks.py'],
             'hypothesis': 'Need to see task evaluator', 'learning': 'Read project source'},
            {'action': 'mutate', 'task': 'parity_label',
             'function': 'def parity_label(x):\n    return "even" if x % 2 == 0 else "odd"',
             'hypothesis': 'Adds correct parity task', 'learning': 'Parity tests were passed'},
            {'action': 'mutate', 'task': 'parity_label',
             'function': 'def parity_label(x):\n    return "even" if x % 2 == 0 else "odd"',
             'hypothesis': 'repeat', 'learning': 'Should not repeat'},
        ])
        tmp, engine = self.make_engine(fake)
        try:
            engine.control('start')
            engine.step()
            self.assertIn('seed_core/tasks.py', fake.messages[0][1]['content'])
            engine.step()
            self.assertIn('requested_file_contents', json.loads(fake.messages[1][1]['content']))
            engine.step()
            accepted = engine.rows('SELECT * FROM proposals ORDER BY id')
            self.assertEqual(len(accepted), 3)
            self.assertEqual(accepted[1]['accepted'], 1)
            self.assertEqual(accepted[2]['accepted'], 0)
            self.assertIn('already attempted', accepted[2]['reason'])
            self.assertGreater(accepted[1]['reward'], accepted[1]['cost'])
            self.assertEqual(evaluate(engine._organism_source(1), 'parity_label')['score'], 1)
            self.assertTrue(engine.rows('SELECT * FROM episodes'))
            context = json.loads(fake.messages[2][1]['content'])
            self.assertTrue(context['memory']['last_proposals'])
            new_engine = Engine(engine.root, brain=FakeBrain([]), start_worker=False)
            self.assertEqual(len(new_engine.rows('SELECT * FROM proposals')), 3)
            self.assertEqual(new_engine._organism_source(1), engine._organism_source(1))
        finally:
            tmp.cleanup()

    def test_repair_invalid_inheritance(self):
        tmp, engine = self.make_engine(FakeBrain([]))
        try:
            engine.control('start')
            engine._write_code(1, 'def useless(x):\n    return x\n')
            child = engine._spawn(parent=1)
            self.assertIn('risk_gate', Runtime(engine._organism_source(child)).functions)
            self.assertIn('useless', Runtime(engine._organism_source(child)).functions)
        finally:
            tmp.cleanup()

    def test_file_awareness_is_safe(self):
        tmp, engine = self.make_engine(FakeBrain([]))
        try:
            paths = [i['path'] for i in engine.index.manifest()]
            self.assertIn('seed_core/tasks.py', paths)
            self.assertNotIn('data/private.db', paths)
            with self.assertRaises(ValueError):
                engine.index.read('../private.txt')
            with self.assertRaises(ValueError):
                engine.index.read('data/private.db')
        finally:
            tmp.cleanup()

    def test_neural_student_trains_and_persists(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            store = Store(base / 'data' / 'db.sqlite')
            rng = random.Random(88)
            with store.connect() as conn:
                for _ in range(320):
                    e, f = rng.randint(0, 145), rng.randint(0, 8)
                    correct = int(e >= 25 and f < 3)
                    conn.execute('INSERT INTO student_examples(energy,failures,label) VALUES(?,?,?)', (e, f, correct))
            model = NeuralStudent(base / 'models', store)
            result = model.train_candidate(hidden1=12, hidden2=10, epochs=110)
            self.assertTrue(result['trained'])
            self.assertTrue(result['promoted'])
            self.assertGreater(result['accuracy'], .85)
            reloaded = NeuralStudent(base / 'models', store)
            self.assertTrue(reloaded.predict(90, 0)['ready'])
            self.assertEqual(reloaded.predict(90, 0)['prediction'], 'explore')
            self.assertEqual(reloaded.predict(10, 5)['prediction'], 'conserve')

    def test_json_repair_and_trace(self):
        fake = FakeBrain(['not valid json', {'action': 'reflect', 'hypothesis': 'fixed', 'learning': 'Provide valid JSON next time'}])
        tmp, engine = self.make_engine(fake)
        try:
            engine.control('start')
            engine.step()
            proposals = engine.rows('SELECT * FROM proposals')
            self.assertEqual(len(proposals), 1)
            self.assertEqual(proposals[0]['action'], 'reflect')
            traces = engine.rows('SELECT * FROM traces ORDER BY id')
            self.assertEqual([t['purpose'] for t in traces], ['decision', 'json_repair'])
        finally:
            tmp.cleanup()

    def test_parse_json(self):
        self.assertEqual(parse_action('x {"action":"reflect","learning":"ok"} y')['action'], 'reflect')
        with self.assertRaises(ValueError):
            parse_action('{"action":"delete"}')


if __name__ == '__main__':
    unittest.main()
