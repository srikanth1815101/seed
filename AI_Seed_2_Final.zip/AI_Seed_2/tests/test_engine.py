"""End-to-end evolution admission, accounting, recovery, and cancellation.

Only the Ollama transport is replaced. Proposals run through the real parser,
restricted runtime, trusted benchmarks, SQLite, and organism code activation.
"""
import json
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

from seed_core.context_builder import estimate_tokens
from seed_core.engine import BASELINE, Engine
from seed_core.safe_runtime import Runtime, canonical_fingerprint
from seed_core.tasks import evaluate, evaluate_holdout, scores


PARITY = 'def parity_label(x):\n    return "even" if x % 2 == 0 else "odd"'


class FakeBrain:
    def __init__(self, responses):
        self.responses = list(responses)
        self.messages = []

    def generate(self, messages):
        self.messages.append(messages)
        if not self.responses:
            raise AssertionError('Unexpected extra inference call')
        response = self.responses.pop(0)
        return response if isinstance(response, str) else json.dumps(response), 85


class BlockingBrain(FakeBrain):
    def __init__(self, response):
        super().__init__([response])
        self.started = threading.Event()
        self.release = threading.Event()

    def generate(self, messages):
        self.started.set()
        if not self.release.wait(timeout=5):
            raise AssertionError('Test did not release the blocked model call')
        return super().generate(messages)


class EngineIntegrationTests(unittest.TestCase):
    def make_engine(self, responses=(), brain=None):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        root = Path(directory.name)
        original = Path(__file__).resolve().parents[1]
        cfg = json.loads((original / 'config.json').read_text(encoding='utf8'))
        cfg.update(brain_every_cycles=1, max_ram_percent=101, max_cpu_percent=101,
                   auto_start=False)
        (root / 'config.json').write_text(json.dumps(cfg), encoding='utf8')
        (root / 'seed_core').mkdir()
        (root / 'seed_core' / 'tasks.py').write_text('# task contract fixture', encoding='utf8')
        fake = brain or FakeBrain(responses)
        engine = Engine(root, brain=fake, start_worker=False)
        self.addCleanup(engine.shutdown)
        engine.control('start')
        return engine, fake

    def decide(self, engine, oid=1):
        engine._decide(engine.store.one('SELECT * FROM organisms WHERE id=?', (oid,)))

    def test_ast_duplicates_keep_one_canonical_failure_without_nested_wrapping(self):
        source = 'def clamp_value(x, low, high):\n    return open(x)'
        spaced = 'def clamp_value(x,low,high):\n  return open( x )\n'
        engine, fake = self.make_engine([
            {'action': 'mutate', 'function': code, 'learning': 'test unsupported operation'}
            for code in (source, spaced, source, spaced)
        ])
        for _ in range(4):
            self.decide(engine)
        proposals = engine.rows('SELECT * FROM proposals ORDER BY id')
        self.assertEqual(len(proposals), 4)
        self.assertEqual(len(fake.messages), 4)
        first = proposals[0]
        self.assertFalse(first['accepted'])
        self.assertIn('open', first['canonical_reason'])
        for duplicate in proposals[1:]:
            self.assertEqual(duplicate['fingerprint'], first['fingerprint'])
            self.assertEqual(duplicate['canonical_reason'], first['canonical_reason'])
            self.assertEqual(duplicate['duplicate_of'], first['id'])
            self.assertTrue(duplicate['reason'].startswith('DUPLICATE_PROPOSAL'))
            self.assertEqual(duplicate['reason'].count('DUPLICATE_PROPOSAL'), 1)
            self.assertLess(len(duplicate['reason']), 300)
            self.assertEqual(duplicate['reward'], 0)
            self.assertAlmostEqual(duplicate['cost'], engine.cfg['thinking_cost'] + 85 * engine.cfg['energy_per_token'])
        self.assertEqual(engine._organism_source(1), BASELINE)
        self.assertEqual(engine.daily_calls, 4)
        self.assertEqual(engine.daily_tokens, 340)

    def test_measured_admission_records_code_evaluations_lineage_and_energy(self):
        engine, _ = self.make_engine([
            {'action': 'mutate', 'function': PARITY, 'hypothesis': 'Solve integer parity', 'learning': 'Use modulo'},
            {'action': 'mutate', 'task': 'clamp_value',
             'function': 'def clamp_value(x, low, high):\n    return x',
             'learning': 'Incorrect candidate must earn no reward'},
        ])
        self.decide(engine)
        active = engine._organism_source(1)
        self.assertEqual(evaluate(active, 'parity_label')['score'], 1)
        self.decide(engine)
        accepted, rejected = engine.rows('SELECT * FROM proposals ORDER BY id')
        self.assertEqual(accepted['accepted'], 1)
        self.assertEqual(accepted['task'], 'parity_label')
        self.assertEqual(accepted['source_before'], BASELINE)
        self.assertEqual(accepted['source_after'], active)
        self.assertIn('+def parity_label', accepted['diff'])
        self.assertEqual(accepted['generation'], 1)
        self.assertIsNone(accepted['parent'])
        self.assertEqual(accepted['base_fingerprint'], canonical_fingerprint(BASELINE))
        self.assertEqual(json.loads(accepted['original_action'])['function'], PARITY)
        evaluations = json.loads(accepted['evaluation_json'])
        self.assertGreater(evaluations['train_after']['total'], 0)
        self.assertGreater(evaluations['holdout_after']['benchmark_cases'], 0)
        self.assertEqual(evaluations['holdout_after']['score'], 1)
        self.assertAlmostEqual(accepted['reward'] - accepted['cost'], engine.cfg['successful_edit_surplus'])
        self.assertAlmostEqual(accepted['net_energy'], engine.cfg['successful_edit_surplus'])
        self.assertAlmostEqual(accepted['energy_after'] - accepted['energy_before'], accepted['net_energy'])
        self.assertGreaterEqual(accepted['execution_ms'], 0)
        self.assertEqual(rejected['accepted'], 0)
        self.assertEqual(rejected['reward'], 0)
        self.assertAlmostEqual(rejected['net_energy'], -rejected['cost'], places=6)
        self.assertEqual(engine._organism_source(1), active)
        self.assertEqual(engine.store.one('SELECT COUNT(*) n FROM code_revisions')['n'], 2)
        self.assertEqual(engine.store.one('SELECT source FROM organism_code WHERE organism=1')['source'], active)

    def test_net_energy_reports_real_cap_clamping(self):
        engine, _ = self.make_engine([{'action': 'mutate', 'function': PARITY}])
        engine.store.execute('UPDATE organisms SET energy=? WHERE id=1', (engine.cfg['max_energy'] - 1,))
        self.decide(engine)
        proposal = engine.store.one('SELECT * FROM proposals')
        self.assertTrue(proposal['accepted'])
        self.assertAlmostEqual(proposal['net_energy'], 1)
        self.assertAlmostEqual(proposal['energy_after'], engine.cfg['max_energy'])

    def test_helper_replacement_cannot_regress_dependent_capability(self):
        engine, _ = self.make_engine([{
            'action': 'mutate', 'task': 'helper',
            'function': 'def absolute(x):\n    return 0',
        }])
        source = (BASELINE + '\ndef absolute(x):\n    return abs(x)\n'
                  '\ndef distance_1d(a, b):\n    return absolute(a - b)\n')
        engine._write_code(1, source)
        self.assertEqual(evaluate(source, 'distance_1d')['score'], 1)
        self.decide(engine)
        proposal = engine.store.one('SELECT * FROM proposals')
        self.assertFalse(proposal['accepted'])
        self.assertIn('regress', proposal['reason'])
        self.assertEqual(engine._organism_source(1), source)

    def test_helper_boundary_regression_is_rejected_even_when_scorecard_misses_it(self):
        engine, _ = self.make_engine([{
            'action': 'mutate', 'task': 'helper',
            'function': 'def adjust(t):\n    return 30 if t == 12 else t',
        }])
        source = (BASELINE + '\ndef adjust(t):\n    return t\n'
                  '\ndef temperature_band(t):\n    value = adjust(t)\n'
                  '    return "cold" if value < 12 else ("hot" if value >= 29 else "mild")\n')
        candidate = source.replace('def adjust(t):\n    return t', 'def adjust(t):\n    return 30 if t == 12 else t')
        self.assertEqual(scores(source)['temperature_band'], scores(candidate)['temperature_band'])
        self.assertLess(evaluate_holdout(candidate, 'temperature_band')['score'], 1)
        engine._write_code(1, source)
        self.decide(engine)
        proposal = engine.store.one('SELECT * FROM proposals')
        self.assertFalse(proposal['accepted'])
        self.assertIn('regress', proposal['reason'])
        self.assertEqual(engine._organism_source(1), source)

    def test_budget_reservation_prevents_calls_and_usage_survives_restart(self):
        engine, brain = self.make_engine([{'action': 'reflect', 'learning': 'bounded request'}])
        messages = [{'role': 'user', 'content': 'hello'}]
        reservation = estimate_tokens(messages) + engine.cfg['num_predict']
        engine.cfg['daily_token_limit'] = reservation - 1
        with self.assertRaisesRegex(RuntimeError, 'Insufficient daily tokens'):
            engine._model_call(messages, 1, 'test_budget')
        self.assertEqual(brain.messages, [])
        self.assertEqual(engine.daily_calls, 0)
        self.assertEqual(engine.daily_tokens, 0)
        engine.cfg['daily_token_limit'] = reservation
        engine._model_call(messages, 1, 'test_budget')
        self.assertEqual(engine.daily_calls, 1)
        self.assertEqual(engine.daily_tokens, 85)
        restarted_brain = FakeBrain([])
        restarted = Engine(engine.root, brain=restarted_brain, start_worker=False)
        self.addCleanup(restarted.shutdown)
        self.assertEqual(restarted.daily_calls, 1)
        self.assertEqual(restarted.daily_tokens, 85)
        restarted.cfg['daily_calls_limit'] = 1
        with self.assertRaisesRegex(RuntimeError, 'budget exhausted'):
            restarted._model_call(messages, 1, 'test_budget')
        self.assertEqual(restarted_brain.messages, [])

    def test_protocol_repair_is_one_attempt_and_preserves_exact_responses(self):
        original = '{"action":"inspect","hypothesis":"missing paths"}'
        repair = '{"action":"inspect","learning":"still missing paths"}'
        engine, brain = self.make_engine([original, repair, {'action': 'reflect', 'learning': 'must not be called'}])
        before_energy = engine.store.one('SELECT energy FROM organisms WHERE id=1')['energy']
        self.decide(engine)
        self.assertEqual(len(brain.messages), 2)
        self.assertEqual(engine.rows('SELECT * FROM proposals'), [])
        traces = engine.rows('SELECT * FROM traces ORDER BY id')
        self.assertEqual([row['purpose'] for row in traces], ['decision', 'json_repair'])
        self.assertEqual([row['response_text'] for row in traces], [original, repair])
        repair_context = json.loads(brain.messages[1][1]['content'])
        self.assertEqual(repair_context['original_response'], original)
        self.assertIn('inspect requires paths', repair_context['protocol_error'])
        episode = engine.store.one('SELECT * FROM episodes ORDER BY id DESC LIMIT 1')
        self.assertEqual(episode['action'], 'invalid')
        after_energy = engine.store.one('SELECT energy FROM organisms WHERE id=1')['energy']
        expected_cost = engine.cfg['thinking_cost'] + 170 * engine.cfg['energy_per_token']
        self.assertAlmostEqual(before_energy - after_energy, expected_cost)
        self.assertEqual(engine.daily_tokens, 170)

    def _run_blocked_decision(self, engine, brain):
        errors = []

        def decide():
            try:
                self.decide(engine)
            except Exception as exc:
                errors.append(exc)

        worker = threading.Thread(target=decide)
        worker.start()
        self.addCleanup(worker.join, 5)
        self.addCleanup(brain.release.set)
        self.assertTrue(brain.started.wait(3), 'Inference did not begin')
        return worker, errors

    def test_pause_resume_during_inference_cancels_stale_mutation(self):
        brain = BlockingBrain({'action': 'mutate', 'function': PARITY})
        engine, _ = self.make_engine(brain=brain)
        worker, errors = self._run_blocked_decision(engine, brain)
        engine.control('pause')
        engine.control('resume')
        brain.release.set()
        worker.join(5)
        self.assertFalse(worker.is_alive())
        self.assertEqual(errors, [])
        self.assertEqual(engine.state, 'RUNNING')
        self.assertEqual(engine.rows('SELECT * FROM proposals'), [])
        self.assertEqual(engine._organism_source(1), BASELINE)
        self.assertEqual(engine.store.one('SELECT action FROM episodes ORDER BY id DESC LIMIT 1')['action'], 'cancelled')
        self.assertEqual(engine.daily_calls, 1)
        self.assertIn('cancel', engine.store.one('SELECT validation FROM traces')['validation'])

    def test_pause_before_malformed_response_prevents_a_new_repair_call(self):
        brain = BlockingBrain('not JSON')
        engine, _ = self.make_engine(brain=brain)
        worker, errors = self._run_blocked_decision(engine, brain)
        engine.control('pause')
        brain.release.set()
        worker.join(5)
        self.assertFalse(worker.is_alive())
        self.assertEqual(errors, [])
        self.assertEqual(engine.daily_calls, 1)
        self.assertEqual([row['purpose'] for row in engine.rows('SELECT purpose FROM traces')], ['decision'])

    def test_corrupt_legacy_source_is_quarantined_and_history_survives_restart(self):
        engine, _ = self.make_engine([{'action': 'mutate', 'function': PARITY}])
        self.decide(engine)
        engine.store.execute('DELETE FROM organism_code WHERE organism=1')
        source_path = engine.root / 'workspaces' / 'organism_1' / 'capabilities.py'
        corrupt = 'import os\ndef risk_gate(energy, failures):\n    return os.system("no")\n'
        source_path.write_text(corrupt, encoding='utf8')
        healthy = engine._organism_source(1)
        self.assertEqual(evaluate(healthy, 'risk_gate')['score'], 1)
        quarantine = list(source_path.parent.glob('quarantine_*.txt'))
        self.assertTrue(quarantine)
        self.assertIn(corrupt, [path.read_text(encoding='utf8') for path in quarantine])
        self.assertNotIn('import os', source_path.read_text(encoding='utf8'))
        child = engine._spawn(parent=1)
        self.assertIn('risk_gate', Runtime(engine._organism_source(child)).functions)
        restarted = Engine(engine.root, brain=FakeBrain([]), start_worker=False)
        self.addCleanup(restarted.shutdown)
        self.assertEqual(len(restarted.rows('SELECT * FROM proposals')), 1)
        self.assertEqual(restarted._organism_source(1), healthy)
        self.assertEqual(restarted._organism_source(child), healthy)
        self.assertGreaterEqual(len(restarted.rows('SELECT * FROM code_revisions')), 4)

    def test_authoritative_source_repairs_corrupted_or_missing_file_mirrors(self):
        engine, _ = self.make_engine([{'action': 'mutate', 'function': PARITY}])
        self.decide(engine)
        expected = engine._organism_source(1)
        path = engine.root / 'workspaces' / 'organism_1' / 'capabilities.py'
        corrupt = 'def risk_gate(energy, failures):\n    return "wrong"\n'
        path.write_text(corrupt, encoding='utf8')
        self.assertEqual(engine._organism_source(1), expected)
        self.assertEqual(path.read_text(encoding='utf8'), expected)
        self.assertIn(corrupt, [p.read_text(encoding='utf8') for p in path.parent.glob('quarantine_*.txt')])
        path.unlink()
        self.assertEqual(engine._organism_source(1), expected)
        self.assertEqual(path.read_text(encoding='utf8'), expected)

    def test_interrupted_mutation_rolls_back_activation_outcome_and_reward(self):
        engine, _ = self.make_engine([{'action': 'mutate', 'function': PARITY}])
        before = engine.store.one('SELECT * FROM organisms WHERE id=1')
        with patch.object(engine, '_record_episode', side_effect=RuntimeError('simulated interrupted completion')):
            with self.assertRaisesRegex(RuntimeError, 'simulated interrupted completion'):
                self.decide(engine)
        pending = engine.store.one('SELECT * FROM proposals')
        self.assertIsNotNone(pending, 'The proposed experiment must survive an interrupted completion')
        self.assertEqual(pending['outcome'], 'pending')
        self.assertEqual(pending['accepted'], 0)
        self.assertEqual(pending['reward'], 0)
        self.assertIsNone(pending['evaluation_json'])
        after = engine.store.one('SELECT * FROM organisms WHERE id=1')
        self.assertEqual(after['energy'], before['energy'])
        self.assertEqual(after['fitness'], before['fitness'])
        self.assertEqual(after['mutation_count'], 0)
        self.assertEqual(engine.store.one('SELECT source FROM organism_code WHERE organism=1')['source'], BASELINE)
        self.assertEqual(len(engine.rows('SELECT * FROM code_revisions')), 1)
        self.assertEqual(engine.rows('SELECT * FROM episodes'), [])
        # A readable mirror may have been written before rollback; the canonical
        # committed revision must repair it before any subsequent execution.
        self.assertEqual(engine._organism_source(1), BASELINE)
        path = engine.root / 'workspaces' / 'organism_1' / 'capabilities.py'
        self.assertEqual(path.read_text(encoding='utf8'), BASELINE)
        restarted = Engine(engine.root, brain=FakeBrain([]), start_worker=False)
        self.addCleanup(restarted.shutdown)
        recovered = restarted.store.one('SELECT * FROM proposals')
        self.assertIn('interrupted', recovered['outcome'])
        self.assertEqual(recovered['accepted'], 0)
        self.assertEqual(restarted.daily_tokens, 85)
        self.assertEqual(restarted._organism_source(1), BASELINE)


if __name__ == '__main__':
    unittest.main()
