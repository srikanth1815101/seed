"""Interpreter trust boundary and independent task evaluation checks."""
import math
import inspect
import unittest
from dataclasses import replace
from unittest import mock

from seed_core.safe_runtime import (CapabilityError, Runtime, canonical_fingerprint,
                                    merge_one, supported_features)
from seed_core.tasks import (TASKS, Task, TaskRegistry, evaluate,
                             evaluate_holdout, public_catalog)


class RuntimeTests(unittest.TestCase):
    def test_pure_numeric_builtins_and_helpers(self):
        source = ('def clamp_value(x, low, high):\n    return max(low, min(high, x))\n'
                  'def distance_1d(a, b):\n    return abs(a - b)\n'
                  'def helper(x):\n    return clamp_value(abs(x), 0, 10)\n')
        runtime = Runtime(source)
        self.assertEqual(runtime.call('clamp_value', -2, 0, 5), 0)
        self.assertEqual(runtime.call('clamp_value', 8, 0, 5), 5)
        self.assertEqual(runtime.call('distance_1d', -4, 8), 12)
        self.assertEqual(runtime.call('helper', -30), 10)
        self.assertEqual(evaluate(source, 'clamp_value')['score'], 1)
        self.assertEqual(evaluate_holdout(source, 'distance_1d')['score'], 1)
        self.assertIn('max', supported_features()['builtins'])
        zero = Runtime('def f(x):\n    return abs(x)').call('f', -0.0)
        self.assertEqual(math.copysign(1, zero), 1)

    def test_interpreter_does_not_use_host_exec_or_eval(self):
        runtime = Runtime('def distance_1d(a, b):\n    return abs(a - b)')
        with mock.patch('builtins.exec', side_effect=AssertionError('host exec')), \
                mock.patch('builtins.eval', side_effect=AssertionError('host eval')):
            self.assertEqual(runtime.call('distance_1d', 3, -2), 5)

    def test_unsupported_features_rejected_even_in_dead_code(self):
        statements = [
            'return open("private")', 'return __import__("os")',
            'return x.real', 'return x[0]', 'return [x]', 'return {x}',
            'return (x, x)', 'return 2 ** x', 'return 1 / x',
            'while x:\n            return 1', 'for y in x:\n            return 1',
            'def nested():\n            return 1', 'return lambda: x',
            'import os', 'return min(a=x, b=2)', 'return abs(*x)',
            'return', 'a = b = 1', 'return None', 'return 1j',
        ]
        for stmt in statements:
            with self.subTest(stmt=stmt), self.assertRaises(CapabilityError):
                Runtime('def candidate(x):\n    if False:\n        ' + stmt + '\n    return x')

    def test_bad_function_signatures_and_reserved_builtins(self):
        for source in ['def f(x=1):\n    return x',
                       'def f(x: int):\n    return x',
                       'def f(*x):\n    return 1',
                       'def f(_x):\n    return 1',
                       'def abs(x):\n    return x',
                       '@f\ndef f(x):\n    return x',
                       'def f(x):\n    return x\ndef f(x):\n    return x']:
            with self.subTest(source=source), self.assertRaises(CapabilityError):
                Runtime(source)

    def test_builtin_types_and_arity_are_strict(self):
        for expression in ['min(1)', 'abs(1, 2)', 'max(1,2,3,4,5,6,7,8)']:
            with self.subTest(expression=expression), self.assertRaises(CapabilityError):
                Runtime('def f():\n    return ' + expression)
        for expression in ['min(True, 2)', 'max("a", "z")', 'abs(False)']:
            with self.subTest(expression=expression), self.assertRaises(CapabilityError):
                Runtime('def f():\n    return ' + expression).call('f')
        self.assertEqual(Runtime('def f():\n    return min(4,3,2,1,0,-1,-2)').call('f'), -2)

    def test_scalar_and_arithmetic_resource_limits(self):
        runtime = Runtime('def f(x):\n    return x')
        class Sneaky(int):
            def __add__(self, other):
                raise AssertionError('user object executed')
        for value in [math.inf, -math.inf, math.nan, 10**100, 'x' * 201,
                      [], {}, object(), Sneaky(1)]:
            with self.subTest(kind=type(value).__name__), self.assertRaises(CapabilityError):
                runtime.call('f', value)
        for expression in ['100000000 * 100000000', '"a" * 100000000', '1 // 0', '1 % 0', 'True + 1']:
            with self.subTest(expression=expression), self.assertRaises(CapabilityError):
                Runtime('def f():\n    return ' + expression).call('f')

    def test_source_syntax_recursion_and_execution_budgets(self):
        with self.assertRaises(CapabilityError):
            Runtime(' ' * 20001)
        with self.assertRaises(CapabilityError):
            Runtime('def f():\n    return ' + '1+' * 100 + '1')
        with self.assertRaises(CapabilityError):
            Runtime('def f(x):\n    return f(x)').call('f', 1)
        # Exponential helper invocation stays shallow while exhausting fuel.
        source = 'def f0(x):\n    return x\n'
        for i in range(1, 8):
            source += f'def f{i}(x):\n    return f{i-1}(x) + f{i-1}(x)\n'
        with self.assertRaisesRegex(CapabilityError, 'execution budget'):
            Runtime(source).call('f7', 1)

    def test_local_variable_limit_and_short_circuit_semantics(self):
        source = 'def f(x):\n' + ''.join(f'    v{i} = {i}\n' for i in range(40)) + '    return x\n'
        with self.assertRaisesRegex(CapabilityError, 'local variable limit'):
            Runtime(source).call('f', 1)
        runtime = Runtime('def f(x):\n    return x or 7\ndef g(x):\n    return x and (1 // 0)')
        self.assertEqual(runtime.call('f', 3), 3)
        self.assertEqual(runtime.call('f', 0), 7)
        self.assertEqual(runtime.call('g', 0), 0)

    def test_merge_preserves_existing_helper_calls_and_rejects_invalid_merged_calls(self):
        source = 'def helper(x):\n    return abs(x)\n'
        proposal = 'def distance_1d(a, b):\n    return helper(a - b)\n'
        merged, name, operation = merge_one(source, proposal)
        self.assertEqual((name, operation), ('distance_1d', 'added'))
        self.assertEqual(Runtime(merged).call(name, -3, 7), 10)
        with self.assertRaises(CapabilityError):
            merge_one(source, 'def distance_1d(a, b):\n    return missing(a)')
        with self.assertRaises(CapabilityError):
            merge_one(merged, 'def helper(x, y):\n    return x + y')

    def test_ast_duplicate_identity_ignores_comments_and_whitespace(self):
        first = 'def parity_label(x):\n    return "even" if x % 2 == 0 else "odd"\n'
        second = '# another idea\ndef parity_label( x ):\n return "even" if x%2==0 else "odd"\n'
        self.assertEqual(canonical_fingerprint(first), canonical_fingerprint(second))
        with self.assertRaisesRegex(CapabilityError, 'identical'):
            merge_one(first, second)


class TaskRegistryTests(unittest.TestCase):
    def custom_task(self, **changes):
        task = Task('double_number', ('x',), 'Return two times x.',
                    (((2,), 4),), lambda x: x * 2,
                    lambda rng: (rng.randint(-10, 10),),
                    benchmarks=(((0,), 0), ((-10,), -20)))
        return replace(task, **changes)

    def test_validated_developer_registry_and_read_only_mapping(self):
        registry = TaskRegistry()
        task = self.custom_task()
        self.assertIs(registry.register(task), task)
        self.assertEqual(list(registry), ['double_number'])
        with self.assertRaises(TypeError):
            registry['double_number'] = task
        with self.assertRaisesRegex(ValueError, 'already registered'):
            registry.register(task)
        with self.assertRaises(TypeError):
            registry.register({'name': 'model_generated_task'})

    def test_registry_rejects_bad_contracts_and_mutated_expected_labels(self):
        invalid = [dict(name='_private'), dict(name='abs'), dict(args=('x', 'x')),
                   dict(description=''), dict(oracle=None), dict(generator=None),
                   dict(examples=()), dict(examples=(((2,), 100),)),
                   dict(benchmarks=(((0,), 1),)),
                   dict(generator=lambda rng: [1]),
                   dict(generator=lambda rng: ('too big' * 50,))]
        for changes in invalid:
            with self.subTest(changes=list(changes)), self.assertRaises((ValueError, CapabilityError)):
                TaskRegistry().register(self.custom_task(**changes))
        state = iter(range(100))
        with self.assertRaisesRegex(ValueError, 'reproducible'):
            TaskRegistry().register(self.custom_task(generator=lambda rng: (next(state),)))

    def test_new_developer_task_is_evaluated_without_engine_changes(self):
        # Isolated registry proves integration without changing the process-wide
        # registry used by unrelated simulation tests.
        registry = TaskRegistry()
        registry.register(self.custom_task())
        with mock.patch('seed_core.tasks.TASKS', registry):
            source = 'def double_number(x):\n    return x * 2'
            self.assertEqual(evaluate(source, 'double_number')['score'], 1)
            self.assertEqual(evaluate_holdout(source, 'double_number')['score'], 1)
            self.assertEqual(public_catalog()[0]['name'], 'double_number')
            self.assertNotIn('benchmarks', public_catalog()[0])
            self.assertNotIn('oracle', public_catalog()[0])

    def test_all_initial_task_oracles_executable_in_restricted_language(self):
        source = '\n'.join(inspect.getsource(task.oracle) for task in TASKS.values())
        for name in TASKS:
            with self.subTest(task=name):
                self.assertEqual(evaluate_holdout(source, name)['score'], 1)

    def test_public_example_cheating_fails_independent_holdout(self):
        source = ('def clamp_value(x, low, high):\n'
                  '    if x == 12 and low == 0 and high == 10:\n        return 10\n'
                  '    if x == -5 and low == 0 and high == 10:\n        return 0\n'
                  '    return 42\n')
        for args, expected in TASKS['clamp_value'].examples:
            self.assertEqual(Runtime(source).call('clamp_value', *args), expected)
        result = evaluate_holdout(source, 'clamp_value')
        self.assertLess(result['score'], .2)
        self.assertGreater(result['benchmark_cases'], 0)
        self.assertGreater(result['generated_cases'], 0)

    def test_boundary_benchmark_detects_near_miss(self):
        source = 'def temperature_band(t):\n    return "cold" if t <= 12 else ("hot" if t > 29 else "mild")'
        result = evaluate_holdout(source, 'temperature_band')
        self.assertLess(result['score'], 1)
        self.assertTrue(any('(12,)' in error or '(29,)' in error for error in result['errors']))

    def test_evaluation_reproducibility_types_and_nonempty_counts(self):
        source = 'def parity_label(x):\n    return "even"'
        self.assertEqual(evaluate_holdout(source, 'parity_label', seed=123),
                         evaluate_holdout(source, 'parity_label', seed=123))
        for count in [0, -1, 100000, True, 1.5]:
            with self.subTest(count=count), self.assertRaises(ValueError):
                evaluate(source, 'parity_label', count=count)
        with self.assertRaises(ValueError):
            evaluate(source, 'parity_label', seed='secret')
        result = evaluate('def majority_vote(a, b, c):\n    return True', 'majority_vote')
        self.assertEqual(result['score'], 0, 'booleans must not pass integer labels')


if __name__ == '__main__':
    unittest.main()
