"""Real API integration checks with isolated state and no Ollama requests."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

from fastapi.testclient import TestClient

from app import create_app
from seed_core.engine import Engine

PROJECT = Path(__file__).resolve().parents[1]


class NoBrain:
    def generate(self, messages):
        raise AssertionError('These API checks must not request Ollama')


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        shutil.copyfile(PROJECT / 'config.json', self.root / 'config.json')
        (self.root / 'static').mkdir()
        (self.root / 'static' / 'index.html').write_text('<html>AI Seed 2</html>', encoding='utf8')
        self.engine = Engine(self.root, brain=NoBrain(), start_worker=False)
        self.client = TestClient(create_app(self.root, self.engine), base_url='http://127.0.0.1:8765')
        self.client.__enter__()

    def tearDown(self):
        self.client.__exit__(None, None, None)
        self.engine.shutdown()
        self.tmp.cleanup()

    def post(self, command, **kwargs):
        return self.client.post('/api/control', json={'command': command}, **kwargs)

    def test_control_lifecycle_and_real_source(self):
        self.assertEqual(self.client.get('/api/health').json()['ok'], True)
        self.assertEqual(self.client.get('/api/status').json()['state'], 'PAUSED')
        response = self.post('start', headers={'Origin': 'http://127.0.0.1:8765'})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()['state'], 'RUNNING')
        org = self.client.get('/api/organisms').json()[0]
        source = self.client.get('/api/source/' + str(org['id'])).json()
        self.assertIn('def risk_gate', source['source'])
        self.assertEqual(source['task_scores']['risk_gate'], 1)
        self.assertTrue(self.client.get('/api/brain-context/' + str(org['id'])).json()['identity'])
        self.assertEqual(self.post('pause').json()['state'], 'PAUSED')
        self.assertEqual(self.post('resume').json()['state'], 'RUNNING')
        self.assertEqual(self.post('stop').json()['state'], 'STOPPED')
        self.assertEqual(self.post('nonsense').status_code, 400)
        self.assertEqual(self.client.get('/api/source/99999').status_code, 404)
        self.assertEqual(self.client.get('/api/traces/99999').status_code, 404)
        self.assertEqual(self.client.get('/api/proposals/99999').status_code, 404)

    def test_local_boundary_rejects_drive_by_control(self):
        for origin in ('https://evil.example', 'http://127.0.0.1:9999', 'null', 'http://localhost:8765'):
            response = self.post('start', headers={'Origin': origin})
            self.assertEqual(response.status_code, 403, origin)
        self.assertEqual(self.post('start', headers={'Host': 'evil.example'}).status_code, 403)
        self.assertEqual(self.post('start', headers={'Host': '127.0.0.1.evil.example'}).status_code, 403)
        self.assertEqual(self.post('start', headers={'Sec-Fetch-Site': 'cross-site'}).status_code, 403)
        self.assertEqual(self.client.post('/api/control', data={'command': 'start'}).status_code, 415)
        self.assertEqual(self.post('start', headers={'Content-Length': '20000'}).status_code, 413)
        self.assertFalse(self.engine.rows('SELECT id FROM organisms'))

    def test_read_endpoints_and_student_are_truthful(self):
        for endpoint in ('/', '/api/status', '/api/organisms', '/api/events', '/api/proposals',
                         '/api/episodes', '/api/trials', '/api/student', '/api/tasks', '/api/project', '/api/traces'):
            response = self.client.get(endpoint)
            self.assertEqual(response.status_code, 200, endpoint)
            self.assertEqual(response.headers['x-content-type-options'], 'nosniff')
        self.assertFalse(self.client.get('/api/student').json()['stats']['trained'])
        answer = self.client.post('/api/chat', json={'question': 'Can you speak?', 'brain': 'student'})
        self.assertEqual(answer.status_code, 200)
        self.assertIn('risk_gate', answer.json()['caveat'])
        self.assertEqual(self.client.post('/api/chat', json={'question': 'x', 'brain': 'unknown'}).status_code, 400)
        self.assertEqual(self.client.get('/api/project/file', params={'path': '../private.txt'}).status_code, 400)
        self.assertEqual(self.client.get('/api/project/file', params={'path': 'data/seed2.db'}).status_code, 400)

    def test_factory_creates_worker_only_inside_lifespan(self):
        owned = create_app(self.root)
        self.assertFalse(hasattr(owned.state, 'engine'))
        with TestClient(owned, base_url='http://127.0.0.1:8765') as client:
            self.assertEqual(client.get('/api/status').json()['state'], 'PAUSED')
            self.assertFalse(owned.state.engine.stop_flag.is_set())
        self.assertTrue(owned.state.engine.stop_flag.is_set())

    def test_launcher_help_does_not_depend_on_working_directory(self):
        result = subprocess.run([sys.executable, str(PROJECT / 'seed.py'), '--help'], cwd=self.root,
                                capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('--check', result.stdout)

    def test_launcher_explains_incomplete_dependency_install(self):
        result = subprocess.run([sys.executable, '-S', str(PROJECT / 'seed.py')], cwd=self.root,
                                capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 1)
        self.assertIn('Dependency installation is incomplete', result.stderr)
        self.assertIn('uvicorn', result.stderr)
        self.assertIn('requirements.lock.txt', result.stderr)
        self.assertNotIn('Traceback', result.stderr)


if __name__ == '__main__':
    unittest.main()
