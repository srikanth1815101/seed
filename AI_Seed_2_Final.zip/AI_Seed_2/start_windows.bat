@echo off
setlocal
cd /d "%~dp0"
if not defined SEED_PYTHON set "SEED_PYTHON=python"
if not exist ".venv\Scripts\python.exe" (
  "%SEED_PYTHON%" -m venv .venv
  if errorlevel 1 goto :failed
)
".venv\Scripts\python.exe" -m pip install -r requirements.lock.txt
if errorlevel 1 goto :failed
".venv\Scripts\python.exe" seed.py
if errorlevel 1 goto :failed
pause
exit /b 0
:failed
echo Could not start AI Seed 2. Install 64-bit Python 3.12+ and check the error above.
echo You may set SEED_PYTHON to your full Python executable path, or run Python directly.
echo If Windows blocks this BAT file, use the direct Python commands in README.md.
pause
exit /b 1
