"""Loopback-only dashboard API; importing this module starts no worker."""
from contextlib import asynccontextmanager
import ipaddress
from pathlib import Path
from urllib.parse import urlsplit

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field

from seed_core.engine import Engine

ROOT = Path(__file__).resolve().parent


class Control(BaseModel):
    command: str = Field(min_length=1, max_length=20)


class Chat(BaseModel):
    question: str = Field(min_length=1, max_length=1500)
    brain: str = 'qwen'


def _loopback(host):
    if host == 'localhost':
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _authority(value):
    """Normalize an HTTP authority without allowing credentials or paths."""
    try:
        parsed = urlsplit('//' + value)
        if (not parsed.hostname or parsed.username is not None or parsed.password is not None
                or parsed.path or parsed.query or parsed.fragment):
            return None
        return parsed.hostname.lower(), parsed.port
    except ValueError:
        return None


def create_app(root=ROOT, engine=None):
    root = Path(root).resolve()

    @asynccontextmanager
    async def lifespan(application):
        # An injected engine belongs to its caller; the normal server owns its worker.
        if engine is None:
            application.state.engine = Engine(root, start_worker=True)
        try:
            yield
        finally:
            if engine is None:
                application.state.engine.shutdown()

    application = FastAPI(title='AI Seed 2 - Persistent Evolution Lab', lifespan=lifespan)
    if engine is not None:
        application.state.engine = engine

    @application.middleware('http')
    async def local_requests(request: Request, call_next):
        authority = _authority(request.headers.get('host', ''))
        if authority is None or not _loopback(authority[0]):
            return JSONResponse({'detail': 'Use a loopback host for this local application'}, status_code=403)
        if request.method in ('POST', 'PUT', 'PATCH', 'DELETE'):
            origin = request.headers.get('origin')
            if origin:
                try:
                    parsed = urlsplit(origin)
                    expected = (request.url.scheme, authority[0], authority[1] or (443 if request.url.scheme == 'https' else 80))
                    actual = (parsed.scheme, parsed.hostname, parsed.port or (443 if parsed.scheme == 'https' else 80))
                    valid_origin = (actual == expected and not parsed.username and not parsed.password
                                    and not parsed.path and not parsed.query and not parsed.fragment)
                except ValueError:
                    valid_origin = False
                if not valid_origin:
                    return JSONResponse({'detail': 'Cross-origin control requests are not allowed'}, status_code=403)
            if request.headers.get('sec-fetch-site', '').lower() == 'cross-site':
                return JSONResponse({'detail': 'Cross-site control requests are not allowed'}, status_code=403)
            if request.headers.get('content-type', '').split(';', 1)[0].strip().lower() != 'application/json':
                return JSONResponse({'detail': 'Control requests require application/json'}, status_code=415)
            try:
                size = int(request.headers.get('content-length', '0'))
            except ValueError:
                return JSONResponse({'detail': 'Invalid request size'}, status_code=400)
            if size < 0 or size > 16384:
                return JSONResponse({'detail': 'Request is too large'}, status_code=413)
        response = await call_next(request)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Cache-Control'] = 'no-store'
        return response

    def current():
        return application.state.engine

    @application.get('/')
    def home():
        return FileResponse(root / 'static' / 'index.html')

    @application.get('/api/health')
    def health():
        instance = current()
        instance.store.one('SELECT 1 AS ok')
        return {'ok': True, 'state': instance.state, 'workflow': 'local evolution lab'}

    @application.get('/api/status')
    def status():
        return current().status()

    @application.get('/api/organisms')
    def organisms():
        return current().rows('SELECT * FROM organisms ORDER BY id DESC LIMIT 100')

    @application.get('/api/events')
    def events():
        return current().rows('SELECT * FROM events ORDER BY id DESC LIMIT 100')

    @application.get('/api/proposals')
    def proposals():
        return current().rows('SELECT id,ts,organism,action,task,function_name,fingerprint,intent,outcome,reason,accepted,cost,reward,train_before,holdout_before,train_after,holdout_after,trace_id '
                              'FROM proposals ORDER BY id DESC LIMIT 120')

    @application.get('/api/proposals/{proposal_id}')
    def proposal(proposal_id: int):
        result = current().store.one('SELECT * FROM proposals WHERE id=?', (proposal_id,))
        if not result:
            raise HTTPException(404, 'Experiment not found')
        return result

    @application.get('/api/episodes')
    def episodes():
        return current().rows('SELECT id,ts,organism,cycle,action,outcome,lesson,energy_delta,proposal_id FROM episodes ORDER BY id DESC LIMIT 100')

    @application.get('/api/trials')
    def trials():
        return current().rows('SELECT * FROM trials ORDER BY id DESC LIMIT 50')

    @application.get('/api/student')
    def student():
        return {'stats': current().student.stats(), 'models': current().rows('SELECT * FROM models ORDER BY id DESC LIMIT 15')}

    @application.get('/api/tasks')
    def tasks():
        from seed_core.tasks import public_catalog
        return public_catalog()

    @application.get('/api/source/{oid}')
    def source(oid: int):
        instance = current()
        if not instance.store.one('SELECT id FROM organisms WHERE id=?', (oid,)):
            raise HTTPException(404, 'Organism does not exist')
        from seed_core.tasks import scores
        source_text = instance._organism_source(oid)
        return {'organism': oid, 'source': source_text, 'task_scores': scores(source_text)}

    @application.get('/api/project')
    def project():
        return current().index.manifest()

    @application.get('/api/project/file')
    def project_file(path: str):
        try:
            return {'path': path, 'content': current().index.read(path)}
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @application.get('/api/traces')
    def traces():
        return current().rows('SELECT id,ts,organism,purpose,tokens,validation,error FROM traces ORDER BY id DESC LIMIT 75')

    @application.get('/api/traces/{trace_id}')
    def trace(trace_id: int):
        result = current().store.one('SELECT * FROM traces WHERE id=?', (trace_id,))
        if not result:
            raise HTTPException(404, 'Trace not found')
        return result

    @application.get('/api/brain-context/{oid}')
    def context(oid: int):
        organism = current().store.one('SELECT * FROM organisms WHERE id=?', (oid,))
        if not organism:
            raise HTTPException(404, 'Organism not found')
        return current().observation(organism, include_inspections=False)

    @application.post('/api/control')
    def control(cmd: Control):
        try:
            return {'state': current().control(cmd.command)}
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @application.post('/api/chat')
    def chat(x: Chat):
        if x.brain not in ('qwen', 'student'):
            raise HTTPException(400, 'Unknown brain')
        try:
            return current().chat(x.question, x.brain)
        except (ConnectionError, RuntimeError, ValueError) as exc:
            raise HTTPException(503, str(exc)) from exc

    return application


app = create_app()
