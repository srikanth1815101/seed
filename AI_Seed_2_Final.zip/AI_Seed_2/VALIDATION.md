# Verified release results

Validated on Linux x86_64 with Python 3.11.17 / NumPy 2.4.6 and Python 3.12.14 / NumPy 2.5.4 on 24 October 2026.

| Check | Actual outcome |
| --- | --- |
| Original tests before development | 8 passed |
| Full final unit/integration suite | 86 passed on each Python version; 0 failed; 0 skipped |
| Dependency consistency (`python -m pip check`) | No broken requirements |
| Offline evolutionary demonstration | 4 accepted task improvements; 3 rejected mutations |
| Neural model training | Real NumPy MLP; 98.98% validation; 97.38% reserved-audit accuracy |
| Weaker model candidate | Rejected; champion checkpoint retained |
| Learned policy execution after training | 5/5 sampled independent risk challenges correct |
| Persisted history, inheritance, checkpoint reload | Passed |
| HTTP server | Dashboard, health/status, source scorecard and start/pause/resume/stop passed |
| Included trained example | Correct explore(90,0) and conserve(10,5) predictions |
| Windows dependency availability | Binary wheels resolved for Python 3.11 and 3.12 win_amd64 |
| Windows runtime | Not executed |
| Live Ollama/Qwen | Not executed; local Ollama unavailable |

Run from the project root:

```text
python -m unittest discover -s tests -v
python scripts/offline_demo.py --output NEW_OUTPUT_DIRECTORY
python scripts/predict_student.py --energy 90 --failures 0
```

Use the project's virtual environment interpreter as documented in README.md.
`validation/offline_report.json` contains the measured demonstration details;
`validation/release_checks.json` contains release check metadata.

The demo uses scripted mock proposals and reported inference usage. Execution,
evaluation, data storage, inheritance, neural training and promotion are real.
Synthetic risk-task data has 1,359 unique inputs, partitioned into 971 training,
197 validation and 191 audit examples. The audit set is excluded from gradient
updates and promotion; repeated diagnostic access can still introduce research
bias. The model learns one bounded classification policy. It does not train a
general language model or improve Qwen's weights.

The cloud configuration draft saves tested install_script and start_skill fields.
Review and save those fields in environment settings, then publish to snapshot
this prepared environment. New-task restoration and publication were not tested.

## Python 3.11 installation correction

The original ZIP pinned NumPy 2.5.4, requiring Python 3.12. The corrected lock file selects NumPy 2.4.6 on Python 3.11 and retains 2.5.4 on Python 3.12. The launcher now reports incomplete dependency installation before starting the server. A regression test runs the launcher without site packages to verify that a failed install yields repair instructions instead of a uvicorn traceback.
