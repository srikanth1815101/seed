"""Start the local dashboard: python seed.py [--check]."""
import argparse
import importlib.metadata
import ipaddress
import json
from pathlib import Path
import sys
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parent


def loopback(host):
    if host == 'localhost':
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def check(config):
    """Read-only diagnostics: never download a model or start evolution."""
    ok = True
    print(f'Project: {ROOT}')
    print(f'Python: {sys.version.split()[0]}')
    for name in ('fastapi', 'uvicorn', 'numpy', 'psutil'):
        try:
            print(f'{name}: {importlib.metadata.version(name)}')
        except importlib.metadata.PackageNotFoundError:
            print(f'{name}: missing; install requirements.lock.txt')
            ok = False
    print(f'Dashboard: {config["host"]}:{config["port"]}; starts paused')
    url = config['ollama_url'].rstrip('/') + '/api/tags'
    try:
        # Local Ollama must bypass any inherited corporate HTTP proxy.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(url, timeout=5) as response:
            payload = response.read(1024 * 1024 + 1)
        if len(payload) > 1024 * 1024:
            raise ValueError('Ollama model listing exceeded diagnostic limit')
        models = json.loads(payload).get('models', [])
        found = any(item.get('name') == config['model'] or item.get('model') == config['model'] for item in models)
        print(f'Ollama reachable; {config["model"]}: {"available" if found else "not installed"}')
        if not found:
            print(f'Install explicitly with: ollama pull {config["model"]}')
            ok = False
    except (OSError, ValueError, urllib.error.URLError) as exc:
        print(f'Ollama not ready: {exc}')
        print('Start Ollama locally before live code generation. Offline tests/demo still work.')
        ok = False
    return 0 if ok else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='read-only dependency and Ollama readiness checks')
    args = parser.parse_args(argv)
    if sys.version_info < (3, 11):
        parser.error('AI Seed requires Python 3.11 or newer; recreate .venv using a supported interpreter')
    if sys.maxsize <= 2**32:
        parser.error('AI Seed requires 64-bit Python; recreate .venv using a 64-bit interpreter')
    try:
        config = json.loads((ROOT / 'config.json').read_text(encoding='utf-8'))
        if not loopback(config['host']):
            raise ValueError('host must be a loopback address (127.0.0.1, ::1, or localhost)')
        if type(config['port']) is not int or not 1 <= config['port'] <= 65535:
            raise ValueError('port must be an integer from 1 to 65535')
        if config.get('auto_start', False):
            raise ValueError('Set auto_start to false; use dashboard Start after reviewing the configuration')
    except (OSError, ValueError, KeyError) as exc:
        parser.error(f'Invalid config.json: {exc}')
    if args.check:
        return check(config)
    missing = []
    for package in ('fastapi', 'uvicorn', 'numpy', 'psutil'):
        try:
            importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            missing.append(package)
    if missing:
        print('Dependency installation is incomplete. Missing: ' + ', '.join(missing), file=sys.stderr)
        print('Install all dependencies before starting AI Seed:', file=sys.stderr)
        print(f'"{sys.executable}" -m pip install -r "{ROOT / "requirements.lock.txt"}"', file=sys.stderr)
        return 1
    import uvicorn
    from app import create_app
    host = f'[{config["host"]}]' if ':' in config['host'] else config['host']
    print(f'AI Seed 2: http://{host}:{config["port"]}')
    print('Open the dashboard and click Start. Ctrl+C stops the server; data is retained.')
    uvicorn.run(create_app(ROOT), host=config['host'], port=config['port'], reload=False, workers=1)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
