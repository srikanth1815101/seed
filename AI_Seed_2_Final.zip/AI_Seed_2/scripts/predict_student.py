"""Run a trained risk policy; this model does not generate language."""
import argparse
import json
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from seed_core.db import Store
from seed_core.student import NeuralStudent


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model-dir', type=Path, default=ROOT / 'validation' / 'trained_policy')
    parser.add_argument('--energy', type=float, required=True)
    parser.add_argument('--failures', type=int, required=True)
    args = parser.parse_args(argv)
    if not args.model_dir.is_dir():
        parser.error('Model directory does not exist; train a student or use the included example')
    # Inference uses an ephemeral store and never changes your lab history.
    with tempfile.TemporaryDirectory() as directory:
        model = NeuralStudent(args.model_dir, Store(Path(directory) / 'inference.db'))
        result = model.predict(args.energy, args.failures)
        print(json.dumps({'task': 'risk_gate', **result}, indent=2))
    return 0 if result.get('ready') else 1


if __name__ == '__main__':
    raise SystemExit(main())
