"""Reproducible offline evidence: scripted proposals, real evaluation and training.

This does not generate code with Ollama. The mock brain intentionally supplies
known proposals so failures in the closed feedback loop can be reproduced. The
interpreter, evaluator, SQLite, inheritance and NumPy training are the real ones.
Run from any directory with: python scripts/offline_demo.py --output NEW_FOLDER
"""
import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from seed_core.engine import Engine  # noqa: E402
from seed_core.student import NeuralStudent  # noqa: E402
from seed_core.tasks import evaluate, risk_gate, scores  # noqa: E402


CLAMP = 'def clamp_value(x, low, high):\n    return max(min(x, high), low)\n'
PARITY = 'def parity_label(x):\n    return "even" if x % 2 == 0 else "odd"\n'
BUDGET = 'def budget_left(income, expenses, reserve):\n    return max(0, income - expenses - reserve)\n'
DISTANCE = 'def distance_1d(a, b):\n    return abs(a - b)\n'


def _action(action, **fields):
    return {'action': action, 'hypothesis': 'Deterministic offline integration case',
            'learning': 'Use the evaluator result in the next decision.', **fields}


def scripted_responses():
    """Includes a repaired malformed response and two AST-equivalent duplicates."""
    return [
        _action('inspect', paths=['seed_core/tasks.py']),
        _action('mutate', function=CLAMP),  # Task inference is deliberately tested.
        _action('mutate', task='clamp_value', function=CLAMP.replace('max(min', 'max( min')),
        _action('mutate', task='clamp_value', function=CLAMP),
        _action('mutate', task='temperature_band',
                function='def temperature_band(t):\n    return open("DO_NOT_OPEN")\n'),
        'this is deliberately malformed JSON',
        _action('reflect', learning='Repair returned valid JSON; forbidden I/O stays rejected.'),
        _action('mutate', task='parity_label', function=PARITY),
        _action('mutate', task='budget_left', function=BUDGET),
        _action('mutate', task='distance_1d', function=DISTANCE),
        _action('reflect', learning='Four measured capabilities improved; do not repeat solved code.'),
    ]


class ScriptedBrain:
    """No network calls and no claim of autonomous language-model reasoning."""
    def __init__(self, responses):
        self.responses = list(responses)
        self.messages = []
        self.position = 0

    @property
    def remaining(self):
        return len(self.responses) - self.position

    def generate(self, messages):
        if not self.remaining:
            raise RuntimeError('Unexpected extra inference: offline script is exhausted')
        self.messages.append(messages)
        answer = self.responses[self.position]
        self.position += 1
        # Usage is mocked too. Real execution/training metrics are measured below.
        return answer if isinstance(answer, str) else json.dumps(answer), 65


def _check(condition, message):
    if not condition:
        raise AssertionError(message)


def _prepare_output(path):
    output = Path(path).expanduser()
    if output.is_symlink():
        raise ValueError('Output must not be a symlink')
    output = output.resolve()
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        raise ValueError('Choose a new or empty output directory; existing data will not be overwritten')
    output.mkdir(parents=True, exist_ok=True)
    config = json.loads((PROJECT_ROOT / 'config.json').read_text(encoding='utf8'))
    config.update(auto_start=False, max_population=2, initial_energy=140.0,
                  birth_energy=145.0, max_age=10000, brain_every_cycles=1,
                  max_ram_percent=101, max_cpu_percent=101,
                  daily_calls_limit=len(scripted_responses()), daily_token_limit=100000,
                  model_train_every_samples=100000, min_inference_interval_seconds=0,
                  inference_interval_seconds=0, inference_error_backoff_seconds=0)
    (output / 'config.json').write_text(json.dumps(config, indent=2), encoding='utf8')
    (output / 'seed_core').mkdir()
    for source in (PROJECT_ROOT / 'seed_core').glob('*.py'):
        shutil.copyfile(source, output / 'seed_core' / source.name)
    (output / 'README.md').write_text(
        'Offline integration artifacts. Brain proposals and token usage are mocked.\n'
        'Trials, benchmarks, SQLite persistence and NumPy MLP training are real.\n'
        'Oracle-generated risk_gate examples are synthetic benchmark data.\n', encoding='utf8')
    return output


def run_demo(output_path):
    """Run assertions and persist evidence; raises on failure, never erases data."""
    output = _prepare_output(output_path)
    brain = ScriptedBrain(scripted_responses())
    engine = Engine(output, brain=brain, start_worker=False)
    engine.random.seed(20261024)
    try:
        engine.control('start')
        founder = engine.rows('SELECT * FROM organisms ORDER BY id LIMIT 1')[0]
        oid = founder['id']
        initial_scores = scores(engine._organism_source(oid))
        # Use the production decision method; only inference transport is mocked.
        while brain.remaining:
            previous_position = brain.position
            engine._decide(engine.store.one('SELECT * FROM organisms WHERE id=?', (oid,)))
            _check(brain.position > previous_position,
                   f'Decision made no progress: {engine.last_error or engine.activity}')
        proposals = engine.rows('SELECT * FROM proposals ORDER BY id')
        accepted = [row for row in proposals if row['accepted'] and row['action'] == 'mutate']
        improved_tasks = sorted(row['task'] for row in accepted)
        _check(improved_tasks == ['budget_left', 'clamp_value', 'distance_1d', 'parity_label'],
               f'Expected four verified improvements, observed {improved_tasks}')
        for row in accepted:
            _check(row['train_after'] > row['train_before'], 'Training did not improve')
            _check(row['holdout_after'] > row['holdout_before'], 'Holdout did not improve')
            _check(row['reward'] > row['cost'], 'Accepted improvement had no energy surplus')
        rejected_mutations = [row for row in proposals if row['action'] == 'mutate' and not row['accepted']]
        _check(len(rejected_mutations) == 3, 'Expected two duplicates and one forbidden operation')
        _check(all(row['reward'] == 0 for row in rejected_mutations), 'Rejected mutation received reward')
        duplicate_rows = [row for row in rejected_mutations if row['task'] == 'clamp_value']
        _check(len(duplicate_rows) == 2, 'AST-equivalent duplicate was not recognized')
        _check(max(len(row['reason']) for row in duplicate_rows) < 400,
               'Duplicate rejection reason grew unexpectedly')
        inspection_context = json.loads(brain.messages[1][1]['content'])
        _check('seed_core/tasks.py' in inspection_context.get('requested_file_contents', {}),
               'Inspected file did not appear in the following decision')
        final_context = json.loads(brain.messages[-1][1]['content'])
        _check(bool(final_context.get('memory', {}).get('last_proposals')),
               'Actual previous outcomes were absent from later context')
        traces = engine.rows('SELECT purpose FROM traces ORDER BY id')
        _check(any(row['purpose'] == 'json_repair' for row in traces), 'Malformed response was not repaired')
        final_source = engine._organism_source(oid)
        for task in improved_tasks:
            _check(evaluate(final_source, task, seed=30819, count=80)['score'] == 1,
                   f'Independent benchmark failed for {task}')

        # Reproduction uses ordinary energy/fitness gates with the demo config.
        engine._death_and_birth(oid)
        children = engine.rows('SELECT * FROM organisms WHERE parent=?', (oid,))
        _check(bool(children), 'Successful founder did not reproduce')
        child = children[0]
        _check(engine._organism_source(child['id']) == final_source,
               'Descendant failed to inherit activated capabilities')

        # Real simulator cycles exercise activated functions, with inference exhausted.
        for _ in range(40):
            engine.step()
        actual_trials = engine.rows('SELECT task,correct,actor FROM trials')
        used_tasks = sorted({row['task'] for row in actual_trials if row['correct']})
        _check(set(improved_tasks).issubset(used_tasks),
               f'Not all newly learned functions were used successfully: {used_tasks}')
        observed_examples = engine.store.one('SELECT COUNT(*) AS n FROM student_examples')['n']

        # Synthetic, independently oracle-labeled benchmark dataset. These labels
        # are not invented by the mock brain or inferred from candidate claims.
        with engine.store.connect() as conn:
            conn.executemany('INSERT INTO student_examples(energy,failures,label) VALUES(?,?,?)',
                             ((energy, failures, int(risk_gate(energy, failures) == 'explore'))
                              for energy in range(151) for failures in range(9)))
        champion = engine.student.train_candidate(hidden1=16, hidden2=12,
                                                 learning_rate=.05, epochs=160)
        _check(champion.get('trained') and champion.get('promoted'), 'Neural candidate did not train/promote')
        _check(champion['accuracy'] >= .90, 'Neural validation accuracy is below 90%')
        _check(champion.get('audit_accuracy', 0) >= .85, 'Neural independent audit accuracy is below 85%')
        checkpoint = output / 'models' / 'student_policy.npz'
        champion_digest = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
        weak = engine.student.train_candidate(hidden1=4, hidden2=4, learning_rate=.001, epochs=10)
        _check(weak.get('trained') and not weak.get('promoted'), 'Weaker candidate replaced champion')
        _check(weak['accuracy'] < champion['accuracy'], 'Intended weaker candidate was not worse')
        _check(hashlib.sha256(checkpoint.read_bytes()).hexdigest() == champion_digest,
               'Rejected candidate altered the champion checkpoint')
        reloaded_student = NeuralStudent(output / 'models', engine.store)
        _check(reloaded_student.predict(90, 0)['prediction'] == 'explore', 'Reloaded model failed explore example')
        _check(reloaded_student.predict(10, 5)['prediction'] == 'conserve', 'Reloaded model failed conserve example')

        # Production _experience independently evaluates student outputs and logs actor.
        for _ in range(100):
            engine.cycle_number += 1
            current = engine.store.one('SELECT * FROM organisms WHERE id=?', (oid,))
            engine._experience(current)
        neural_trials = engine.rows("SELECT correct FROM trials WHERE actor='trained_neural_student'")
        _check(bool(neural_trials), 'Promoted student never executed a real evaluated challenge')

        engine.control('pause')
        cycle_before_pause = engine.cycle_number
        engine.step()
        _check(engine.cycle_number == cycle_before_pause, 'Pause did not stop the simulation cycle')
        engine.control('resume')
        engine.control('stop')
        count_before_restart = engine.store.one('SELECT COUNT(*) AS n FROM proposals')['n']
        engine.shutdown()
        reopened = Engine(output, brain=ScriptedBrain([]), start_worker=False)
        try:
            _check(reopened.store.one('SELECT COUNT(*) AS n FROM proposals')['n'] == count_before_restart,
                   'Proposal history was lost after restart')
            _check(reopened._organism_source(oid) == final_source, 'Activated source was lost after restart')
            _check(reopened.student.predict(90, 0)['ready'], 'Student checkpoint was lost after restart')
            _check(reopened.state == 'PAUSED', 'Restart should begin paused')
        finally:
            reopened.shutdown()

        report = {
            'status': 'passed', 'brain': 'scripted mock; no live Ollama calls',
            'mocked': ['proposal generation', 'reported inference token usage'],
            'real': ['restricted execution', 'training and holdout benchmarks', 'energy accounting',
                     'SQLite feedback memory', 'inherited code', 'later task execution',
                     'NumPy neural training', 'model promotion and persistence'],
            'scripted_brain_calls': len(brain.messages),
            'simulator_cycles': 40, 'post_training_challenges': 100,
            'accepted_mutations': len(accepted), 'rejected_mutations': len(rejected_mutations),
            'improved_tasks': improved_tasks, 'initial_scores': initial_scores,
            'final_scores': scores(final_source), 'descendant': child['id'],
            'feedback_in_later_context': True, 'inspected_file_in_next_context': True,
            'malformed_reply_repaired': True, 'history_survived_restart': True,
            'dataset': {'observed_risk_trials_before_training': observed_examples,
                        'added_oracle_benchmark_examples': 151 * 9,
                        'provenance': 'Synthetic risk_gate task oracle; not human data or LLM training data'},
            'student_champion': champion, 'weaker_candidate': weak,
            'student_independent_trials': len(neural_trials),
            'student_independent_correct': sum(row['correct'] for row in neural_trials),
            'checkpoint_sha256': champion_digest,
            'limitations': ['No live Ollama/Qwen inference was performed.',
                            'Scripted proposals demonstrate the engine, not autonomous discovery.',
                            'The learned model is a risk_gate classifier, not a new general language model.',
                            'Repeated validation selection may overfit; audit accuracy is diagnostic.'],
        }
        (output / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False), encoding='utf8')
        return report
    finally:
        engine.shutdown()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, help='New or empty directory for independent demo artifacts')
    args = parser.parse_args(argv)
    try:
        report = run_demo(args.output)
    except (AssertionError, OSError, ValueError, RuntimeError) as exc:
        print(f'Offline demonstration failed: {exc}', file=sys.stderr)
        return 1
    print(json.dumps({'status': report['status'], 'improved_tasks': report['improved_tasks'],
                      'student_validation_accuracy': report['student_champion']['accuracy'],
                      'student_audit_accuracy': report['student_champion'].get('audit_accuracy'),
                      'brain': report['brain'], 'report': str(Path(args.output).resolve() / 'report.json')}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
