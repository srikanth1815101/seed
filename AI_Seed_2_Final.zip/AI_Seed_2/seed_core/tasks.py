"""Reproducible skill challenges: examples are public; hidden tests are withheld.

These are local sandbox tasks, not real-world claims of intelligence.
"""
import random
import threading
from collections.abc import Mapping
from dataclasses import dataclass
from .safe_runtime import Runtime, CapabilityError, _scalar


@dataclass(frozen=True)
class Task:
    name: str
    args: tuple
    description: str
    examples: tuple
    oracle: object
    generator: object
    benchmarks: tuple = ()


def risk_gate(energy, failures):
    return 'conserve' if energy < 25 or failures >= 3 else 'explore'


def clamp_value(x, low, high):
    return max(low, min(high, x))


def parity_label(x):
    return 'even' if x % 2 == 0 else 'odd'


def budget_left(income, expenses, reserve):
    return max(0, income - expenses - reserve)


def temperature_band(t):
    return 'cold' if t < 12 else ('hot' if t >= 29 else 'mild')


def majority_vote(a, b, c):
    return 1 if a + b + c >= 2 else 0


def distance_1d(a, b):
    return abs(a - b)


def triangle_kind(a, b, c):
    if min(a, b, c) <= 0 or a + b <= c or b + c <= a or a + c <= b:
        return 'invalid'
    if a == b == c:
        return 'equilateral'
    return 'isosceles' if a == b or b == c or a == c else 'scalene'


def gen_risk(rng):
    return (rng.randint(0, 150), rng.randint(0, 8))


def gen_clamp(rng):
    low = rng.randint(-60, 40)
    return (rng.randint(-120, 120), low, low + rng.randint(1, 100))


def gen_parity(rng):
    return (rng.randint(-500, 500),)


def gen_budget(rng):
    return (rng.randint(0, 250), rng.randint(0, 300), rng.randint(0, 150))


def gen_temp(rng):
    return (rng.randint(-30, 65),)


def gen_vote(rng):
    return tuple(rng.randint(0, 1) for _ in range(3))


def gen_distance(rng):
    return (rng.randint(-150, 150), rng.randint(-150, 150))


def gen_triangle(rng):
    if rng.random() < 0.20:
        a = rng.randint(1, 30)
        return (a, a, a)
    if rng.random() < 0.25:
        a, b = rng.randint(1, 50), rng.randint(1, 50)
        return (a, a, b)
    return tuple(rng.randint(-2, 55) for _ in range(3))


_INITIAL_TASKS = (
    Task('risk_gate', ('energy', 'failures'), 'When energy is below 25 or failures >=3 return conserve; otherwise explore.',
         (((10, 0), 'conserve'), ((70, 1), 'explore'), ((90, 4), 'conserve')), risk_gate, gen_risk),
    Task('clamp_value', ('x', 'low', 'high'), 'Clamp x to inclusive low..high.',
         (((12, 0, 10), 10), ((-5, 0, 10), 0)), clamp_value, gen_clamp),
    Task('parity_label', ('x',), 'Return even for divisible-by-2 integers, otherwise odd.',
         (((4,), 'even'), ((-3,), 'odd')), parity_label, gen_parity),
    Task('budget_left', ('income', 'expenses', 'reserve'), 'Remaining budget after expenses and reserve; never below zero.',
         (((100, 20, 15), 65), ((20, 30, 5), 0)), budget_left, gen_budget),
    Task('temperature_band', ('t',), 'Return cold if t<12, hot if t>=29, otherwise mild.',
         (((-3,), 'cold'), ((21,), 'mild'), ((32,), 'hot')), temperature_band, gen_temp),
    Task('majority_vote', ('a', 'b', 'c'), 'Inputs are 0/1. Return 1 when at least two are 1, else 0.',
         (((1, 0, 1), 1), ((0, 0, 1), 0)), majority_vote, gen_vote),
    Task('distance_1d', ('a', 'b'), 'Absolute difference of two integer positions.',
         (((3, 8), 5), ((-4, 4), 8)), distance_1d, gen_distance),
    Task('triangle_kind', ('a', 'b', 'c'), 'Return invalid, equilateral, isosceles, or scalene for sides.',
         (((4, 4, 4), 'equilateral'), ((3, 4, 8), 'invalid'), ((3, 3, 4), 'isosceles')), triangle_kind, gen_triangle),
)


# Trusted, fixed edge cases are separate from the public prompt examples.
_BOUNDARIES = {
    "risk_gate": (((24, 0), "conserve"), ((25, 2), "explore"), ((25, 3), "conserve"), ((0, 0), "conserve")),
    "clamp_value": (((5, 5, 9), 5), ((9, 5, 9), 9), ((-200, -4, -1), -4), ((0, 0, 0), 0)),
    "parity_label": (((0,), "even"), ((-500,), "even"), ((-499,), "odd")),
    "budget_left": (((10, 5, 5), 0), ((11, 5, 5), 1), ((0, 0, 0), 0)),
    "temperature_band": (((11,), "cold"), ((12,), "mild"), ((28,), "mild"), ((29,), "hot")),
    "majority_vote": (((0, 0, 0), 0), ((1, 1, 0), 1), ((1, 0, 0), 0), ((1, 1, 1), 1)),
    "distance_1d": (((0, 0), 0), ((150, -150), 300), ((-150, 150), 300)),
    "triangle_kind": (((1, 2, 3), "invalid"), ((0, 1, 1), "invalid"), ((3, 4, 5), "scalene"), ((2, 2, 3), "isosceles")),
}


class TaskRegistry(Mapping):
    """Read-only task view with an explicit trusted-developer registration API.

    Only host code may register callables. Model actions cannot add tasks or
    change labels; neither oracle nor benchmark cases appear in public_catalog.
    Registration rejects replacement so a known benchmark cannot be silently
    rewritten. Register extensions during application startup.
    """
    def __init__(self):
        self._tasks = {}
        self._lock = threading.RLock()

    def __getitem__(self, name):
        return self._tasks[name]

    def __iter__(self):
        with self._lock:
            return iter(tuple(self._tasks))

    def __len__(self):
        return len(self._tasks)

    @staticmethod
    def _arguments(task, args):
        if type(args) is not tuple or len(args) != len(task.args):
            raise ValueError("task generator/case arguments must be a tuple matching the task signature")
        for value in args:
            _scalar(value)
        return args

    @staticmethod
    def _same(a, b):
        return type(a) is type(b) and a == b

    def register(self, task):
        if not isinstance(task, Task):
            raise TypeError("register a Task defined by trusted developer code")
        if (type(task.name) is not str or not task.name.isidentifier() or
                task.name.startswith("_") or len(task.name) > 64 or task.name in {"min", "max", "abs"}):
            raise ValueError("invalid task name")
        if (type(task.args) is not tuple or not 1 <= len(task.args) <= 7 or
                any(type(a) is not str or not a.isidentifier() or a.startswith("_") or len(a) > 64 for a in task.args) or
                len(set(task.args)) != len(task.args)):
            raise ValueError("invalid task argument names")
        if type(task.description) is not str or not 1 <= len(task.description) <= 1200:
            raise ValueError("task needs a bounded description")
        if not callable(task.oracle) or not callable(task.generator):
            raise ValueError("task requires trusted oracle and generator callables")
        if type(task.examples) is not tuple or not 1 <= len(task.examples) <= 20:
            raise ValueError("task needs 1..20 public examples")
        if type(task.benchmarks) is not tuple or len(task.benchmarks) > 128:
            raise ValueError("task benchmarks must be a bounded tuple")
        for case in task.examples + task.benchmarks:
            if type(case) is not tuple or len(case) != 2:
                raise ValueError("task cases must be (arguments, expected) tuples")
            args, expected = case
            self._arguments(task, args)
            _scalar(expected)
            actual = _scalar(task.oracle(*args))
            if not self._same(actual, expected):
                raise ValueError("case expectation disagrees with independent oracle")
        # Catch common broken/nonreproducible plugin contracts before activation.
        first, second = random.Random(8327), random.Random(8327)
        for _ in range(24):
            args = self._arguments(task, task.generator(first))
            repeated = self._arguments(task, task.generator(second))
            if args != repeated or any(type(a) is not type(b) for a, b in zip(args, repeated)):
                raise ValueError("task generator must be reproducible from its supplied RNG")
            expected = _scalar(task.oracle(*args))
            if not self._same(expected, _scalar(task.oracle(*args))):
                raise ValueError("task oracle must be deterministic")
        with self._lock:
            if task.name in self._tasks:
                raise ValueError("task already registered: " + task.name)
            self._tasks[task.name] = task
        return task


TASKS = TaskRegistry()


def register_task(task):
    """Explicit extension point; call from a reviewed developer module at startup."""
    return TASKS.register(task)


for _task in _INITIAL_TASKS:
    register_task(Task(_task.name, _task.args, _task.description, _task.examples,
                       _task.oracle, _task.generator, _BOUNDARIES[_task.name]))


def public_catalog():
    return [dict(name=t.name, args=list(t.args), description=t.description,
                 examples=[dict(input=list(args), output=output) for args, output in t.examples])
            for t in TASKS.values()]


def _cases(task, seed, count):
    if type(seed) is not int:
        raise ValueError('evaluation seed must be an integer')
    if type(count) is not int or not 1 <= count <= 2048:
        raise ValueError('evaluation count must be 1..2048')
    rng = random.Random(seed)
    cases = []
    for _ in range(count):
        args = TaskRegistry._arguments(task, task.generator(rng))
        cases.append((args, _scalar(task.oracle(*args))))
    return cases


def _evaluate_cases(source, task, cases):
    runtime = Runtime(source)
    total = len(cases)
    if task.name not in runtime.functions:
        return dict(score=0., correct=0, total=total, errors=['function missing'])
    params = [arg.arg for arg in runtime.functions[task.name].args.args]
    if len(params) != len(task.args):
        return dict(score=0., correct=0, total=total, errors=['wrong number of parameters'])
    successes, errors = 0, []
    for args, expected in cases:
        try:
            actual = runtime.call(task.name, *args)
            if type(actual) is type(expected) and actual == expected:
                successes += 1
            elif len(errors) < 3:
                errors.append(f'{args}: returned {actual!r}, expected {expected!r}')
        except (CapabilityError, ArithmeticError, TypeError, ValueError) as exc:
            if len(errors) < 3:
                errors.append(f'{args}: {str(exc)[:100]}')
    return dict(score=round(successes / total, 4), correct=successes, total=total, errors=errors)


def evaluate(source, task_name, seed=4021, count=48):
    """Measured accuracy on generated cases; candidate source never defines labels."""
    task = TASKS[task_name]
    return _evaluate_cases(source, task, _cases(task, seed, count))


def evaluate_holdout(source, task_name, seed=9191, count=64):
    """Independent generated holdout plus trusted fixed boundary benchmarks.

    Public examples are excluded from the generated holdout. The engine supplies
    a fresh seed for admission to reduce repeated fixed-set reward exploitation.
    These are narrow local benchmarks, not a claim of arbitrary generalization.
    """
    task = TASKS[task_name]
    public = {args for args, _ in task.examples}
    generated = [(args, expected) for args, expected in _cases(task, seed, count)
                 if args not in public]
    cases = list(task.benchmarks) + generated
    if not cases:
        # A finite-domain task may expose every possible input publicly; report
        # that there is no independent holdout instead of calling it a pass.
        return dict(score=0., correct=0, total=0, errors=['no independent holdout cases'])
    result = _evaluate_cases(source, task, cases)
    result['benchmark_cases'] = len(task.benchmarks)
    result['generated_cases'] = len(generated)
    return result


def scores(source):
    return {name: evaluate(source, name, seed=717, count=30)['score'] for name in TASKS}


def frontier(source):
    current = scores(source)
    return sorted(current, key=lambda n: (current[n], n))


def environment_challenge(source, rng):
    """Run an actual generated challenge against one callable organism function."""
    task_name = rng.choice(list(TASKS))
    task = TASKS[task_name]
    args = task.generator(rng)
    expected = task.oracle(*args)
    actual = None
    try:
        actual = Runtime(source).call(task_name, *args)
        correct = type(actual) == type(expected) and actual == expected
    except (CapabilityError, ArithmeticError, ValueError, TypeError, OverflowError) as exc:
        actual = 'error: ' + str(exc)[:90]
        correct = False
    return dict(task=task_name, inputs=list(args), expected=expected,
                actual=actual, correct=correct)
