"""Deterministic, bounded context for modest local language models.

UTF-8 byte counts deliberately overestimate normal token use without downloading
another tokenizer. SQLite retains complete evidence; prompts contain excerpts.
"""
import ast
import json
from copy import deepcopy
from .brain import SYSTEM


def _dump(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), default=str)


def estimate_tokens(messages):
    """Conservative UTF-8 byte token bound including chat framing overhead."""
    if isinstance(messages, str):
        return len(messages.encode('utf8')) + 8
    return 16 + sum(16 + len(str(message.get('role', '')).encode('utf8'))
                    + len(str(message.get('content', '')).encode('utf8'))
                    for message in messages)


def _snippet(value, chars):
    text = str(value)
    return text if len(text) <= chars else text[:max(0, chars - 1)] + '…'


def _relevant_source(source, focus, limit=1300):
    if not isinstance(source, str):
        return ''
    try:
        tree = ast.parse(source)
        functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
        if focus in functions:
            selected = [functions[focus]]
            used = {n.func.id for n in ast.walk(functions[focus])
                    if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)}
            selected += [functions[name] for name in sorted(used) if name in functions and name != focus]
            source = '\n\n'.join(ast.unparse(node) for node in selected)
        else:
            from .tasks import TASKS
            helpers = [node for name, node in functions.items() if name not in TASKS]
            source = '\n\n'.join(ast.unparse(node) for node in helpers[:3])
    except (SyntaxError, ValueError, RecursionError):
        pass
    return _snippet(source, limit)


def _auxiliary_messages(obs, system, input_limit, num_predict):
    """Chat and protocol repair must preserve their actual purpose and inputs."""
    repairing = 'protocol_error' in obs or 'original_response' in obs
    out = {'context_budget': {'method': 'UTF-8 byte upper bound', 'input_limit': input_limit,
                              'output_reserved': num_predict, 'excerpts': True}}
    if repairing:
        out.update(protocol_error=str(obs.get('protocol_error', 'Invalid action protocol')),
                   original_response=_snippet(obs.get('original_response', ''), 1200),
                   instruction=str(obs.get('instruction', 'Repair this exact protocol error.')))
    else:
        # Do not silently replace or truncate the user's question. A question
        # that cannot fit gets an explicit context-size error.
        out['user_question'] = str(obs['user_question'])

    def messages():
        return [{'role': 'system', 'content': system}, {'role': 'user', 'content': _dump(out)}]

    def fits():
        return estimate_tokens(messages()) <= input_limit

    if repairing:
        for cap in (900, 600, 320, 160, 80):
            if fits():
                break
            out['original_response'] = _snippet(out['original_response'], cap)
    if not fits():
        raise ValueError('context cannot fit the question or repair error; shorten the input or increase num_ctx')

    focus = obs.get('focus_task', 'model_experiment')
    additions = [('focus_task', focus)]
    catalog = [{key: value for key, value in item.items() if key in ('name', 'args', 'description')}
               for item in obs.get('task_catalog', []) if item.get('name') == focus]
    additions += [('task_catalog', catalog[:1]), ('identity', obs.get('identity', {})),
                  ('task_scores', obs.get('task_scores', {}))]
    if not repairing:
        additions += [('student', obs.get('student', {})),
                      ('memory', {'last_proposals': obs.get('memory', {}).get('last_proposals', [])[:1]})]
    for key, value in additions:
        if not value:
            continue
        out[key] = value
        if not fits():
            out.pop(key)
    return messages()


def build_messages(observation, *, num_ctx=4096, num_predict=750, system=SYSTEM):
    """Select measured feedback and focus contract within context/output budget.

    The observation and persisted history are unchanged. Requested file excerpts
    retain their path across trimming so inspect actions have an actual effect.
    """
    if type(num_ctx) is not int or type(num_predict) is not int or num_predict < 1:
        raise ValueError('context and output limits must be positive integers')
    input_limit = num_ctx - num_predict - 64
    if input_limit < 256:
        raise ValueError('context is too small for output reservation')
    obs = deepcopy(observation)
    if 'user_question' in obs or 'protocol_error' in obs or 'original_response' in obs:
        return _auxiliary_messages(obs, system, input_limit, num_predict)
    focus = obs.get('focus_task', 'model_experiment')
    identity = obs.get('identity', {})
    memory = obs.get('memory', {})
    recent = memory.get('last_proposals', [])
    contents = obs.get('requested_file_contents', {})
    catalog = [item for item in obs.get('task_catalog', []) if item.get('name') == focus]
    out = {
        'identity': {key: identity[key] for key in ('organism', 'generation', 'energy', 'fitness', 'age', 'mutations') if key in identity},
        'focus_task': focus,
        'focus_instruction': _snippet(obs.get('focus_instruction', 'Improve focus task; obey actual failure feedback.'), 220),
        'task_catalog': catalog[:1],
        'task_scores': obs.get('task_scores', {}),
        'organism_source': _relevant_source(obs.get('organism_source', ''), focus),
        'memory': {'last_proposals': []},
        'project_files': [],
        'context_budget': {'method': 'UTF-8 byte upper bound', 'input_limit': input_limit,
                           'output_reserved': num_predict, 'excerpts': True},
    }
    if recent:
        row = recent[0]
        out['memory']['last_proposals'] = [{key: _snippet(value, 180) if isinstance(value, str) else value
                                         for key, value in row.items()
                                         if key in ('id', 'task', 'action', 'accepted', 'reason', 'outcome', 'after', 'before')}]
    if contents:
        out['requested_file_contents'] = {str(path): _snippet(text, 500)
                                          for path, text in list(contents.items())[:3]}
    plan = obs.get('plan', obs.get('planner'))
    if isinstance(plan, dict):
        out['plan'] = {key: value for key, value in plan.items()
                       if key in ('focus_task', 'strategy', 'instruction', 'cooldown_multiplier', 'inspect_paths')}
    relevant = [row for row in memory.get('known_rejections', []) if row.get('task') == focus]
    if relevant:
        row = relevant[0]
        out['memory']['known_rejections'] = [{key: _snippet(value, 160) if isinstance(value, str) else value
                                             for key, value in row.items()
                                             if key in ('task', 'reason', 'fingerprint', 'function_name')}]
    preferred = sorted(obs.get('project_files', []),
                       key=lambda item: (item.get('path') != 'seed_core/tasks.py', item.get('path', '')))
    if preferred:
        out['project_files'] = [{'path': preferred[0].get('path', '')}]

    def messages():
        return [{'role': 'system', 'content': system}, {'role': 'user', 'content': _dump(out)}]

    def fits():
        return estimate_tokens(messages()) <= input_limit

    if not fits() and out.get('plan'):
        out['plan'] = {key: value for key, value in out['plan'].items()
                       if key in ('strategy', 'focus_task')}
    if not fits():
        out['task_catalog'] = [{key: value for key, value in item.items()
                                if key in ('name', 'args', 'description')} for item in catalog[:1]]
    for cap in (320, 180, 80):
        if fits():
            break
        if 'requested_file_contents' in out:
            out['requested_file_contents'] = {path: _snippet(text, cap)
                                              for path, text in out['requested_file_contents'].items()}
        out['organism_source'] = _snippet(out['organism_source'], max(cap, 180))
        out['focus_instruction'] = _snippet(out['focus_instruction'], cap)
    if not fits():
        out['task_scores'] = {focus: out['task_scores'][focus]} if focus in out['task_scores'] else {}
    if not fits() and out['memory']['last_proposals']:
        row = out['memory']['last_proposals'][0]
        out['memory']['last_proposals'] = [{key: _snippet(value, 100) if isinstance(value, str) else value
                                         for key, value in row.items() if key in ('task', 'accepted', 'reason', 'outcome')}]
    if not fits():
        raise ValueError('context cannot fit system, focus contract, and recent feedback; increase num_ctx or reduce num_predict')

    def add_if_fits(container, key, value):
        previous = container.get(key, None)
        present = key in container
        container[key] = value
        if fits():
            return True
        if present:
            container[key] = previous
        else:
            container.pop(key, None)
        return False

    for row in relevant[1:3]:
        item = {key: _snippet(value, 160) if isinstance(value, str) else value
                for key, value in row.items() if key in ('task', 'reason', 'fingerprint', 'function_name')}
        current = out['memory'].get('known_rejections', [])
        add_if_fits(out['memory'], 'known_rejections', current + [item])
    for row in recent[1:4]:
        item = {key: _snippet(value, 130) if isinstance(value, str) else value
                for key, value in row.items() if key in ('task', 'accepted', 'reason', 'outcome')}
        add_if_fits(out['memory'], 'last_proposals', out['memory']['last_proposals'] + [item])
    if memory.get('learned_notes'):
        add_if_fits(out['memory'], 'learned_notes', [_snippet(item, 140) for item in memory['learned_notes'][:2]])
    if memory.get('verified_successes'):
        success = [{key: value for key, value in row.items() if key in ('task', 'function_name', 'holdout_after')}
                   for row in memory['verified_successes'][:2]]
        add_if_fits(out['memory'], 'verified_successes', success)
    if obs.get('student'):
        stats = {key: value for key, value in obs['student'].items()
                 if key in ('ready', 'trained', 'accuracy', 'examples', 'stored_samples', 'validation_samples', 'architecture', 'task')}
        add_if_fits(out, 'student', stats)
    try:
        tree = ast.parse(obs.get('organism_source', ''))
        signatures = [f"{node.name}({','.join(arg.arg for arg in node.args.args)})"
                      for node in tree.body if isinstance(node, ast.FunctionDef)]
        add_if_fits(out, 'available_functions', signatures)
    except (SyntaxError, ValueError, TypeError, RecursionError):
        pass
    for item in preferred[1:40]:
        compact = {'path': item.get('path', '')}
        if not add_if_fits(out, 'project_files', out['project_files'] + [compact]):
            break
    add_if_fits(out['context_budget'], 'estimated_input_tokens', estimate_tokens(messages()) + 40)
    return messages()
