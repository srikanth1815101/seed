"""SQLite persistence for observations, every proposal, model trials, code and traces."""
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS organisms(
 id INTEGER PRIMARY KEY, parent INTEGER, generation INTEGER, alive INTEGER,
 energy REAL, fitness REAL, age INTEGER, workspace TEXT, created TEXT,
 death_reason TEXT, mutation_count INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS events(
 id INTEGER PRIMARY KEY, ts TEXT, kind TEXT, organism INTEGER, detail TEXT);
CREATE TABLE IF NOT EXISTS episodes(
 id INTEGER PRIMARY KEY, ts TEXT, organism INTEGER, cycle INTEGER,
 observation_json TEXT, action TEXT, outcome TEXT, lesson TEXT,
 energy_delta REAL, proposal_id INTEGER);
CREATE TABLE IF NOT EXISTS proposals(
 id INTEGER PRIMARY KEY, ts TEXT, organism INTEGER, action TEXT,
 task TEXT, function_name TEXT, fingerprint TEXT, code TEXT,
 intent TEXT, outcome TEXT, reason TEXT,
 train_before REAL, holdout_before REAL, train_after REAL, holdout_after REAL,
 accepted INTEGER DEFAULT 0, cost REAL DEFAULT 0, reward REAL DEFAULT 0,
 trace_id INTEGER);
CREATE INDEX IF NOT EXISTS proposal_fingerprint_idx ON proposals(fingerprint);
CREATE TABLE IF NOT EXISTS traces(
 id INTEGER PRIMARY KEY, ts TEXT, organism INTEGER, purpose TEXT,
 request_json TEXT, response_text TEXT, tokens INTEGER,
 validation TEXT, error TEXT);
CREATE TABLE IF NOT EXISTS trials(
 id INTEGER PRIMARY KEY, ts TEXT, organism INTEGER, task TEXT,
 inputs_json TEXT, expected_json TEXT, actual_json TEXT, correct INTEGER,
 reward REAL, actor TEXT DEFAULT 'organism');
CREATE TABLE IF NOT EXISTS student_examples(
 id INTEGER PRIMARY KEY, energy REAL, failures INTEGER, label INTEGER);
CREATE TABLE IF NOT EXISTS models(
 id INTEGER PRIMARY KEY, ts TEXT, hidden1 INTEGER, hidden2 INTEGER,
 accuracy REAL, examples INTEGER, artifact TEXT, promoted INTEGER,
 reason TEXT);
CREATE TABLE IF NOT EXISTS notes(
 id INTEGER PRIMARY KEY, ts TEXT, organism INTEGER, text TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS code_revisions(
 id INTEGER PRIMARY KEY, ts TEXT, organism INTEGER, source TEXT,
 fingerprint TEXT, reason TEXT);
CREATE TABLE IF NOT EXISTS organism_code(
 organism INTEGER PRIMARY KEY, source TEXT NOT NULL,
 fingerprint TEXT NOT NULL, updated TEXT NOT NULL);
"""

# These additions deliberately leave all original tables and rows intact.  A
# plain ALTER, rather than copying a table, also preserves user-added columns.
PROPOSAL_COLUMNS = {
    'canonical_reason': "TEXT DEFAULT ''",
    'original_action': 'TEXT',
    'learning': 'TEXT',
    'generation': 'INTEGER',
    'parent': 'INTEGER',
    'base_fingerprint': 'TEXT',
    'source_before': 'TEXT',
    'source_after': 'TEXT',
    'diff': 'TEXT',
    'evaluation_json': 'TEXT',
    'net_energy': 'REAL',
    'energy_before': 'REAL',
    'energy_after': 'REAL',
    'execution_ms': 'REAL',
    'duplicate_of': 'INTEGER',
}


def canonical_reason(reason):
    """Recover legacy duplicate wrappers without altering the historical text."""
    result = str(reason or '').strip()
    wrappers = (
        'already attempted this exact function for this task:',
        'already attempted this exact function:',
        'DUPLICATE_PROPOSAL: Same function previously rejected because',
    )
    for _ in range(32):
        for prefix in wrappers:
            if result.startswith(prefix):
                result = result[len(prefix):].strip()
                break
        else:
            break
    return result[:1000]

class Store:
    def __init__(self, path):
        self.path = Path(path)
        self._local = threading.local()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as conn:
            conn.execute('PRAGMA journal_mode=WAL')
            conn.execute('BEGIN IMMEDIATE')
            version = int(conn.execute('PRAGMA user_version').fetchone()[0])
            if version > 2:
                raise ValueError('Database was created by a newer AI Seed version; use that version')
            # executescript() implicitly commits, so execute each simple DDL
            # statement inside the same explicit migration transaction instead.
            for statement in SCHEMA.split(';'):
                if statement.strip():
                    conn.execute(statement)
            existing = {row['name'] for row in conn.execute('PRAGMA table_info(proposals)')}
            for name, declaration in PROPOSAL_COLUMNS.items():
                if name not in existing:
                    conn.execute(f'ALTER TABLE proposals ADD COLUMN {name} {declaration}')
            trial_columns = {row['name'] for row in conn.execute('PRAGMA table_info(trials)')}
            if 'actor' not in trial_columns:
                conn.execute("ALTER TABLE trials ADD COLUMN actor TEXT DEFAULT 'organism'")
            conn.execute('CREATE INDEX IF NOT EXISTS proposal_task_result_idx '
                         'ON proposals(task,accepted,id)')
            conn.execute('CREATE INDEX IF NOT EXISTS proposal_lineage_idx '
                         'ON proposals(organism,id)')
            conn.execute('CREATE INDEX IF NOT EXISTS revision_organism_idx '
                         'ON code_revisions(organism,id)')
            if version < 2:
                rows = conn.execute("SELECT id,reason,outcome FROM proposals "
                                    "WHERE accepted=0 AND COALESCE(canonical_reason,'')=''").fetchall()
                for row in rows:
                    conn.execute('UPDATE proposals SET canonical_reason=? WHERE id=?',
                                 (canonical_reason(row['reason'] or row['outcome']), row['id']))
                conn.execute('PRAGMA user_version=2')

    @contextmanager
    def connect(self):
        active = getattr(self._local, 'connection', None)
        if active is not None:
            try:
                yield active
            except BaseException:
                self._local.rollback_only = True
                raise
            return
        conn = sqlite3.connect(str(self.path), timeout=25)
        conn.row_factory = sqlite3.Row
        conn.execute('PRAGMA busy_timeout=25000')
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    @contextmanager
    def transaction(self):
        """Join all same-thread store operations in one atomic transaction.

        Nested transaction contexts join the outer transaction, not an implicit
        commit or a savepoint. If an inner database operation fails, the whole
        transaction remains rollback-only even if its exception was caught.
        Other threads keep their own connections and cannot commit this work.
        """
        if getattr(self._local, 'connection', None) is not None:
            try:
                yield self._local.connection
            except BaseException:
                self._local.rollback_only = True
                raise
            return
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            self._local.connection = conn
            self._local.rollback_only = False
            try:
                yield conn
                if self._local.rollback_only:
                    raise RuntimeError('Transaction rolled back after an inner database failure')
            finally:
                del self._local.connection
                del self._local.rollback_only

    def rows(self, sql, params=()):
        with self.connect() as conn:
            return [dict(r) for r in conn.execute(sql, params).fetchall()]

    def one(self, sql, params=()):
        with self.connect() as conn:
            r = conn.execute(sql, params).fetchone()
            return dict(r) if r else None

    def execute(self, sql, params=()):
        with self.connect() as conn:
            cur = conn.execute(sql, params)
            return cur.lastrowid
