"""Bounded retrieval from complete SQLite history, including ancestor outcomes.

The database stores evidence; these summaries do not imply that Ollama remembers
an earlier HTTP request or that an organism's self-reported lesson is verified.
"""
from .db import canonical_reason


def _short(value, limit=180):
    return str(value or '')[:limit]


class Memory:
    def __init__(self, store):
        self.store = store

    def _ancestors(self, organism):
        """Bound traversal even if a user-edited legacy database has a cycle."""
        seen = {organism['id']}
        ancestors = []
        parent = organism.get('parent')
        while parent is not None and parent not in seen and len(ancestors) < 16:
            seen.add(parent)
            record = self.store.one('SELECT id,parent,generation FROM organisms WHERE id=?', (parent,))
            if not record:
                break
            ancestors.append(record)
            parent = record['parent']
        return ancestors

    @staticmethod
    def _proposal(record):
        result = dict(record)
        if 'reason' in result:
            result['reason'] = _short(canonical_reason(result.get('canonical_reason') or result['reason']), 200)
        result.pop('canonical_reason', None)
        if 'outcome' in result:
            result['outcome'] = _short(result['outcome'], 120)
        if 'learning' in result:
            result['learning'] = _short(result['learning'], 140)
        if 'code' in result:
            result['code'] = _short(result['code'], 800)
        return result

    def recall(self, organism, focus_task=None, limit=8):
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 32:
            raise ValueError('memory limit must be an integer between 1 and 32')
        oid = organism['id']
        ancestors = self._ancestors(organism)
        lineage = [oid, *[row['id'] for row in ancestors]]
        slots = ','.join('?' for _ in lineage)
        recent = self.store.rows(
            'SELECT id,organism,action,task,function_name,outcome,reason,canonical_reason,'
            'accepted,round(cost,3) cost,round(reward,3) reward,round(net_energy,3) net,'
            'round(holdout_before,4) before,round(holdout_after,4) after '
            'FROM proposals WHERE organism=? ORDER BY id DESC LIMIT ?', (oid, limit))

        # The focus filter happens in SQL before LIMIT. A relevant rejection from
        # years ago can therefore outrank hundreds of recent unrelated records.
        failures = self.store.rows(
            'SELECT p.id,p.organism,p.task,p.function_name,p.fingerprint,p.reason,'
            'p.canonical_reason,p.base_fingerprint,p.duplicate_of '
            'FROM proposals p JOIN ('
            'SELECT MIN(id) AS original FROM proposals '
            "WHERE accepted=0 AND fingerprint IS NOT NULL AND outcome!='pending' "
            'GROUP BY task,fingerprint,COALESCE(base_fingerprint,\'\')) original '
            'ON p.id=original.original '
            f'ORDER BY CASE WHEN p.task=? THEN 0 ELSE 1 END,'
            f'CASE WHEN p.organism IN ({slots}) THEN 0 ELSE 1 END,p.id DESC LIMIT ?',
            (focus_task or '', *lineage, min(limit, 6)))
        successes = self.store.rows(
            'SELECT id,organism,action,task,function_name,code,holdout_before,holdout_after '
            'FROM proposals WHERE accepted=1 '
            f'ORDER BY CASE WHEN task=? THEN 0 ELSE 1 END,'
            f'CASE WHEN organism IN ({slots}) THEN 0 ELSE 1 END,id DESC LIMIT 5',
            (focus_task or '', *lineage))
        episodes = self.store.rows(
            'SELECT action,outcome,lesson,round(energy_delta,3) net '
            'FROM episodes WHERE organism=? ORDER BY id DESC LIMIT 4', (oid,))
        for episode in episodes:
            episode['outcome'] = _short(episode['outcome'], 160)
            episode['lesson'] = _short(episode['lesson'], 140)
        progress = self.store.rows(
            'SELECT task,COUNT(*) total,SUM(accepted) accepted '
            'FROM proposals WHERE action=\'mutate\' AND outcome!=\'pending\' '
            'GROUP BY task ORDER BY task')
        notes = self.store.rows(
            f'SELECT text FROM notes ORDER BY CASE WHEN organism IN ({slots}) THEN 0 ELSE 1 END,'
            'id DESC LIMIT 3', lineage)
        count = self.store.one('SELECT COUNT(*) n FROM student_examples')['n']
        totals = self.store.one(
            'SELECT COUNT(*) attempts,COALESCE(SUM(accepted),0) accepted,'
            'ROUND(COALESCE(SUM(reward-cost),0),3) net_energy FROM proposals '
            "WHERE organism=? AND outcome!='pending'", (oid,))
        return {
            'last_proposals': [self._proposal(row) for row in recent],
            'verified_successes': [self._proposal(row) for row in successes],
            'known_rejections': [self._proposal(row) for row in failures],
            'task_mutation_progress': progress,
            'recent_episodes': episodes,
            'learned_notes': ['Model note (unverified): ' + _short(row['text'], 160) for row in notes],
            'student_samples': count,
            'evolutionary_memory': {
                'ancestors': ancestors,
                'shared_experiments': True,
                'rule': 'Ancestor and shared proposals are evidence, not necessarily active inherited code.',
            },
            'summary': {'organism': oid, **totals},
            'rule': 'Use measured outcomes and canonical failures. Never repeat unchanged code; notes are hypotheses.',
        }
