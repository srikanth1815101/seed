"""Deterministic objectives and loop breaking, independent of model compliance."""
import json
import math

from .db import canonical_reason


class Planner:
    def __init__(self, store):
        self.store = store

    def plan(self, organism, task_scores):
        scores = {}
        for name, value in task_scores.items():
            if not isinstance(name, str) or isinstance(value, bool):
                continue
            try:
                score = float(value)
            except (TypeError, ValueError):
                continue
            if math.isfinite(score):
                scores[name] = score
        unsolved = sorted((name for name in scores if scores[name] < .95),
                          key=lambda name: (scores[name], name))
        focus = unsolved[0] if unsolved else 'model_experiment'
        preferred = self.store.one('SELECT value FROM settings WHERE key=?',
                                   (f"planner_next_task_{organism['id']}",))
        if preferred:
            value = preferred['value']
            try:
                decoded = json.loads(value)
                value = decoded if isinstance(decoded, str) else value
            except (ValueError, TypeError):
                pass
            if value in unsolved:
                focus = value
        recent = self.store.rows(
            'SELECT id,action,task,accepted,fingerprint,reason,canonical_reason,outcome '
            "FROM proposals WHERE organism=? AND outcome!='pending' ORDER BY id DESC LIMIT 6",
            (organism['id'],))
        result = {
            'focus_task': focus,
            'strategy': 'improve_unsolved' if unsolved else 'train_student',
            'instruction': ('Improve the focus task against its contract. Reuse active validated helpers; '
                            'do not repeat known failed implementations.') if unsolved else
                           'All registered tasks are solved. Train a bounded student candidate only when enough examples exist.',
            'cooldown_multiplier': 1,
        }
        if not recent:
            return result

        latest = recent[0]
        failed_task = latest['task']
        consecutive_failures = []
        for row in recent:
            if row['action'] != 'mutate' or row['accepted'] or row['task'] != failed_task:
                break
            consecutive_failures.append(row)
        stalled_actions = (len(recent) >= 2 and
                           all(row['action'] in ('inspect', 'reflect') for row in recent[:2]))
        if len(consecutive_failures) >= 2 or stalled_actions:
            alternatives = [name for name in unsolved if name != failed_task and name != focus]
            if not alternatives:
                alternatives = [name for name in unsolved if name != failed_task]
            if alternatives:
                result['focus_task'] = alternatives[0]
                result['strategy'] = 'switch_task'
                result['instruction'] = (
                    f"Repeated attempts made no measured improvement. Switch to {alternatives[0]}; "
                    'propose a different implementation for its contract, not another reflection or identical inspection.')
            else:
                result['strategy'] = 'inspect_then_revise'
                result['inspect_paths'] = ['seed_core/tasks.py']
                result['instruction'] = (
                    'Repeated attempts failed. Inspect the task contract once if not already supplied, '
                    'then choose a different implementation. Formatting changes are duplicates.')
            result['cooldown_multiplier'] = 4
        elif consecutive_failures:
            failure = canonical_reason(latest.get('canonical_reason') or latest['reason'] or latest['outcome'])
            result['strategy'] = 'correct_failure'
            result['instruction'] = ('Correct the measured failure with different code: ' + failure[:220])
        return result
