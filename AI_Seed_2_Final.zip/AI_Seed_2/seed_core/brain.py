"""Bounded Ollama transport and explicit organism action protocol.

Ollama is stateless. Responses are data for the restricted runtime, never host code.
"""
import ast
import json
import math
import re
import urllib.error
import urllib.parse
import urllib.request
from pathlib import PurePosixPath

SYSTEM = """You propose one measured improvement for a local software organism.
Ollama has no memory: use the supplied SQLite feedback and current focus task.
Return ONE JSON object, no prose. Include hypothesis and learning (short strings).
Actions:
mutate: task=<catalog name or helper>, function=<one complete def>.
inspect: paths=[<1..3 exact project_files paths>]; contents arrive next call.
model_experiment: params={hidden1:16,hidden2:12,learning_rate:0.03,epochs:90}.
reflect: learning=<specific lesson>, next_task=<optional catalog name>.
Mutations use scalar int/float/bool/string values, local assignments, if/else,
return, ternary, + - * // %, comparisons, and/or/not, and existing helper calls.
Pure builtins: min/max(2..7 numeric arguments), abs(one numeric argument).
No imports, loops, indexing, attributes, I/O, eval, exec, or other builtins.
Task functions must match the task name and parameter count. Short code only.
Never repeat a rejected AST or claim tests ran. Correct the saved failure; change
tasks when solved. Rewards require independently measured train+holdout gains.
You can inspect listed source, but only organism capabilities can change.
model_experiment trains a small narrow policy, not an LLM or Qwen weights."""

MAX_RESPONSE_BYTES = 64_000
MAX_ACTION_CHARS = 32_000
_ACTIONS = {'mutate', 'inspect', 'model_experiment', 'reflect'}
_PATH_PATTERN = re.compile(r'[A-Za-z0-9_./\\-]+\.(?:py|md|json|txt|html|js|css|bat|toml)\b')


def _json_object(raw):
    def pairs(values):
        result = {}
        for key, value in values:
            if key in result:
                raise ValueError('duplicate JSON field: ' + str(key)[:40])
            result[key] = value
        return result

    def invalid_constant(value):
        raise ValueError('non-finite JSON number is not allowed')

    decoder = json.JSONDecoder(object_pairs_hook=pairs, parse_constant=invalid_constant)
    try:
        value = json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid_constant)
    except (ValueError, RecursionError):
        first = raw.find('{')
        if first < 0:
            raise ValueError('response must contain one JSON action object') from None
        try:
            value, end = decoder.raw_decode(raw[first:])
        except (ValueError, RecursionError) as exc:
            raise ValueError('response must contain one valid JSON action object') from exc
        trailing = raw[first + end:].strip().strip('`').strip()
        if trailing.startswith(('{', '[')):
            raise ValueError('return exactly one JSON action object')
    if not isinstance(value, dict):
        raise ValueError('response must be a JSON object')
    return value


def _path(value):
    if not isinstance(value, str) or not value or len(value) > 240:
        raise ValueError('inspect paths must be nonempty project-relative strings')
    value = value.strip().replace('\\', '/')
    candidate = PurePosixPath(value)
    if (candidate.is_absolute() or '..' in candidate.parts or ':' in value
            or not candidate.parts or any(p.startswith('.') for p in candidate.parts)):
        raise ValueError('inspect paths must be permitted project-relative files')
    return candidate.as_posix()


def parse_action(raw, task_names=None, allowed_paths=None, max_function_chars=1800):
    """Normalize redundant arguments; reject missing executable arguments.

    allowed_paths accepts a ProjectIndex or iterable of manifest paths. Metadata
    is optional for compatibility with old saved model responses.
    """
    if not isinstance(raw, str) or len(raw) > MAX_ACTION_CHARS:
        raise ValueError('response must be text of at most 32000 characters')
    cmd = _json_object(raw)
    action = cmd.get('action')
    if not isinstance(action, str) or action not in _ACTIONS:
        raise ValueError('action must be mutate, inspect, model_experiment, or reflect')
    if task_names is None:
        from .tasks import TASKS
        task_names = TASKS
    tasks = set(task_names)
    if hasattr(allowed_paths, 'manifest'):
        allowed = {item['path'] for item in allowed_paths.manifest()}
    elif allowed_paths is not None:
        allowed = set(allowed_paths)
    else:
        allowed = None
    result = {'action': action}
    normalizations = []
    for name in ('hypothesis', 'learning'):
        value = cmd.get(name, '')
        if not isinstance(value, str) or len(value) > 1200:
            raise ValueError(name + ' must be a string of at most 1200 characters')
        result[name] = value.strip()

    if action == 'mutate':
        function = cmd.get('function')
        if not isinstance(function, str) or not function.strip():
            raise ValueError('mutate requires function: one complete Python function')
        if len(function) > max_function_chars:
            raise ValueError(f'mutate.function exceeds {max_function_chars} characters')
        try:
            tree = ast.parse(function)
        except (SyntaxError, RecursionError, ValueError) as exc:
            raise ValueError('mutate.function must be syntactically valid Python') from exc
        if len(tree.body) != 1 or not isinstance(tree.body[0], ast.FunctionDef):
            raise ValueError('mutate.function must contain exactly one def')
        task = cmd.get('task')
        if task is None or task == '':
            name = tree.body[0].name
            if name not in tasks:
                raise ValueError('mutate requires task: exact catalog name or helper')
            task = name
            normalizations.append('inferred task from exact registered function name')
        if not isinstance(task, str) or task not in tasks | {'helper'}:
            raise ValueError('mutate.task must be an exact task catalog name or helper')
        if task != 'helper' and tree.body[0].name != task:
            raise ValueError('mutate.function name must match task ' + task)
        result.update(task=task, function=function.strip())
    elif action == 'inspect':
        paths = cmd.get('paths')
        if isinstance(paths, str):
            paths = [paths]
            normalizations.append('normalized one inspect path to a list')
        if not paths:
            recovered = set()
            if allowed is not None:
                for key, value in cmd.items():
                    if key in ('action', 'paths'):
                        continue
                    values = value if isinstance(value, list) else [value]
                    for text in values:
                        if not isinstance(text, str):
                            continue
                        for item in _PATH_PATTERN.findall(text):
                            try:
                                candidate = _path(item)
                            except ValueError:
                                continue
                            if candidate in allowed:
                                recovered.add(candidate)
            if len(recovered) == 1:
                paths = sorted(recovered)
                normalizations.append('recovered one unambiguous allowed inspect path')
            else:
                raise ValueError('inspect requires paths: ["seed_core/tasks.py"] (1..3 permitted files)')
        if not isinstance(paths, list) or not 1 <= len(paths) <= 3:
            raise ValueError('inspect.paths must be a list of 1..3 permitted project files')
        normalized = list(dict.fromkeys(_path(item) for item in paths))
        if allowed is not None:
            unavailable = [item for item in normalized if item not in allowed]
            if unavailable:
                raise ValueError('inspect path is not in project_files: ' + unavailable[0])
        result['paths'] = normalized
    elif action == 'model_experiment':
        params = cmd.get('params')
        if not isinstance(params, dict):
            raise ValueError('model_experiment requires params object')
        unknown = set(params) - {'hidden1', 'hidden2', 'learning_rate', 'epochs'}
        if unknown:
            raise ValueError('unsupported model parameter: ' + sorted(unknown)[0])
        checked = {}
        for name, default, low, high in (('hidden1', 16, 4, 64), ('hidden2', 12, 4, 64), ('epochs', 90, 10, 160)):
            value = params.get(name, default)
            if type(value) is not int or not low <= value <= high:
                raise ValueError(f'{name} must be an integer in {low}..{high}')
            checked[name] = value
        rate = params.get('learning_rate', .03)
        if type(rate) not in (int, float) or not math.isfinite(rate) or not .001 <= rate <= .1:
            raise ValueError('learning_rate must be a finite number in 0.001..0.1')
        checked['learning_rate'] = float(rate)
        result['params'] = checked
    else:
        if not result['learning']:
            raise ValueError('reflect requires a nonempty learning string')
        if 'next_task' in cmd:
            if not isinstance(cmd['next_task'], str) or cmd['next_task'] not in tasks:
                raise ValueError('reflect.next_task must be an exact task catalog name')
            result['next_task'] = cmd['next_task']
    if normalizations:
        result['_normalizations'] = normalizations
    return result


class OllamaClient:
    def __init__(self, url='http://127.0.0.1:11434', model='qwen3:1.7b',
                 num_ctx=4096, num_predict=750, temperature=0.35,
                 timeout=150, max_response_bytes=MAX_RESPONSE_BYTES):
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError('ollama_url must be an HTTP(S) URL without embedded credentials')
        if type(num_ctx) is not int or not 1024 <= num_ctx <= 32768:
            raise ValueError('num_ctx must be an integer in 1024..32768')
        if type(num_predict) is not int or not 64 <= num_predict < num_ctx:
            raise ValueError('num_predict must be at least 64 and smaller than num_ctx')
        if not 0 <= temperature <= 2:
            raise ValueError('temperature must be in 0..2')
        self.url = url.rstrip('/')
        self.model = model
        self.num_ctx = num_ctx
        self.num_predict = num_predict
        self.temperature = temperature
        self.timeout = min(max(float(timeout), 1), 300)
        self.max_response_bytes = min(max(int(max_response_bytes), 1024), 1_000_000)

    def generate(self, messages):
        body = json.dumps({
            'model': self.model, 'stream': False, 'think': False,
            'format': 'json', 'messages': messages,
            'options': {'num_ctx': self.num_ctx, 'num_predict': self.num_predict,
                        'temperature': self.temperature},
        }, allow_nan=False).encode('utf8')
        request = urllib.request.Request(self.url + '/api/chat', body,
                                         {'Content-Type': 'application/json'})
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                raw = response.read(self.max_response_bytes + 1)
            if len(raw) > self.max_response_bytes:
                raise ValueError('Ollama response exceeds configured byte limit')
            payload = json.loads(raw)
            if not isinstance(payload, dict):
                raise ValueError('Ollama response must be an object')
            if payload.get('error'):
                raise ValueError(str(payload['error'])[:200])
            message = payload.get('message')
            if not isinstance(message, dict) or not isinstance(message.get('content'), str):
                raise ValueError('Ollama response is missing message.content')
            content = message['content']
            if len(content) > MAX_ACTION_CHARS:
                raise ValueError('Ollama action exceeds response character limit')
            counts = [payload.get('prompt_eval_count', 0), payload.get('eval_count', 0)]
            if any(type(count) is not int or count < 0 for count in counts):
                raise ValueError('Ollama returned invalid usage counters')
            usage = sum(counts)
            if not usage or any(key not in payload for key in ('prompt_eval_count', 'eval_count')):
                from .context_builder import estimate_tokens
                usage = estimate_tokens(messages) + len(content.encode('utf8')) + 16
        except (urllib.error.URLError, TimeoutError, OSError, ValueError, RecursionError) as exc:
            raise ConnectionError(f'Ollama unavailable or invalid response: {str(exc)[:240]}') from exc
        return content, max(usage, 1)
