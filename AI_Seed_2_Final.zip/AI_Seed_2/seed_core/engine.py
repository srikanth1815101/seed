"""AI Seed 2: persistent observe -> Qwen decide -> validate -> remember loop.

Qwen is the reasoning bootstrap, not a magically stateful Ollama model. Every
request explicitly includes compact persisted memory, project index and state.
Organism-defined pure functions never run through Python exec/eval.
"""
import ast
import datetime as dt
import difflib
import hashlib
import json
import os
import random
import shutil
import threading
import time
from pathlib import Path
from contextlib import nullcontext

from .brain import OllamaClient, SYSTEM, parse_action
from .context_builder import build_messages, estimate_tokens
from .db import Store
from .memory import Memory
from .planner import Planner
from .project_index import ProjectIndex
from .safe_runtime import Runtime, CapabilityError, merge_one, canonical_fingerprint
from .student import NeuralStudent
from .tasks import TASKS, public_catalog, evaluate, evaluate_holdout, scores, environment_challenge


BASELINE = '''def risk_gate(energy, failures):
    if energy < 25 or failures >= 3:
        return "conserve"
    return "explore"
'''


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')


def brief(obj, limit=200):
    return str(obj)[:limit]


def _json(value):
    return json.dumps(value, ensure_ascii=False, default=str)


class Engine:
    def __init__(self, root, brain=None, start_worker=False):
        self.root = Path(root).resolve()
        self.cfg = json.loads((self.root / 'config.json').read_text(encoding='utf8'))
        self._validate_config()
        self.store = Store(self.root / 'data' / 'seed2.db')
        self.memories = Memory(self.store)
        self.planner = Planner(self.store)
        self.index = ProjectIndex(self.root,
                                  self.cfg['max_project_files_indexed'],
                                  self.cfg['max_file_inspection_chars'])
        self.brain = brain or OllamaClient(
            self.cfg['ollama_url'], self.cfg['model'],
            self.cfg['num_ctx'], self.cfg['num_predict'],
            self.cfg['temperature'])
        self.student = NeuralStudent(self.root / 'models', self.store)
        last_model = self.store.one('SELECT MAX(examples) AS n FROM models')
        self.last_student_train_samples = int((last_model or {}).get('n') or 0)
        self.lock = threading.RLock()
        self.llm_lock = threading.Lock()
        self.budget_lock = threading.RLock()
        self.step_lock = threading.Lock()
        self.control_epoch = 0
        self.retry_not_before = 0.0
        self.worker = None
        self.state = 'PAUSED'
        self.activity = 'Initialized; click Start'
        self.last_error = ''
        saved_cycle = self.store.one("SELECT value FROM settings WHERE key='cycle_number'")
        self.cycle_number = int(saved_cycle['value']) if saved_cycle else 0
        self.stop_flag = threading.Event()
        self.random = random.Random()
        self.last_reseed_at = 0.0
        self.last_trace = None
        self.daily_day = ''
        self.daily_calls = 0
        self.daily_tokens = 0
        self._sync_budget()
        # A crash must not leave a proposal looking as though it is still running.
        self.store.execute("UPDATE proposals SET outcome='interrupted before completion', "
                           "reason='Process ended before a measured outcome was committed', "
                           "canonical_reason='Process ended before a measured outcome was committed' "
                           "WHERE outcome='pending'")
        if self.cfg.get('auto_start'):
            self.control('start')
        if start_worker:
            self.worker = threading.Thread(target=self.loop, name='seed_evolution', daemon=True)
            self.worker.start()

    def _validate_config(self):
        for name in ('cycle_seconds', 'brain_every_cycles', 'max_population', 'num_ctx',
                     'num_predict', 'daily_calls_limit', 'daily_token_limit',
                     'max_code_bytes', 'max_function_chars', 'max_llm_traces'):
            value = self.cfg.get(name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0 < value < 10**9:
                raise ValueError(f'config {name} must be a positive finite number')
        if self.cfg['num_ctx'] < 2048 or self.cfg['num_predict'] >= self.cfg['num_ctx'] - 1024:
            raise ValueError('num_ctx must leave at least 1024 tokens for the prompt')

    def rows(self, sql, params=()):
        return self.store.rows(sql, params)

    def event(self, kind, organism, detail):
        self.store.execute('INSERT INTO events(ts,kind,organism,detail) VALUES(?,?,?,?)',
                           (utc(), kind, organism, brief(detail, 1500)))

    def _sync_budget(self):
        with self.budget_lock:
            self._sync_budget_unlocked()

    def _sync_budget_unlocked(self):
        today = dt.datetime.now().date().isoformat()
        if self.daily_day != today:
            self.daily_day = today
            record = self.store.one("SELECT value FROM settings WHERE key='daily_budget'")
            if record:
                try:
                    saved = json.loads(record['value'])
                except (ValueError, TypeError):
                    saved = {}
            else:
                saved = {}
            self.daily_calls = int(saved.get('calls', 0)) if saved.get('day') == today else 0
            self.daily_tokens = int(saved.get('tokens', 0)) if saved.get('day') == today else 0

    def _save_budget(self):
        with self.budget_lock:
            self.store.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('daily_budget',?)",
                               (_json(dict(day=self.daily_day, calls=self.daily_calls, tokens=self.daily_tokens)),))

    def _budget_available(self):
        self._sync_budget()
        return (self.daily_calls < self.cfg['daily_calls_limit'] and
                self.daily_tokens < self.cfg['daily_token_limit'])

    def _source_path(self, oid):
        path = self.root / 'workspaces' / f'organism_{int(oid)}' / 'capabilities.py'
        for part in (path.parent.parent, path.parent, path):
            if part.is_symlink():
                raise ValueError('Organism workspace must not contain symbolic links')
        return path

    def _quarantine_mirror(self, path):
        if path.is_file():
            target = path.parent / f'quarantine_{time.time_ns()}.txt'
            shutil.copy2(path, target)

    def _mirror_code(self, path, source):
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix('.py.tmp')
        if temp.is_symlink():
            raise ValueError('Source staging file must not be a symbolic link')
        temp.write_text(source, encoding='utf8')
        os.replace(temp, path)

    def _organism_source(self, oid):
        path = self._source_path(oid)
        saved = self.store.one('SELECT source FROM organism_code WHERE organism=?', (oid,))
        if saved:
            source = saved['source']
        else:
            if path.is_file() and path.stat().st_size <= self.cfg['max_code_bytes']:
                try:
                    source = path.read_text(encoding='utf8')
                except UnicodeError:
                    source = ''
            else:
                source = ''
        healthy = self._healthy_source(source)
        if healthy != source or not saved:
            if healthy != source:
                self._quarantine_mirror(path)
                self.event('source_recovered', oid, 'Invalid legacy source quarantined; restored validated source')
            self._write_code(oid, healthy, reason='recovered legacy source' if healthy != source else 'imported legacy source')
        else:
            try:
                matches = path.is_file() and path.stat().st_size <= self.cfg['max_code_bytes'] and path.read_text(encoding='utf8') == source
            except (OSError, UnicodeError):
                matches = False
            if not matches:
                self._quarantine_mirror(path)
                self._mirror_code(path, healthy)
                self.event('source_recovered', oid, 'Restored source mirror from SQLite; conflicting file quarantined')
        return healthy

    def _healthy_source(self, source):
        try:
            rt = Runtime(source)
            if 'risk_gate' not in rt.functions:
                merged, _, _ = merge_one(source, BASELINE)
                source = merged
            if evaluate(source, 'risk_gate', count=20)['score'] < .90:
                merged, _, _ = merge_one(source, BASELINE)
                source = merged
            return source
        except (CapabilityError, TypeError, ValueError):
            return BASELINE

    def _spawn(self, parent=None, force_new=False):
        ancestor = self.store.one('SELECT * FROM organisms WHERE id=?', (parent,)) if parent else None
        generation = int(ancestor['generation']) + 1 if ancestor else 1
        if force_new:
            previous = self.store.one('SELECT COALESCE(MAX(generation),0) AS n FROM organisms')['n']
            generation = max(generation, previous + 1)
        parent_source = self._organism_source(parent) if ancestor else BASELINE
        inherited_source = self._healthy_source(parent_source)
        workspace = ''
        oid = self.store.execute(
            'INSERT INTO organisms(parent,generation,alive,energy,fitness,age,workspace,created) VALUES(?,?,?,?,?,?,?,?)',
            (parent, generation, 1, float(self.cfg['child_energy'] if parent and not force_new else self.cfg['initial_energy']),
             0.0, 0, workspace, utc()))
        folder = self.root / 'workspaces' / f'organism_{oid}'
        folder.mkdir(parents=True, exist_ok=True)
        self._write_code(oid, inherited_source, reason='validated inherited source' if ancestor else 'founder baseline')
        self.store.execute('UPDATE organisms SET workspace=? WHERE id=?',
                           ((folder.relative_to(self.root)).as_posix(), oid))
        self.event('birth', oid, f'Born generation {generation}, parent={parent}; source validated and inherited')
        return oid

    def control(self, command):
        with self.lock:
            if self.stop_flag.is_set():
                raise ValueError('Engine has shut down; restart the application')
            if command not in ('start', 'resume', 'pause', 'stop', 'founder'):
                raise ValueError('Unknown control command')
            self.control_epoch += 1
            if command == 'start':
                if not self.rows('SELECT id FROM organisms WHERE alive=1 LIMIT 1'):
                    self._spawn(force_new=False)
                self.state = 'RUNNING'
            elif command == 'resume':
                if not self.rows('SELECT id FROM organisms WHERE alive=1 LIMIT 1'):
                    self._spawn(force_new=True)
                self.state = 'RUNNING'
            elif command == 'pause':
                self.state = 'PAUSED'
            elif command == 'stop':
                self.state = 'STOPPED'
            elif command == 'founder':
                self.store.execute("UPDATE organisms SET alive=0,death_reason='Manual new founder' WHERE alive=1")
                self._spawn(force_new=True)
                self.state = 'PAUSED'
            else:
                raise ValueError('Unknown control command')
            self.activity = command.title()
            self.event('control', None, command)
            return self.state

    def _resource_warning(self):
        try:
            import psutil
            ram = psutil.virtual_memory().percent
            cpu = psutil.cpu_percent(interval=0.05)
            if ram >= self.cfg['max_ram_percent'] or cpu >= self.cfg['max_cpu_percent']:
                return f'Local resource governor: CPU={cpu}% RAM={ram}%'
        except ImportError:
            pass
        return None

    def _trace(self, oid, purpose, messages, raw, tokens, error=''):
        trace_id = self.store.execute(
            'INSERT INTO traces(ts,organism,purpose,request_json,response_text,tokens,validation,error) VALUES(?,?,?,?,?,?,?,?)',
            (utc(), oid, purpose, _json(messages), raw, int(tokens), '', error))
        self.last_trace = trace_id
        return trace_id

    def _model_call(self, messages, oid, purpose):
        with self.llm_lock:
            if purpose in ('decision', 'json_repair'):
                with self.lock:
                    if self.state != 'RUNNING' or self.stop_flag.is_set():
                        raise RuntimeError('Evolution is paused or stopped; no new inference started')
            if time.monotonic() < self.retry_not_before:
                raise RuntimeError('Ollama retry cooldown active; local tasks continue')
            if not self._budget_available():
                raise RuntimeError('Daily Ollama inference budget exhausted')
            reservation = estimate_tokens(messages) + int(self.cfg['num_predict'])
            if self.daily_tokens + reservation > self.cfg['daily_token_limit']:
                raise RuntimeError('Insufficient daily tokens for a bounded request and response')
            with self.budget_lock:
                self.daily_calls += 1
                self.daily_tokens += reservation
                reservation_day = self.daily_day
                self._save_budget()
            try:
                raw, tokens = self.brain.generate(messages)
                if not isinstance(raw, str) or len(raw.encode('utf8')) > 32000:
                    raise ValueError('Ollama response exceeds the response limit')
                tokens = max(1, int(tokens))
                with self.budget_lock:
                    self._sync_budget()
                    if self.daily_day == reservation_day:
                        self.daily_tokens += tokens - reservation
                    else:
                        # A response crossing midnight must not refund yesterday's
                        # reservation against today's counters.
                        self.daily_calls += 1
                        self.daily_tokens += tokens
                    self._save_budget()
                trace = self._trace(oid, purpose, messages, raw, tokens)
                self.last_error = ''
                return raw, int(tokens), trace
            except Exception as exc:
                # Unknown usage is charged conservatively; retries cannot evade budgets.
                self.retry_not_before = time.monotonic() + self.cfg.get('ollama_retry_seconds', 30)
                self._trace(oid, purpose, messages, '', 0, brief(exc, 300))
                raise

    def _trace_validation(self, trace, validation):
        if trace:
            self.store.execute('UPDATE traces SET validation=? WHERE id=?',
                               (brief(validation, 1800), trace))

    def memory(self, organism, focus_task=None):
        return self.memories.recall(organism, focus_task, self.cfg['max_history_items'])

    def observation(self, organism, include_inspections=True):
        oid = organism['id']
        source = self._organism_source(oid)
        current = scores(source)
        manifest = self.index.manifest()
        task_catalog = public_catalog()
        plan = self.planner.plan(organism, current)
        context = {
            'identity': {'organism': oid, 'generation': organism['generation'],
                         'energy': round(organism['energy'], 2),
                         'fitness': round(organism['fitness'], 2),
                         'age': organism['age'], 'mutations': organism['mutation_count']},
            'project_files': manifest,
            'project_access_rule': 'All allowed files are listed; use inspect action to request up to 3 contents.',
            'organism_file': f'workspaces/organism_{oid}/capabilities.py',
            'organism_source': source[:self.cfg['max_file_inspection_chars']],
            'task_scores': current,
            'recommended_unsolved_tasks': [t for t in sorted(current, key=current.get) if current[t] < .95][:5],
            'focus_task': plan['focus_task'],
            'plan': plan,
            'focus_instruction': plan['instruction'],
            'task_catalog': [{**t, 'examples': t['examples'][:1]} for t in task_catalog],
            'memory': self.memory(organism, plan['focus_task']),
            'student': self.student.stats(),
        }
        if include_inspections:
            record = self.store.one('SELECT value FROM settings WHERE key=?', (f'inspection_{oid}',))
            if record:
                try:
                    requested = json.loads(record['value'])
                    context['requested_file_contents'] = self.index.read_many(requested)
                except (ValueError, TypeError, OSError):
                    context['requested_file_contents'] = {'error': 'failed to inspect requested files'}
                # Retain the inspection request until a successful call consumes it.
        return context

    def _save_proposal(self, oid, command, trace):
        code = str(command.get('function', ''))[:7000]
        fingerprint = canonical_fingerprint(code) if code else None
        function_name = ''
        try:
            tree = ast.parse(code)
            if len(tree.body) == 1 and isinstance(tree.body[0], ast.FunctionDef):
                function_name = tree.body[0].name
        except SyntaxError:
            pass
        pid = self.store.execute(
            'INSERT INTO proposals(ts,organism,action,task,function_name,fingerprint,code,intent,outcome,reason,trace_id) '
            'VALUES(?,?,?,?,?,?,?,?,?,?,?)',
            (utc(), oid, command['action'], str(command.get('task', ''))[:80],
             function_name, fingerprint, code, brief(command.get('hypothesis', ''), 650),
             'pending', '', trace))
        organism = self.store.one('SELECT * FROM organisms WHERE id=?', (oid,))
        before = self._organism_source(oid)
        self.store.execute('UPDATE proposals SET original_action=?,learning=?,generation=?,parent=?,'
                           'base_fingerprint=?,source_before=?,energy_before=? WHERE id=?',
                           (_json(command), brief(command.get('learning', ''), 1000),
                            organism['generation'], organism['parent'], canonical_fingerprint(before),
                            before, organism['energy'], pid))
        return pid, fingerprint, function_name

    def _finish_proposal(self, pid, outcome, reason='', accepted=False, cost=0., reward=0.,
                         train_before=None, holdout_before=None,
                         train_after=None, holdout_after=None):
        canonical = self.store.one('SELECT canonical_reason FROM proposals WHERE id=?', (pid,))
        original_reason = (canonical or {}).get('canonical_reason') or reason
        self.store.execute('UPDATE proposals SET outcome=?,reason=?,accepted=?,cost=?,reward=?,canonical_reason=?,'
                           'train_before=?,holdout_before=?,train_after=?,holdout_after=? WHERE id=?',
                           (brief(outcome, 250), brief(reason, 1000), int(accepted),
                            cost, reward, brief(original_reason, 1000), train_before, holdout_before,
                            train_after, holdout_after, pid))

    def _mutation(self, organism, command, fingerprint, pid):
        task = str(command.get('task', '')).strip()
        proposal = str(command.get('function', ''))
        oid = organism['id']
        old = self._organism_source(oid)
        holdout_seed = self.random.getrandbits(32)
        if len(proposal) > self.cfg['max_function_chars']:
            return False, 'function too long (use one short function)', {}, None
        # Query ONLY earlier attempts, not the current pending proposal.
        earlier = self.store.one('SELECT id,outcome,reason,canonical_reason FROM proposals WHERE id<? '
                                 'AND fingerprint=? AND task=? AND base_fingerprint=? '
                                 'AND (organism=? OR accepted=0) ORDER BY id ASC LIMIT 1',
                                 (pid, fingerprint, task, canonical_fingerprint(old), oid)) if fingerprint else None
        # An already active function is also a duplicate, regardless of unrelated edits.
        if not earlier and fingerprint:
            proposed_name = self.store.one('SELECT function_name FROM proposals WHERE id=?', (pid,))['function_name']
            existing = next((n for n in ast.parse(old).body if isinstance(n, ast.FunctionDef) and n.name == proposed_name), None)
            if existing and canonical_fingerprint(ast.unparse(existing)) == fingerprint:
                earlier = self.store.one('SELECT id,outcome,reason,canonical_reason FROM proposals '
                                         'WHERE id<? AND fingerprint=? AND task=? ORDER BY id ASC LIMIT 1',
                                         (pid, fingerprint, task))
        if earlier:
            canonical = earlier['canonical_reason'] or earlier['reason'] or earlier['outcome']
            self.store.execute('UPDATE proposals SET canonical_reason=?,duplicate_of=? WHERE id=?',
                               (brief(canonical, 500), earlier['id'], pid))
            return False, 'DUPLICATE_PROPOSAL: already attempted; original outcome: ' + brief(canonical, 180), {}, None
        if task not in TASKS and task != 'helper':
            return False, 'unknown task: choose one from task_catalog or helper', {}, None
        try:
            merged, changed, operation = merge_one(old, proposal, self.cfg['max_function_chars'])
            if len(merged.encode('utf8')) > self.cfg['max_code_bytes']:
                raise CapabilityError('complete organism source too large')
            if task == 'helper':
                if changed in TASKS:
                    raise CapabilityError('use its actual task name, not helper')
                # Stage helpers without granting positive energy or fitness.
                if len(Runtime(old).functions) >= 35:
                    raise CapabilityError('too many helper functions')
                if self._regressions(old, merged, holdout_seed):
                    raise CapabilityError('helper would regress an existing capability')
                self._write_code(oid, merged)
                self.store.execute('UPDATE proposals SET source_after=? WHERE id=?', (merged, pid))
                return False, f'staged helper {changed}, not yet rewarded', {}, merged
            if changed != task:
                raise CapabilityError(f'function must be named {task} for this task (got {changed})')
            before_train = evaluate(old, task, seed=211, count=40)
            before_holdout = evaluate_holdout(old, task, seed=holdout_seed, count=64)
            after_train = evaluate(merged, task, seed=211, count=40)
            after_holdout = evaluate_holdout(merged, task, seed=holdout_seed, count=64)
            detail = dict(train_before=before_train['score'], holdout_before=before_holdout['score'],
                          train_after=after_train['score'], holdout_after=after_holdout['score'])
            evaluations = dict(train_before=before_train, holdout_before=before_holdout,
                               train_after=after_train, holdout_after=after_holdout,
                               train_seed=211, holdout_seed=holdout_seed)
            self.store.execute('UPDATE proposals SET evaluation_json=? WHERE id=?', (_json(evaluations), pid))
            # Verify improvement on both distributions, not just syntax or novelty.
            improved = (after_train['score'] >= before_train['score'] + .04 and
                        after_holdout['score'] >= before_holdout['score'] + .04 and
                        after_holdout['score'] >= .75 and after_train['score'] >= .70)
            if not improved:
                return False, (f'no verified train+holdout improvement for {task}: '
                               f'{before_train["score"]:.2f}/{before_holdout["score"]:.2f} -> '
                               f'{after_train["score"]:.2f}/{after_holdout["score"]:.2f}; '
                               f'errors: {after_holdout["errors"][:1]}'), detail, None
            # A helper replacement must not break previously working task functions.
            regressed = self._regressions(old, merged, holdout_seed, exclude=task)
            if regressed:
                return False, 'regression in existing capabilities: ' + ', '.join(regressed), detail, None
            self._write_code(oid, merged)
            self.store.execute('UPDATE organisms SET mutation_count=mutation_count+1 WHERE id=?', (oid,))
            diff = ''.join(difflib.unified_diff(old.splitlines(True), merged.splitlines(True),
                                                 fromfile='previous/capabilities.py',
                                                 tofile='accepted/capabilities.py'))
            self.store.execute('UPDATE proposals SET source_after=?,diff=? WHERE id=?', (merged, diff, pid))
            self.event('mutation', oid,
                       f'ACCEPT {operation} {changed}, hidden {before_holdout["score"]:.2f} -> {after_holdout["score"]:.2f}; '+brief(diff, 350))
            return True, (f'accepted {operation} {task}, training {before_train["score"]:.2f} -> {after_train["score"]:.2f}, '
                          f'heldout {before_holdout["score"]:.2f} -> {after_holdout["score"]:.2f}'), detail, merged
        except (CapabilityError, SyntaxError, ValueError, TypeError, ArithmeticError, RecursionError) as exc:
            return False, 'rejected: ' + brief(exc, 300), {}, None

    def _regressions(self, old, new, seed, exclude=None):
        before, after = scores(old), scores(new)
        regressed = []
        for name in TASKS:
            if name == exclude:
                continue
            old_holdout = evaluate_holdout(old, name, seed=seed, count=64)['score']
            new_holdout = evaluate_holdout(new, name, seed=seed, count=64)['score']
            if after[name] < before[name] or new_holdout < old_holdout:
                regressed.append(name)
        return regressed

    def _write_code(self, oid, merged, reason='validated capability update'):
        Runtime(merged)
        path = self._source_path(oid)
        fingerprint = canonical_fingerprint(merged)
        # On interruption, SQLite's committed revision restores the readable mirror.
        with self.store.transaction() as conn:
            conn.execute('INSERT INTO code_revisions(ts,organism,source,fingerprint,reason) VALUES(?,?,?,?,?)',
                         (utc(), oid, merged, fingerprint, reason))
            conn.execute('INSERT OR REPLACE INTO organism_code(organism,source,fingerprint,updated) VALUES(?,?,?,?)',
                         (oid, merged, fingerprint, utc()))
            self._mirror_code(path, merged)

    def _model_experiment(self, command):
        params = command.get('params') or {}
        if not isinstance(params, dict):
            raise ValueError('model_experiment params must be an object')
        result = self.student.train_candidate(
            params.get('hidden1', 16), params.get('hidden2', 12),
            params.get('learning_rate', .03), params.get('epochs', 90))
        return result

    def _record_episode(self, oid, observation, action, outcome, lesson, net, pid=None):
        # Include a concise snapshot; full prompts are saved in traces.
        compact = {'identity': observation.get('identity'),
                   'task_scores': observation.get('task_scores'),
                   'previous_feedback': observation.get('memory', {}).get('last_proposals', [])[:3]}
        self.store.execute('INSERT INTO episodes(ts,organism,cycle,observation_json,action,outcome,lesson,energy_delta,proposal_id) '
                           'VALUES(?,?,?,?,?,?,?,?,?)',
                           (utc(), oid, self.cycle_number, _json(compact), action,
                            brief(outcome, 450), brief(lesson, 500), round(net, 3), pid))
        if lesson and action in ('mutate', 'reflect', 'model_experiment'):
            self.store.execute('INSERT INTO notes(ts,organism,text) VALUES(?,?,?)',
                               (utc(), oid, brief(lesson, 320)))

    def _decide(self, organism):
        oid = organism['id']
        with self.lock:
            if self.state != 'RUNNING' or self.stop_flag.is_set():
                return
            epoch = self.control_epoch
            obs = self.observation(organism)
        messages = build_messages(obs, num_ctx=int(self.cfg['num_ctx']),
                                  num_predict=int(self.cfg['num_predict']))
        self.activity = f'Qwen observing organism {oid} and project'
        try:
            raw, tokens, trace = self._model_call(messages, oid, 'decision')
        except (ConnectionError, RuntimeError, TimeoutError, ValueError) as exc:
            self.last_error = brief(exc, 300)
            self.event('brain_error', oid, self.last_error)
            self.activity = 'Qwen unavailable; running local tasks only'
            return
        cost = self.cfg['thinking_cost'] + tokens * self.cfg['energy_per_token']
        with self.lock:
            if self.state != 'RUNNING' or epoch != self.control_epoch:
                self._apply_energy(oid, -cost)
                self._trace_validation(trace, 'cancelled after control change; no repair or mutation executed')
                self._record_episode(oid, obs, 'cancelled', 'Decision cancelled by user control', '', -cost)
                return
        # Successfully delivered requested files; they remain in the exact saved trace.
        self.store.execute('DELETE FROM settings WHERE key=?', (f'inspection_{oid}',))
        parse_options = dict(allowed_paths=self.index, max_function_chars=self.cfg['max_function_chars'])
        try:
            try:
                cmd = parse_action(raw, **parse_options)
            except ValueError as error:
                self._trace_validation(trace, 'Protocol error: ' + brief(error, 500))
                self.event('json_repair', oid, 'One bounded protocol repair: ' + brief(error, 250))
                repair_obs = {'protocol_error': brief(error, 400), 'original_response': raw[:1200],
                              'focus_task': obs['focus_task'], 'task_catalog': obs['task_catalog'],
                              'instruction': 'Correct the exact schema error. If required data is unavailable, '
                                             'return action reflect with a concise learning. Do not invent test results.'}
                repair = build_messages(repair_obs, num_ctx=int(self.cfg['num_ctx']),
                                        num_predict=int(self.cfg['num_predict']))
                repaired, repair_tokens, repair_trace = self._model_call(repair, oid, 'json_repair')
                cost += repair_tokens * self.cfg['energy_per_token']
                cmd = parse_action(repaired, **parse_options)
                self._trace_validation(repair_trace, 'Repaired protocol; linked decision trace ' + str(trace))
        except (ValueError, ConnectionError, RuntimeError, TypeError, TimeoutError) as exc:
            self._trace_validation(trace, 'invalid response after repair: ' + brief(exc, 200))
            with self.lock:
                self._apply_energy(oid, -cost)
                self._record_episode(oid, obs, 'invalid', 'Protocol error: ' + brief(exc, 250),
                                     'Use the required fields; the repair budget is one attempt.', -cost)
            self.event('protocol_error', oid, brief(exc, 250))
            return
        with self.lock:
            current = self.store.one('SELECT * FROM organisms WHERE id=?', (oid,))
            if self.state != 'RUNNING' or epoch != self.control_epoch or not current or not current['alive']:
                self._trace_validation(trace, 'cancelled after control change; inference cost charged')
                self._apply_energy(oid, -cost)
                self._record_episode(oid, obs, 'cancelled', 'Decision cancelled by user control', '', -cost)
                return
            started = time.perf_counter()
            pid, fingerprint, func = self._save_proposal(oid, cmd, trace)
            completion = self.store.transaction() if cmd['action'] == 'mutate' else nullcontext()
            with completion:
                action = cmd['action']
                accepted, reward, detail = False, 0.0, {}
                if action == 'mutate':
                    cost += self.cfg['mutation_cost']
                    accepted, result, detail, _ = self._mutation(current, cmd, fingerprint, pid)
                    if result.startswith('DUPLICATE_PROPOSAL'):
                        cost -= self.cfg['mutation_cost']
                    if accepted:
                        reward = cost + float(self.cfg['successful_edit_surplus'])
                elif action == 'inspect':
                    paths = cmd['paths']
                    contents = self.index.read_many(paths)
                    permitted = [path for path, data in contents.items() if not data.startswith('File not available')]
                    if not permitted:
                        result = 'INSPECT_REJECTED: no permitted readable paths; use project_files paths'
                    else:
                        self.store.execute('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)',
                                           (f'inspection_{oid}', _json(permitted)))
                        result = 'file inspection scheduled for NEXT Qwen call: ' + ', '.join(permitted)
                elif action == 'model_experiment':
                    try:
                        candidate = self._model_experiment(cmd)
                        accepted = bool(candidate.get('promoted'))
                        result = 'model experiment: ' + brief(candidate, 600)
                        if accepted:
                            reward = cost + float(self.cfg['successful_edit_surplus'])
                    except (ValueError, TypeError, OSError, FloatingPointError) as exc:
                        result = 'model experiment rejected: ' + brief(exc, 250)
                else:
                    result = 'reflection saved; next plan considers measured task scores'
                    preferred = cmd.get('next_task')
                    if preferred in TASKS:
                        self.store.execute('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)',
                                           (f'planner_next_task_{oid}', preferred))
                self._finish_proposal(pid, result, result if not accepted else '', accepted, cost, reward,
                                      detail.get('train_before'), detail.get('holdout_before'),
                                      detail.get('train_after'), detail.get('holdout_after'))
                before_energy = self.store.one('SELECT energy FROM organisms WHERE id=?', (oid,))['energy']
                self._apply_energy(oid, reward - cost, fitness=(2.0 if accepted else 0))
                after_energy = self.store.one('SELECT energy FROM organisms WHERE id=?', (oid,))['energy']
                net = round(after_energy - before_energy, 6)
                self.store.execute('UPDATE proposals SET net_energy=?,energy_before=?,energy_after=?,execution_ms=? WHERE id=?',
                                   (net, before_energy, after_energy, (time.perf_counter() - started) * 1000, pid))
                lesson = (result + '; ' + str(cmd.get('learning', '')))[:500]
                self._record_episode(oid, obs, action, result, lesson, net, pid)
                self._trace_validation(trace, f'{result}; cost={cost:.2f}; reward={reward:.2f}; net={net:+.2f}')
                self.event('action', oid, f'{action} | {brief(result, 300)} | cost={cost:.2f} reward={reward:.2f} net={net:+.2f}')
                self.activity = f'Organism {oid}: {brief(result, 90)}'

    def _apply_energy(self, oid, net, fitness=0.):
        self.store.execute('UPDATE organisms SET energy=MIN(?,MAX(0,energy+?)),fitness=fitness+? WHERE id=?',
                           (self.cfg['max_energy'], net, fitness, oid))

    def _experience(self, organism):
        oid = organism['id']
        source = self._organism_source(oid)
        # Favor learned tasks often enough to provide survival resources, but also
        # probe unsolved challenges to learn what is missing.
        available = [n for n in TASKS if n in Runtime(source).functions]
        if available and self.random.random() < .65:
            name = self.random.choice(available)
            from .tasks import TASKS as CATALOG
            task = CATALOG[name]
            args = task.generator(self.random)
            try:
                actual = Runtime(source).call(name, *args)
                expected = task.oracle(*args)
                trial = dict(task=name, inputs=list(args), actual=actual,
                             expected=expected, correct=type(actual) == type(expected) and actual == expected)
            except (CapabilityError, ArithmeticError, ValueError, TypeError) as exc:
                trial = dict(task=name, inputs=list(args), actual='error: '+brief(exc, 100),
                             expected=task.oracle(*args), correct=False)
        else:
            trial = environment_challenge(source, self.random)
        # Once trained and independently validated, the new neural model may
        # autonomously act on a small fraction of risk_gate challenges. Its
        # predictions are still checked against the task oracle and logged.
        trial['actor'] = 'organism_function'
        if (trial['task'] == 'risk_gate' and self.student.weights is not None
                and float(self.student.meta.get('current_validation_accuracy', self.student.meta.get('accuracy', 0))) >= .90
                and self.cycle_number % 4 == 0):
            prediction = self.student.predict(*trial['inputs'])
            if (prediction['ready'] and
                    prediction.get('confidence', 0) >= self.cfg.get('student_min_confidence', .80)):
                trial['actor'] = 'trained_neural_student'
                trial['actual'] = prediction['prediction']
                trial['correct'] = trial['actual'] == trial['expected']
        # Ecological resources: correct execution earns nourishment, failures cost.
        net = 1.8 if trial['correct'] else -0.55
        self.store.execute('INSERT INTO trials(ts,organism,task,inputs_json,expected_json,actual_json,correct,reward,actor) '
                           'VALUES(?,?,?,?,?,?,?,?,?)',
                           (utc(), oid, trial['task'], _json(trial['inputs']), _json(trial['expected']),
                            _json(trial['actual']), int(trial['correct']), net, trial['actor']))
        self._apply_energy(oid, net, fitness=(.25 if trial['correct'] else 0))
        if trial['task'] == 'risk_gate':
            args = trial['inputs']
            label = int(trial['expected'] == 'explore')
            self.store.execute('INSERT INTO student_examples(energy,failures,label) VALUES(?,?,?)',
                               (args[0], args[1], label))
        if self.cycle_number % 5 == 0 or not trial['correct']:
            self.event('trial', oid, f'{trial["task"]}({trial["inputs"]}) [{trial["actor"]}]: '
                       f'{"correct" if trial["correct"] else "failed"}; net={net:+.2f}')
        return trial

    def _death_and_birth(self, oid):
        o = self.store.one('SELECT * FROM organisms WHERE id=?', (oid,))
        if o is None or not o['alive']:
            return
        if o['energy'] <= 0 or o['age'] >= self.cfg['max_age']:
            cause = 'energy exhausted' if o['energy'] <= 0 else 'age limit'
            self.store.execute('UPDATE organisms SET alive=0,death_reason=? WHERE id=?', (cause, oid))
            self.event('death', oid, cause)
            return
        live = self.store.one('SELECT COUNT(*) AS n FROM organisms WHERE alive=1')['n']
        if (o['energy'] >= self.cfg['birth_energy'] and o['fitness'] >= 8 and
                live < self.cfg['max_population']):
            self._apply_energy(oid, -self.cfg['birth_cost'])
            child = self._spawn(parent=oid)
            self.event('reproduction', oid, f'Produced organism {child}; inherited validated capabilities')

    def _reseed(self):
        if time.monotonic() - self.last_reseed_at < self.cfg['reseed_cooldown_seconds']:
            return
        champion = self.store.one('SELECT * FROM organisms ORDER BY mutation_count DESC,fitness DESC,id DESC LIMIT 1')
        child = self._spawn(parent=champion['id'] if champion else None, force_new=True)
        self.event('rebirth', child, 'Rebuilt population from best inherited source; repaired baseline if needed')
        self.last_reseed_at = time.monotonic()

    def _maybe_train_student(self):
        count = self.store.one('SELECT COUNT(*) AS n FROM student_examples')['n']
        if count >= 70 and count - self.last_student_train_samples >= self.cfg['model_train_every_samples']:
            try:
                result = self.student.train_candidate()
                self.last_student_train_samples = count
                self.event('student_training', None, brief(result, 500))
            except (ValueError, TypeError, OSError, FloatingPointError) as exc:
                self.event('student_error', None, brief(exc, 250))

    def step(self):
        if not self.step_lock.acquire(blocking=False):
            return
        try:
            self._step()
        finally:
            self.step_lock.release()

    def _step(self):
        """One complete cycle. Do not hold the control lock during slow Ollama I/O."""
        with self.lock:
            if self.state != 'RUNNING':
                return
            warning = self._resource_warning()
            if warning:
                self.activity = warning
                return
            living = self.rows('SELECT * FROM organisms WHERE alive=1 ORDER BY id')
            if not living:
                self._reseed()
                return
            self.cycle_number += 1
            self.store.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('cycle_number',?)",
                               (str(self.cycle_number),))
            organism = self.random.choice(living)
            oid = organism['id']
            self.store.execute('UPDATE organisms SET age=age+1 WHERE id=?', (oid,))
            self._experience(organism)
            self._maybe_train_student()
            fresh = self.store.one('SELECT * FROM organisms WHERE id=?', (oid,))
            # Adaptive backoff on three recent failed proposals, without blocking
            # the local life cycle or permanently silencing the brain.
            plan = self.planner.plan(fresh, scores(self._organism_source(oid)))
            period = int(self.cfg['brain_every_cycles'] * plan['cooldown_multiplier'])
            should_call = (self.cycle_number % period == 0 and
                           fresh['energy'] >= 8 and self._budget_available() and
                           time.monotonic() >= self.retry_not_before)
        if should_call:
            self._decide(fresh)
        with self.lock:
            if self.state == 'RUNNING':
                self._death_and_birth(oid)

    def loop(self):
        while not self.stop_flag.is_set():
            try:
                self.step()
            except Exception as exc:
                self.last_error = brief(exc, 500)
                self.event('error', None, self.last_error)
            self.stop_flag.wait(self.cfg['cycle_seconds'])

    def shutdown(self):
        with self.lock:
            self.state = 'STOPPED'
            self.control_epoch += 1
            self.stop_flag.set()
        if self.worker and self.worker is not threading.current_thread():
            self.worker.join(timeout=2)

    def status(self):
        self._sync_budget()
        living = self.rows('SELECT * FROM organisms WHERE alive=1 ORDER BY id')
        totals = self.store.one('SELECT COUNT(*) AS births, SUM(CASE WHEN alive=0 THEN 1 ELSE 0 END) AS deaths FROM organisms')
        accepted = self.store.one('SELECT COUNT(*) AS n FROM proposals WHERE accepted=1')['n']
        rejected = self.store.one('SELECT COUNT(*) AS n FROM proposals WHERE action="mutate" AND accepted=0')['n']
        return dict(state=self.state, activity=self.activity, error=self.last_error,
                    population=len(living), capacity=self.cfg['max_population'],
                    generation=max((o['generation'] for o in living), default=0),
                    births=totals['births'], deaths=totals['deaths'] or 0,
                    avg_energy=round(sum(o['energy'] for o in living) / max(1, len(living)), 1),
                    accepted=accepted, rejected=rejected,
                    cycle=self.cycle_number, model=self.cfg['model'],
                    calls=self.daily_calls, call_limit=self.cfg['daily_calls_limit'],
                    tokens=self.daily_tokens, token_limit=self.cfg['daily_token_limit'],
                    student=self.student.stats(),
                    db_mb=round(self.store.path.stat().st_size / 1048576, 3))

    def chat(self, question, brain='qwen'):
        if brain == 'student':
            # Student speaks only about the limited policy it actually learned.
            living = self.rows('SELECT energy FROM organisms WHERE alive=1 ORDER BY id DESC LIMIT 1')
            energy = living[0]['energy'] if living else 60.0
            prediction = self.student.predict(energy, 0)
            return {'brain': 'neural-student', 'answer': _json(prediction),
                    'caveat': 'Only risk_gate classification, not a conversational LLM'}
        living = self.rows('SELECT * FROM organisms WHERE alive=1 ORDER BY id DESC LIMIT 1')
        if living:
            obs = self.observation(living[0], include_inspections=False)
        else:
            obs = {'project_files': self.index.manifest(), 'task_catalog': public_catalog()}
        obs['user_question'] = question
        prompt = build_messages(obs, num_ctx=int(self.cfg['num_ctx']), num_predict=int(self.cfg['num_predict']),
                                system=SYSTEM + '\nFor user_question return action reflect with learning containing your answer.')
        raw, tokens, trace = self._model_call(prompt, living[0]['id'] if living else None, 'user_chat')
        try:
            result = parse_action(raw)
            answer = str(result.get('learning') or result.get('hypothesis') or raw)
        except ValueError:
            answer = raw
        self._trace_validation(trace, 'user chat, no code executed')
        return {'brain': self.cfg['model'], 'answer': answer, 'tokens': tokens}
