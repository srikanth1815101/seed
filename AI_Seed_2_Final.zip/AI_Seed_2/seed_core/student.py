"""A locally trained, bounded NumPy MLP for the narrow risk_gate task.

Observed examples remain in SQLite. Stable input partitions keep repeated
observations out of other splits, even after restart or new training samples.
The student is a classifier, not a language model or a replacement for Qwen.
"""
import hashlib
import json
import math
import numbers
import os
import shutil
import tempfile
import threading
import uuid
import zipfile
from pathlib import Path

import numpy as np


MAX_CHECKPOINT_BYTES = 2_000_000
SPLIT_VERSION = 'risk-input-sha256-v1'


def features(energy, failures):
    if (isinstance(energy, bool) or not isinstance(energy, numbers.Real)
            or not math.isfinite(float(energy))):
        raise ValueError('energy must be a finite number')
    if (isinstance(failures, bool) or not isinstance(failures, numbers.Integral)
            or not 0 <= int(failures) <= 8 or not 0 <= float(energy) <= 150):
        raise ValueError('Student domain: energy 0..150 and integer failures 0..8')
    e, f = float(energy), int(failures)
    return [e / 150.0, f / 8.0, min(e / 25.0, 2.0), min(f / 3.0, 2.0), 1.0]


def _softmax(z):
    z = z - z.max(axis=1, keepdims=True)
    exp = np.exp(z)
    return exp / exp.sum(axis=1, keepdims=True)


def _input_key(energy, failures):
    return f'{float(energy):.17g}:{int(failures)}'


def _partition(key):
    bucket = int.from_bytes(hashlib.sha256(key.encode('ascii')).digest()[:4], 'big') % 100
    return 'train' if bucket < 70 else ('validation' if bucket < 85 else 'audit')


def _atomic_bytes(path, content):
    fd, name = tempfile.mkstemp(prefix='.' + path.name, dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


class NeuralStudent:
    def __init__(self, root, store):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.store = store
        self.checkpoint = self.root / 'student_policy.npz'
        self.meta_path = self.root / 'student_meta.json'
        self.lock = threading.RLock()
        self.meta = {'trained': False, 'accuracy': 0.0, 'samples': 0,
                     'hidden1': 16, 'hidden2': 12, 'note': 'No trained policy yet'}
        self.weights = None
        if self.checkpoint.exists():
            try:
                weights, metadata = self._load_checkpoint(self.checkpoint)
                self.weights, self.meta = weights, metadata
                self._restore_current_validation()
            except (ValueError, OSError, KeyError, TypeError, EOFError, OverflowError, RecursionError, zipfile.BadZipFile) as exc:
                self.meta['checkpoint_error'] = str(exc)[:200]
                self.meta['note'] = 'Checkpoint could not be validated; training can create a new champion'

    def _champion_identity(self):
        if self.meta.get('candidate_id'):
            return self.meta['candidate_id']
        digest = hashlib.sha256()
        for array in self.weights:
            digest.update(array.tobytes())
        return 'legacy-' + digest.hexdigest()

    def _restore_current_validation(self):
        record = self.store.one("SELECT value FROM settings WHERE key='student_validation_current'")
        if not record:
            return
        try:
            saved = json.loads(record['value'])
            accuracy = saved['current_validation_accuracy']
            if (saved['champion_id'] == self._champion_identity() and type(accuracy) in (int, float)
                    and math.isfinite(accuracy) and 0 <= accuracy <= 1
                    and type(saved['current_validation_samples']) is int
                    and saved['current_validation_samples'] > 0):
                self.meta.update({key: saved[key] for key in ('current_validation_accuracy',
                                                             'current_validation_samples',
                                                             'current_validation_fingerprint')})
        except (ValueError, TypeError, KeyError):
            pass  # A corrupt optional measurement cannot invalidate otherwise valid weights.

    def _record_current_validation(self, accuracy, keys):
        measured = {'current_validation_accuracy': round(accuracy, 4),
                    'current_validation_samples': len(keys),
                    'current_validation_fingerprint': hashlib.sha256(json.dumps(keys).encode()).hexdigest()}
        self.store.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('student_validation_current',?)",
                           (json.dumps({'champion_id': self._champion_identity(), **measured}),))
        self.meta.update(measured)

    @staticmethod
    def _backup_file(path):
        if not path.exists():
            return None
        backup = path.parent / ('.rollback-' + uuid.uuid4().hex)
        try:
            # A hard link snapshots the old inode while replacement stays atomic.
            # The copy fallback uses bounded buffers for filesystems without links.
            try:
                os.link(path, backup)
            except OSError:
                with path.open('rb') as source, backup.open('xb') as target:
                    shutil.copyfileobj(source, target, length=1024 * 1024)
                    target.flush()
                    os.fsync(target.fileno())
            return backup
        except Exception:
            backup.unlink(missing_ok=True)
            raise

    @staticmethod
    def _validate_weights(weights):
        if len(weights) != 6:
            raise ValueError('Expected six MLP weight arrays')
        w1, w2, w3, b1, b2, b3 = weights
        if w1.ndim != 2 or w2.ndim != 2:
            raise ValueError('Invalid model weight dimensions')
        h1, h2 = w1.shape[1], w2.shape[1]
        if not 4 <= h1 <= 64 or not 4 <= h2 <= 64:
            raise ValueError('Model architecture exceeds supported limits')
        expected = [(5, h1), (h1, h2), (h2, 2), (h1,), (h2,), (2,)]
        for array, shape in zip(weights, expected):
            if (array.shape != shape or array.dtype.kind != 'f'
                    or not np.isfinite(array).all() or np.max(np.abs(array), initial=0) > 1_000_000):
                raise ValueError('Invalid, nonfinite or unbounded model weights')
        return h1, h2

    def _load_checkpoint(self, path):
        if path.stat().st_size > MAX_CHECKPOINT_BYTES:
            raise ValueError('Checkpoint exceeds size limit')
        with zipfile.ZipFile(path) as archive:
            required = {f'{prefix}{i}.npy' for prefix in ('w', 'b') for i in range(1, 4)}
            names = [info.filename for info in archive.infolist()]
            if (len(names) != len(set(names)) or not required <= set(names)
                    or not set(names) <= required | {'metadata.npy'}
                    or sum(info.file_size for info in archive.infolist()) > MAX_CHECKPOINT_BYTES):
                raise ValueError('Expanded checkpoint has unexpected contents or exceeds size limit')
            # Check declared .npy allocations before loading: a tiny archive can
            # otherwise declare an enormous array with a forged shape header.
            for info in archive.infolist():
                with archive.open(info) as handle:
                    version = np.lib.format.read_magic(handle)
                    if version == (1, 0):
                        shape, _, dtype = np.lib.format.read_array_header_1_0(handle)
                    elif version == (2, 0):
                        shape, _, dtype = np.lib.format.read_array_header_2_0(handle)
                    else:
                        raise ValueError('Unsupported checkpoint array format')
                    size = math.prod(shape) * dtype.itemsize
                    if (len(shape) > 2 or size > MAX_CHECKPOINT_BYTES
                            or dtype.hasobject or size != info.file_size - handle.tell()):
                        raise ValueError('Checkpoint array shape/size is invalid')
        with np.load(path, allow_pickle=False) as data:
            weights = [data[f'w{i}'].copy() for i in range(1, 4)] + [data[f'b{i}'].copy() for i in range(1, 4)]
            h1, h2 = self._validate_weights(weights)
            if 'metadata' in data:
                encoded = data['metadata']
                if encoded.shape != () or encoded.dtype.kind != 'U' or encoded.itemsize > 100_000:
                    raise ValueError('Invalid embedded model metadata')
                metadata = json.loads(str(encoded.item()))
            else:
                # Compatibility with the uploaded version's separate metadata.
                if not self.meta_path.exists() or self.meta_path.stat().st_size > 100_000:
                    raise ValueError('Legacy checkpoint requires valid student_meta.json')
                metadata = json.loads(self.meta_path.read_text(encoding='utf8'))
        if not isinstance(metadata, dict):
            raise ValueError('Model metadata must be an object')
        accuracy = metadata.get('accuracy')
        if (isinstance(accuracy, bool) or not isinstance(accuracy, (int, float))
                or not math.isfinite(accuracy) or not 0 <= accuracy <= 1):
            raise ValueError('Invalid checkpoint validation accuracy')
        if metadata.get('hidden1') != h1 or metadata.get('hidden2') != h2:
            raise ValueError('Model metadata does not match its weight architecture')
        return weights, {**metadata, 'trained': True}

    @staticmethod
    def _forward(x, weights):
        w1, w2, w3, b1, b2, b3 = weights
        a1 = np.tanh(x @ w1 + b1)
        a2 = np.tanh(a1 @ w2 + b2)
        return a1, a2, _softmax(a2 @ w3 + b3)

    def _dataset(self):
        rows = self.store.rows('SELECT energy,failures,label FROM student_examples ORDER BY id DESC LIMIT 3000')
        unique = {}
        for row in rows:
            features(row['energy'], row['failures'])  # Check actual observations before NumPy conversion.
            label = row['label']
            if type(label) is not int or label not in (0, 1):
                raise ValueError('Student labels must be integers 0 or 1')
            key = _input_key(row['energy'], row['failures'])
            if key in unique and unique[key]['label'] != label:
                raise ValueError('Conflicting labels for the same observed input')
            unique[key] = row
        groups = {}
        for split in ('train', 'validation', 'audit'):
            keys = sorted(key for key in unique if _partition(key) == split)
            groups[split] = (np.asarray([features(unique[key]['energy'], unique[key]['failures']) for key in keys],
                                      dtype=np.float64).reshape(-1, 5),
                             np.asarray([unique[key]['label'] for key in keys], dtype=np.int64), keys)
        return groups, len(rows), len(unique)

    @staticmethod
    def _measure(x, y, weights):
        p = NeuralStudent._forward(x, weights)[-1]
        accuracy = float(np.mean(p.argmax(axis=1) == y))
        loss = float(-np.log(np.clip(p[np.arange(len(y)), y], 1e-12, 1)).mean())
        return accuracy, loss

    @staticmethod
    def _parameters(hidden1, hidden2, learning_rate, epochs):
        for name, value, low, high in [('hidden1', hidden1, 4, 64), ('hidden2', hidden2, 4, 64),
                                      ('epochs', epochs, 10, 160)]:
            if isinstance(value, bool) or not isinstance(value, numbers.Integral) or not low <= value <= high:
                raise ValueError(f'{name} must be an integer in {low}..{high}')
        if (isinstance(learning_rate, bool) or not isinstance(learning_rate, numbers.Real)
                or not math.isfinite(float(learning_rate)) or not .001 <= learning_rate <= .1):
            raise ValueError('learning_rate must be a finite number in 0.001..0.1')
        return int(hidden1), int(hidden2), float(learning_rate), int(epochs)

    def _save_checkpoint(self, path, weights, metadata):
        self._validate_weights(weights)
        fd, name = tempfile.mkstemp(prefix='.student-', suffix='.npz', dir=path.parent)
        try:
            with os.fdopen(fd, 'wb') as handle:
                np.savez_compressed(handle, w1=weights[0], w2=weights[1], w3=weights[2],
                                    b1=weights[3], b2=weights[4], b3=weights[5],
                                    metadata=np.asarray(json.dumps(metadata, sort_keys=True, allow_nan=False)))
                handle.flush()
                os.fsync(handle.fileno())
            self._load_checkpoint(Path(name))
            os.replace(name, path)
        finally:
            if os.path.exists(name):
                os.unlink(name)

    def train_candidate(self, hidden1=16, hidden2=12, learning_rate=0.04, epochs=90, persist=True):
        h1, h2, lr, epochs = self._parameters(hidden1, hidden2, learning_rate, epochs)
        if type(persist) is not bool:
            raise ValueError('persist must be a boolean')
        with self.lock:
            groups, rows, unique = self._dataset()
            xtr, ytr, train_keys = groups['train']
            xv, yv, valid_keys = groups['validation']
            xa, ya, audit_keys = groups['audit']
            stored_samples = self.store.one('SELECT COUNT(*) AS n FROM student_examples')['n']
            if (unique < 70 or len(xtr) < 40 or len(xv) < 8 or len(xa) < 8
                    or len(set(ytr.tolist())) < 2 or len(set(yv.tolist())) < 2):
                return {'trained': False, 'promoted': False, 'samples': stored_samples,
                        'unique_samples': unique,
                        'reason': 'Need >=70 distinct observed inputs, both training/validation classes, and >=8 validation/audit inputs'}
            rng = np.random.default_rng(177 + h1 * 13 + h2)
            weights = [rng.normal(0, .25, (5, h1)), rng.normal(0, .25, (h1, h2)),
                       rng.normal(0, .25, (h2, 2)), np.zeros(h1), np.zeros(h2), np.zeros(2)]
            w1, w2, w3, b1, b2, b3 = weights
            best, best_loss, best_score = None, float('inf'), -1.0
            for epoch in range(epochs):
                for subset in np.array_split(rng.permutation(len(xtr)), max(1, len(xtr) // 48)):
                    xx, yy = xtr[subset], ytr[subset]
                    a1, a2, p = self._forward(xx, weights)
                    dz3 = p.copy()
                    dz3[np.arange(len(yy)), yy] -= 1
                    dz3 /= len(yy)
                    dw3, db3 = a2.T @ dz3, dz3.sum(axis=0)
                    dz2 = (dz3 @ w3.T) * (1 - a2 * a2)
                    dw2, db2 = a1.T @ dz2, dz2.sum(axis=0)
                    dz1 = (dz2 @ w2.T) * (1 - a1 * a1)
                    dw1, db1 = xx.T @ dz1, dz1.sum(axis=0)
                    for param, grad in ((w1, dw1), (w2, dw2), (w3, dw3),
                                        (b1, db1), (b2, db2), (b3, db3)):
                        param -= lr * np.clip(grad, -2, 2)
                # Select checkpoints with validation only; audit labels never affect learning or selection.
                if epoch % 5 == 4 or epoch == epochs - 1:
                    score, loss = self._measure(xv, yv, weights)
                    if score > best_score or (score == best_score and loss < best_loss):
                        best = [array.copy() for array in weights]
                        best_score, best_loss = score, loss
            weights = best
            self._validate_weights(weights)
            accuracy, _ = self._measure(xv, yv, weights)
            train_accuracy, _ = self._measure(xtr, ytr, weights)
            previous = self._measure(xv, yv, self.weights)[0] if self.weights is not None else None
            if persist and previous is not None:
                self._record_current_validation(previous, valid_keys)
            # Compare the champion and candidate on exactly the same examples, not stale historical scores.
            promoted = self.weights is None or accuracy > previous + .005
            audit_accuracy, _ = self._measure(xa, ya, weights)
            champion_audit = self._measure(xa, ya, self.weights)[0] if self.weights is not None else None
            candidate_id = uuid.uuid4().hex
            candidate = {'trained': True, 'accuracy': round(accuracy, 4),
                         'current_validation_accuracy': round(accuracy, 4),
                         'current_validation_samples': len(xv),
                         'current_validation_fingerprint': hashlib.sha256(json.dumps(valid_keys).encode()).hexdigest(),
                         'train_accuracy': round(train_accuracy, 4), 'audit_accuracy': round(audit_accuracy, 4),
                         'samples': stored_samples, 'dataset_rows': rows, 'unique_samples': unique,
                         'hidden1': h1, 'hidden2': h2, 'learning_rate': lr, 'epochs': epochs,
                         'training_samples': len(xtr), 'validation_samples': len(xv), 'audit_samples': len(xa),
                         'split_version': SPLIT_VERSION,
                         'dataset_fingerprint': hashlib.sha256(json.dumps({k: groups[k][2] for k in groups},
                                                                          sort_keys=True).encode()).hexdigest(),
                         'promoted': promoted, 'previous_accuracy': previous,
                         'previous_audit_accuracy': champion_audit, 'candidate_id': candidate_id,
                         'note': 'Learned risk_gate MLP, not a language model; audit held out of training and selection',
                         'domain': {'energy': [0, 150], 'failures': [0, 8]},
                         'benchmark_limit': 'Repeated validation selection can overfit; audit is diagnostic, not promotion evidence'}
            if persist:
                folder = self.root / 'candidates'
                folder.mkdir(exist_ok=True)
                artifact = folder / f'student_{candidate_id}.npz'
                candidate['artifact'] = artifact.relative_to(self.root.parent).as_posix()
                self._save_checkpoint(artifact, weights, candidate)
                backups = []
                committed = False
                try:
                    if promoted:
                        for path in (self.checkpoint, self.meta_path):
                            backups.append((path, self._backup_file(path)))
                        self._save_checkpoint(self.checkpoint, weights, candidate)
                        _atomic_bytes(self.meta_path, json.dumps(candidate, indent=2, allow_nan=False).encode())
                    self.store.execute('INSERT INTO models(ts,hidden1,hidden2,accuracy,examples,artifact,promoted,reason) '
                                       "VALUES(datetime('now'),?,?,?,?,?,?,?)",
                                       (h1, h2, accuracy, stored_samples, candidate['artifact'], int(promoted),
                                        'validation improvement on shared split; audit diagnostic only' if promoted
                                        else 'did not exceed champion on the same validation inputs'))
                    committed = True
                except Exception as exc:
                    rollback_failed = False
                    for path, backup in backups:
                        try:
                            if backup is None:
                                path.unlink(missing_ok=True)
                            else:
                                os.replace(backup, path)
                                backup.unlink(missing_ok=True)
                        except OSError:
                            rollback_failed = True
                    if rollback_failed:
                        raise OSError('Model save failed and rollback was incomplete; .rollback files retained') from exc
                    raise
                finally:
                    if committed:
                        for _, backup in backups:
                            if backup is not None:
                                try:
                                    backup.unlink(missing_ok=True)
                                except OSError:
                                    pass  # Cleanup cannot invalidate an already committed champion.
                if promoted:
                    self.weights = [array.copy() for array in weights]
                    self.meta = candidate.copy()
            else:
                candidate['promoted'] = False
                candidate['would_promote'] = promoted
            return candidate

    def predict(self, energy, failures):
        with self.lock:
            if self.weights is None:
                return {'ready': False, 'message': 'Student has not been trained'}
            try:
                x = np.asarray([features(energy, failures)], dtype=np.float64)
            except ValueError as exc:
                return {'ready': False, 'message': str(exc)}
            p = self._forward(x, self.weights)[-1][0]
            return {'ready': True, 'prediction': 'explore' if p[1] > p[0] else 'conserve',
                    'confidence': round(float(p.max()), 4), 'validation_accuracy': self.meta['accuracy'],
                    'current_validation_accuracy': self.meta.get('current_validation_accuracy', self.meta['accuracy']),
                    'audit_accuracy': self.meta.get('audit_accuracy'), 'task': 'risk_gate'}

    def stats(self):
        with self.lock:
            n = self.store.one('SELECT COUNT(*) AS n FROM student_examples')['n']
            return {**self.meta, 'stored_samples': n}
