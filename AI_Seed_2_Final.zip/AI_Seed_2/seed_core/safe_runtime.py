"""Bounded scalar AST interpreter; organism source never reaches host exec/eval.

The complete language is validated before use. A small numeric builtin allowlist
is implemented explicitly, alongside calls to other validated organism functions.
"""
import ast
import hashlib
import operator


class CapabilityError(ValueError):
    pass


_MISSING = object()
_BIN = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
        ast.Mod: operator.mod, ast.FloorDiv: operator.floordiv}
_CMP = {ast.Eq: operator.eq, ast.NotEq: operator.ne, ast.Lt: operator.lt,
        ast.LtE: operator.le, ast.Gt: operator.gt, ast.GtE: operator.ge}
_BUILTINS = {'min': (2, 7), 'max': (2, 7), 'abs': (1, 1)}
_ALLOWED = (ast.Module, ast.FunctionDef, ast.arguments, ast.arg, ast.Return,
            ast.If, ast.Assign, ast.Expr, ast.Constant, ast.Name, ast.Load,
            ast.Store, ast.IfExp, ast.Call, ast.BoolOp, ast.And, ast.Or,
            ast.UnaryOp, ast.Not, ast.USub, ast.UAdd, ast.Compare,
            ast.BinOp, *tuple(_BIN), *tuple(_CMP))
MAX_SOURCE_BYTES = 20000
MAX_NODES = 900
MAX_SYNTAX_DEPTH = 64
MAX_STEPS = 800
MAX_CALL_DEPTH = 8
MAX_LOCALS = 40


def _scalar(value):
    if type(value) not in (str, int, float, bool):
        raise CapabilityError('only scalar values are allowed')
    if type(value) is str and len(value) > 200:
        raise CapabilityError('string too large')
    if type(value) in (int, float) and not -100000000 <= value <= 100000000:
        raise CapabilityError('number outside safe bounds')
    return value


def _name(name):
    if type(name) is not str or not name.isidentifier() or name.startswith('_') or len(name) > 64:
        raise CapabilityError('invalid identifier')


def _parse(source):
    if type(source) is not str or len(source) > MAX_SOURCE_BYTES:
        raise CapabilityError('source must be a bounded string')
    try:
        if len(source.encode('utf8')) > MAX_SOURCE_BYTES:
            raise CapabilityError('source too large')
        tree = ast.parse(source)
    except (SyntaxError, ValueError, RecursionError, UnicodeError) as exc:
        raise CapabilityError('invalid or excessively nested Python') from exc
    stack, count = [(tree, 0)], 0
    while stack:
        node, depth = stack.pop()
        count += 1
        if count > MAX_NODES:
            raise CapabilityError('too many syntax nodes')
        if depth > MAX_SYNTAX_DEPTH:
            raise CapabilityError('syntax nesting limit exceeded')
        if not isinstance(node, _ALLOWED):
            raise CapabilityError('unsupported syntax: ' + type(node).__name__)
        stack.extend((child, depth + 1) for child in ast.iter_child_nodes(node))
    return tree


def supported_features():
    """Public language contract for the planner; no host capabilities exposed."""
    return dict(values=['bounded int', 'finite float', 'bool', 'short str'],
                statements=['return', 'if/else', 'single local assignment'],
                operators=['+', '-', '*', '//', '%', 'comparisons', 'and', 'or', 'not'],
                builtins={'min': '2..7 numeric positional arguments',
                          'max': '2..7 numeric positional arguments',
                          'abs': '1 numeric positional argument'},
                helpers=True, loops=False, imports=False, attributes=False,
                limits=dict(source_bytes=MAX_SOURCE_BYTES, syntax_nodes=MAX_NODES,
                            syntax_depth=MAX_SYNTAX_DEPTH, execution_steps=MAX_STEPS,
                            helper_depth=MAX_CALL_DEPTH, locals=MAX_LOCALS))


class Runtime:
    def __init__(self, source: str, *, allow_unknown_helpers=False):
        tree = _parse(source)
        self.functions = {}
        for node in tree.body:
            if not isinstance(node, ast.FunctionDef):
                raise CapabilityError('top-level code must contain only functions')
            if (node.decorator_list or node.returns or node.type_comment or
                    node.args.defaults or node.args.kw_defaults or
                    node.args.posonlyargs or node.args.kwonlyargs or
                    node.args.vararg or node.args.kwarg or
                    getattr(node, 'type_params', ())):
                raise CapabilityError('decorators, typing and special parameters not allowed')
            _name(node.name)
            if node.name in _BUILTINS:
                raise CapabilityError('builtin names are reserved')
            if node.name in self.functions:
                raise CapabilityError('duplicate function name: ' + node.name)
            names = [a.arg for a in node.args.args]
            if len(names) > 7 or len(set(names)) != len(names):
                raise CapabilityError('invalid parameter list')
            for param in node.args.args:
                _name(param.arg)
                if param.annotation or param.type_comment:
                    raise CapabilityError('parameter annotations not allowed')
            self.functions[node.name] = node
        if len(self.functions) > 40:
            raise CapabilityError('too many functions')
        # Validate dead branches as well: unsupported code must not become a
        # latent capability when a different input is later encountered.
        for func in self.functions.values():
            self._validate_block(func.body, allow_unknown_helpers)

    def _validate_block(self, statements, allow_unknown_helpers):
        for stmt in statements:
            if isinstance(stmt, ast.Return):
                if stmt.value is None:
                    raise CapabilityError('return requires a scalar value')
                self._validate_value(stmt.value, allow_unknown_helpers)
            elif isinstance(stmt, ast.Assign):
                if len(stmt.targets) != 1 or not isinstance(stmt.targets[0], ast.Name):
                    raise CapabilityError('only single local assignments are permitted')
                _name(stmt.targets[0].id)
                if stmt.type_comment:
                    raise CapabilityError('type comments not allowed')
                self._validate_value(stmt.value, allow_unknown_helpers)
            elif isinstance(stmt, ast.If):
                self._validate_value(stmt.test, allow_unknown_helpers)
                self._validate_block(stmt.body, allow_unknown_helpers)
                self._validate_block(stmt.orelse, allow_unknown_helpers)
            elif isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Constant) and type(stmt.value.value) is str:
                _scalar(stmt.value.value)
            else:
                raise CapabilityError('unsupported statement: ' + type(stmt).__name__)

    def _validate_value(self, node, allow_unknown_helpers):
        if isinstance(node, ast.Constant):
            _scalar(node.value)
        elif isinstance(node, ast.Name):
            _name(node.id)
        elif isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name) or node.keywords:
                raise CapabilityError('only positional calls to pure builtins or organism helpers are allowed')
            name = node.func.id
            _name(name)
            if len(node.args) > 7:
                raise CapabilityError('too many call arguments')
            if name in _BUILTINS:
                low, high = _BUILTINS[name]
                if not low <= len(node.args) <= high:
                    raise CapabilityError('argument count mismatch for ' + name)
            elif name in self.functions:
                if len(node.args) != len(self.functions[name].args.args):
                    raise CapabilityError('argument count mismatch for ' + name)
            elif not allow_unknown_helpers:
                raise CapabilityError('unknown function: ' + name)
            for arg in node.args:
                self._validate_value(arg, allow_unknown_helpers)
        elif isinstance(node, ast.IfExp):
            for child in (node.test, node.body, node.orelse):
                self._validate_value(child, allow_unknown_helpers)
        elif isinstance(node, ast.UnaryOp):
            self._validate_value(node.operand, allow_unknown_helpers)
        elif isinstance(node, ast.BinOp):
            self._validate_value(node.left, allow_unknown_helpers)
            self._validate_value(node.right, allow_unknown_helpers)
        elif isinstance(node, ast.BoolOp):
            for child in node.values:
                self._validate_value(child, allow_unknown_helpers)
        elif isinstance(node, ast.Compare):
            for child in (node.left, *node.comparators):
                self._validate_value(child, allow_unknown_helpers)
        else:
            raise CapabilityError('unsupported expression: ' + type(node).__name__)

    def call(self, name, *args):
        _name(name)
        return self._call(name, args, [MAX_STEPS], 0)

    def _call(self, name, args, budget, depth):
        if depth >= MAX_CALL_DEPTH:
            raise CapabilityError('maximum helper call depth exceeded')
        func = self.functions.get(name)
        if func is None:
            raise CapabilityError('unknown function: ' + name)
        params = [a.arg for a in func.args.args]
        if len(params) != len(args):
            raise CapabilityError('argument count mismatch for ' + name)
        env = {p: _scalar(v) for p, v in zip(params, args)}
        value = self._block(func.body, env, budget, depth)
        if value is _MISSING:
            raise CapabilityError('function must return a value')
        return _scalar(value)

    @staticmethod
    def _step(budget):
        budget[0] -= 1
        if budget[0] < 0:
            raise CapabilityError('execution budget exceeded')

    def _block(self, statements, env, budget, depth):
        for stmt in statements:
            self._step(budget)
            if isinstance(stmt, ast.Return):
                return self._value(stmt.value, env, budget, depth)
            if isinstance(stmt, ast.Assign):
                name = stmt.targets[0].id
                if name not in env and len(env) >= MAX_LOCALS:
                    raise CapabilityError('local variable limit exceeded')
                env[name] = _scalar(self._value(stmt.value, env, budget, depth))
                continue
            if isinstance(stmt, ast.If):
                branch = stmt.body if self._value(stmt.test, env, budget, depth) else stmt.orelse
                result = self._block(branch, env, budget, depth)
                if result is not _MISSING:
                    return result
                continue
            # Validation permits only bounded literal docstrings here.
        return _MISSING

    def _value(self, node, env, budget, depth):
        self._step(budget)
        if isinstance(node, ast.Constant):
            return _scalar(node.value)
        if isinstance(node, ast.Name):
            if node.id not in env:
                raise CapabilityError('undefined variable: ' + node.id)
            return env[node.id]
        if isinstance(node, ast.IfExp):
            return self._value(node.body if self._value(node.test, env, budget, depth) else node.orelse, env, budget, depth)
        if isinstance(node, ast.Call):
            values = [self._value(arg, env, budget, depth) for arg in node.args]
            if node.func.id in _BUILTINS:
                if any(type(v) not in (int, float) for v in values):
                    raise CapabilityError('pure numeric builtin requires numbers (not bool or str)')
                if node.func.id == 'abs':
                    result = operator.abs(values[0])
                else:
                    result = values[0]
                    for value in values[1:]:
                        if (value < result if node.func.id == 'min' else value > result):
                            result = value
                return _scalar(result)
            return self._call(node.func.id, values, budget, depth + 1)
        if isinstance(node, ast.UnaryOp):
            value = self._value(node.operand, env, budget, depth)
            if isinstance(node.op, ast.Not):
                return not value
            if type(value) not in (int, float):
                raise CapabilityError('unary operator needs a number')
            return _scalar(-value if isinstance(node.op, ast.USub) else value)
        if isinstance(node, ast.BinOp):
            a, b = self._value(node.left, env, budget, depth), self._value(node.right, env, budget, depth)
            if type(a) not in (int, float) or type(b) not in (int, float):
                raise CapabilityError('arithmetic requires numbers')
            if type(node.op) in (ast.Mod, ast.FloorDiv) and b == 0:
                raise CapabilityError('division by zero')
            return _scalar(_BIN[type(node.op)](a, b))
        if isinstance(node, ast.BoolOp):
            value = None
            for part in node.values:
                value = self._value(part, env, budget, depth)
                if (isinstance(node.op, ast.And) and not value) or (isinstance(node.op, ast.Or) and value):
                    break
            return value
        if isinstance(node, ast.Compare):
            left = self._value(node.left, env, budget, depth)
            for op, right_node in zip(node.ops, node.comparators):
                right = self._value(right_node, env, budget, depth)
                try:
                    result = _CMP[type(op)](left, right)
                except (TypeError, OverflowError) as exc:
                    raise CapabilityError('invalid comparison') from exc
                if not result:
                    return False
                left = right
            return True
        raise CapabilityError('unsupported expression: ' + type(node).__name__)


def merge_one(old_source, proposed_source, max_chars=1800):
    """Return (new_source, changed_function, operation); reject duplicate or noop."""
    if type(proposed_source) is not str or not proposed_source.strip() or len(proposed_source) > max_chars:
        raise CapabilityError('mutation empty or too long')
    incoming = Runtime(proposed_source, allow_unknown_helpers=True)
    if len(incoming.functions) != 1:
        raise CapabilityError('mutations must contain exactly one function')
    Runtime(old_source)
    name = next(iter(incoming.functions))
    tree = _parse(old_source)
    new_node = next(iter(_parse(proposed_source).body))
    old_node = next((node for node in tree.body if node.name == name), None)
    if old_node is not None:
        if ast.dump(old_node, include_attributes=False) == ast.dump(new_node, include_attributes=False):
            raise CapabilityError('identical function already exists')
        tree.body[tree.body.index(old_node)] = new_node
        operation = 'replaced'
    else:
        tree.body.append(new_node)
        operation = 'added'
    ast.fix_missing_locations(tree)
    merged = ast.unparse(tree) + '\n'
    Runtime(merged)
    return merged, name, operation


def canonical_fingerprint(source):
    """Whitespace and comments do not create a new proposal identity."""
    try:
        normalized = ast.dump(_parse(source), include_attributes=False)
    except CapabilityError:
        normalized = str(source)
    return hashlib.sha256(normalized.encode('utf8', errors='replace')).hexdigest()[:20]
