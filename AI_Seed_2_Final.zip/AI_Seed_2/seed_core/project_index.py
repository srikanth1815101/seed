"""Read-only allowlisted project inspection, excluding private/generated data."""
import hashlib
import os
from pathlib import Path

EXTS = {'.py', '.json', '.md', '.txt', '.html', '.css', '.js', '.bat', '.toml'}
EXCLUDE_DIRS = {'.git', '.venv', 'venv', '__pycache__', 'node_modules', 'data',
                'models', 'workspaces', 'attachments', 'artifacts', 'dist', '.idea', '.vscode'}
EXCLUDE_NAMES = {'.env', '.env.local', 'secrets.json', 'credentials.json', 'seed.db'}


class ProjectIndex:
    def __init__(self, root, max_files=150, max_chars=7000):
        self.root = Path(root).resolve()
        self.max_files = min(max(int(max_files), 1), 1000)
        self.max_chars = min(max(int(max_chars), 100), 30_000)

    def _candidate(self, relative):
        if not isinstance(relative, str) or len(relative) > 240:
            return None
        candidate = Path(relative.replace('\\', '/'))
        if candidate.is_absolute() or '..' in candidate.parts or ':' in relative or not candidate.parts:
            return None
        if any(part.startswith('.') or part.lower() in EXCLUDE_DIRS for part in candidate.parts[:-1]):
            return None
        if candidate.name.lower() in EXCLUDE_NAMES or candidate.name.startswith('.'):
            return None
        if any(word in component.lower() for component in candidate.parts for word in
               ('secret', 'password', 'credential', 'token', 'api_key', 'private_key')):
            return None
        if candidate.suffix.lower() not in EXTS:
            return None
        original = self.root / candidate
        # Check original components: resolve().is_symlink() loses link identity.
        cursor = self.root
        for component in candidate.parts:
            cursor /= component
            if cursor.is_symlink():
                return None
        try:
            target = original.resolve(strict=True)
            target.relative_to(self.root)
            if not target.is_file() or target.stat().st_size > 100_000:
                return None
        except (OSError, RuntimeError, ValueError):
            return None
        return target

    def _allowed(self, relative):
        return self._candidate(relative) is not None

    def manifest(self):
        result = []
        for folder, dirs, names in os.walk(self.root, followlinks=False):
            dirs[:] = sorted(d for d in dirs if d.lower() not in EXCLUDE_DIRS
                             and not d.startswith('.')
                             and not any(word in d.lower() for word in ('secret', 'credential', 'password'))
                             and not (Path(folder) / d).is_symlink())
            for name in sorted(names):
                if len(result) >= self.max_files:
                    break
                try:
                    relative = (Path(folder) / name).relative_to(self.root).as_posix()
                    path = self._candidate(relative)
                    if path is None:
                        continue
                    data = path.read_bytes()
                    if len(data) > 100_000:
                        continue
                    result.append(dict(path=relative, bytes=len(data),
                                       sha=hashlib.sha256(data).hexdigest()[:10]))
                except (OSError, UnicodeError, ValueError):
                    continue
            if len(result) >= self.max_files:
                break
        return sorted(result, key=lambda item: item['path'])

    def read(self, relative, limit=None):
        path = self._candidate(relative)
        if path is None:
            raise ValueError('File not available to project inspector: ' + str(relative)[:80])
        cap = min(max(int(limit if limit is not None else self.max_chars), 1), self.max_chars)
        try:
            with path.open('rb') as stream:
                data = stream.read(100_001)
            if len(data) > 100_000:
                raise ValueError('Project file exceeds inspection size limit')
            return data.decode('utf8', errors='replace')[:cap]
        except OSError as exc:
            raise ValueError('Project file unavailable during inspection') from exc

    def read_many(self, requested):
        files = {}
        if not isinstance(requested, list):
            return files
        for name in requested[:3]:
            if not isinstance(name, str):
                continue
            try:
                files[name] = self.read(name, self.max_chars // 2)
            except ValueError as exc:
                files[name] = str(exc)
        return files

    def search(self, query, limit=8):
        """Bounded literal text search over inspectable files only."""
        if not isinstance(query, str) or not 2 <= len(query) <= 100:
            raise ValueError('search query must contain 2..100 characters')
        hits = []
        for item in self.manifest():
            text = self.read(item['path'])
            for number, line in enumerate(text.splitlines(), 1):
                if query.casefold() in line.casefold():
                    hits.append({'path': item['path'], 'line': number, 'text': line[:160]})
                    if len(hits) >= min(max(int(limit), 1), 20):
                        return hits
        return hits

    def dependencies(self):
        """Declared requirements only, without environment or credential access."""
        try:
            text = self.read('requirements.txt', 2500)
        except ValueError:
            return []
        return [line.strip() for line in text.splitlines()
                if line.strip() and not line.lstrip().startswith(('#', '-'))][:30]
