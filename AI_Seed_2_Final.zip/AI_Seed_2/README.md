# AI Seed 2 — Local Evolution Lab

AI Seed 2 is a local research application for **evolving tested programs and training a small neural policy**. Qwen3 1.7B, served by Ollama, proposes changes. A restricted interpreter executes organism functions; independent task evaluators decide whether a change improves behavior. SQLite stores the experiments and reconstructs memory for later calls. A FastAPI dashboard exposes the evidence.

The independently trained model is a small NumPy classifier for `risk_gate` decisions. It creates its own learned weights on your machine; it is not a new general language model, does not update Qwen's weights, and does not establish AGI. New useful capabilities require suitable tasks, data, and independent evaluation.

## Run on Windows

Use **64-bit Python 3.12** and an up-to-date [Ollama](https://ollama.com/). The pinned dependencies were validated on Python 3.12. The application uses CPU NumPy training; CUDA or PyTorch is not required. Qwen3 1.7B is the intended bootstrap model for a modest PC with 16 GB RAM and a GTX 1650 4 GB; actual inference speed depends on Ollama and available memory.

Extract the release into a new folder such as `C:\Seed2`. In PowerShell or Command Prompt, run:

```powershell
cd C:\Seed2
python --version
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.lock.txt
ollama pull qwen3:1.7b
.\.venv\Scripts\python.exe seed.py --check
.\.venv\Scripts\python.exe seed.py
```

Keep Ollama running. If it is not already running, start `ollama serve` in another terminal. `ollama pull` is an explicit one-time model download; AI Seed never downloads a model automatically.

Open `http://127.0.0.1:8765` in your browser. The lab starts **paused**; click **Start** to create a founder and begin the feedback loop. **Pause** preserves the population; **Resume** continues it; **Stop** stops cycles while preserving history. Ctrl+C closes the server. Start the server again and click Resume to continue stored organisms.

These commands call Python directly: no PowerShell script activation, `py` launcher, or execution-policy change is required. If `python` is unavailable, use the full path to your Python executable. The optional `start_windows.bat` uses `python` (or the executable path in `SEED_PYTHON`) to create the virtual environment and install pinned requirements. If Windows blocks the BAT file, use the direct commands above.

`--check` checks installed dependencies and whether the configured model is listed by Ollama. It downloads nothing, starts no worker, and returns a nonzero status if Ollama or the model is missing. The dashboard can start without Ollama; live generated mutations require a reachable model. Offline tests and the scripted demonstration do not require Ollama.

On Linux or macOS, use `python3 -m venv .venv`, `.venv/bin/python -m pip install -r requirements.lock.txt`, and `.venv/bin/python seed.py`.

## What evolves

A cycle observes an organism's energy, generation, active source, task scores, and recent results. It recalls persisted successes and canonical failures, chooses a task, and requests one structured action: `mutate`, `inspect`, `model_experiment`, or `reflect`.

For a mutation, the engine validates the function, merges it into an organism's source, and compares its behavior with the previous source on separate generated training and holdout cases. A successful improvement becomes active; its source revision and benchmark evidence are saved. Accepted improvements earn the configured net energy surplus. Invalid, duplicate, or nonimproving proposals receive no success reward. Helpers earn no direct improvement reward. Later environment trials execute active functions, and descendants inherit validated source.

The initial task families are `risk_gate`, `clamp_value`, `parity_label`, `budget_left`, `temperature_band`, `majority_vote`, `distance_1d`, and `triangle_kind`. These are small, verifiable programming problems. Their scores measure competence on those contracts, not general intelligence. Repeated access to evaluation results can still overfit benchmarks.

An omitted mutation task can be inferred only from a registered function name. Inspection requests must identify allowed files. Equivalent AST proposals share a fingerprint; duplicate errors retain the original reason rather than recursively growing. Persisted outcomes influence planning, and deterministic loop-breaking logic limits repeated failures. Context selection is bounded for the small Qwen model; the database keeps fuller records than a single prompt.

## Newly trained neural models

The student learns a binary `conserve`/`explore` risk policy from stored examples. Training uses small configurable two-hidden-layer MLPs and disjoint data partitions. Candidates are compared with the current champion on the same evaluation data. A worse candidate is not promoted; failed experiments leave the champion available. Checkpoints and metadata survive restart. The dashboard shows sample counts, measured accuracy, architecture experiments, and promotions.

When the learned policy meets the engine's accuracy/confidence gate, it can handle eligible risk challenges independently; `trials` records its actor identity. Untrained or ineligible cases use the organism path. This learning path is supervised by the trusted risk-task contract. It does not teach the student to generate code or chat.

To extend the research, add **developer-controlled task contracts and oracles** through the registry in `seed_core/tasks.py`, with independent benchmark cases and tests. Generated organisms cannot rewrite these evaluators or award themselves rewards. Extending the task registry does not automatically extend the student's input/output architecture; a new learned task requires an explicit dataset, model, and evaluation design.

## Inspect real evidence

The dashboard provides:

- Living and historical organisms, parentage, generations, energy, fitness, age, births, deaths, and active source.
- Mutation training/holdout scores, acceptance/rejection reasons, and cost/reward. Select an experiment to inspect its stored details.
- Exact recorded Qwen request and raw response, plus validation feedback. The trace is the authority for what a particular call received.
- Current persistent memory, allowlisted project source, student status, and model experiment history.
- Start, Pause, Resume, Stop, New founder, and Refresh. New founder retires the current population while retaining history.

Useful API endpoints include `/api/health`, `/api/status`, `/api/proposals`, `/api/proposals/{id}`, `/api/trials`, `/api/student`, `/api/source/{id}`, `/api/traces`, and `/api/traces/{id}`. `/api/control` and `/api/chat` accept JSON POST requests from the same local origin. The student chat option reports its narrow policy prediction, not a natural-language conversation.

## Tests and reproducible offline demonstration

Install the test dependency, then run all tests:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Run a demonstration into a **new output directory**:

```powershell
.\.venv\Scripts\python.exe scripts\offline_demo.py --output demo_run
```

The demo uses deterministic mocked model responses to exercise the real engine, evaluator, database, inheritance, and neural training. It writes evidence and state under the selected output directory; it does not replace your live `data/`, `models/`, or `workspaces/`. It demonstrates integration and measured progress, not autonomous invention by live Qwen. See the included validation report for the actual checks executed for this release. Live Ollama behavior and Windows execution must be checked on your PC.

The release also includes the actual trained example weights and evidence in
[`validation/`](validation/README.md). Try the narrow policy without starting Ollama:

```powershell
.\.venv\Scripts\python.exe scripts\predict_student.py --energy 90 --failures 0
```

This example is separate from your live lab; the lab learns its own champion from stored experience.

## Configuration and resources

`config.json` holds the Ollama model/URL, dashboard port, inference interval, population and energy settings, context/output limits, and daily call/token budgets. Defaults target short, serialized calls to `qwen3:1.7b`. Keep `host` loopback and `auto_start` false. If port 8765 is in use, change `port` and restart the server. No API key is needed for a local Ollama server.

`psutil` supplies the CPU/RAM governor. The shared inference lock prevents concurrent model calls. Inference budgets persist across application restarts. Pausing or stopping prevents future cycles; a request already inside Ollama may finish before shutdown, so do not interpret Pause as terminating a GPU computation instantly. Resource thresholds and budgets limit usage; they do not guarantee a fixed memory ceiling for Ollama itself.

## Data, backup, and upgrades

| Location | Contents |
| --- | --- |
| `data/seed2.db` | SQLite experiments, source revisions, observations, notes, trials, traces, budgets, and training examples |
| `workspaces/organism_N/capabilities.py` | Active inherited organism functions |
| `models/` | Neural checkpoints and metadata |
| `config.json` | Your local settings |
| `scripts/offline_demo.py` | Reproducible isolated demonstration |
| `requirements.lock.txt` | Pinned runtime dependencies |
| `tests/` | Offline unit/integration checks |

Before upgrading, stop the application and back up the **whole existing project directory**. Keep `data/`, `models/`, `workspaces/`, and your configuration when copying updated application files. Schema additions are migrated without resetting history. Do not copy a live SQLite database or overwrite an older project with a fresh release before making the backup.

## Execution boundaries

Organism-generated code runs in a bounded AST interpreter, never Python `exec` or `eval`. Imports, filesystem/network access, dynamic attribute access, and general host built-ins are unavailable. The runtime permits an explicit small pure-function subset, including bounded `min`, `max`, and `abs`, and enforces syntax, computation, and value limits. Qwen may inspect allowlisted project files but cannot read credentials, databases, model weights, hidden directories, or arbitrary system paths. It cannot rewrite the trusted engine.

The dashboard binds to loopback, rejects nonlocal Host headers and cross-origin control requests, and requires JSON for state-changing requests. It is a local research tool; do not expose it through a public reverse proxy. Preserve normal TLS/package verification during installation. The system deliberately keeps trusted evaluators and resource controls outside the evolving organisms.
